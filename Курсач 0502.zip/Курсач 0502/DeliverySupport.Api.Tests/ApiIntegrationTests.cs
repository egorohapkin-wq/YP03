using System.Net;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using DeliverySupport.Api.Models;
using Microsoft.AspNetCore.Mvc.Testing;
using Xunit;

namespace DeliverySupport.Api.Tests;

public class ApiFactory : WebApplicationFactory<Program>
{
}

public class ApiIntegrationTests : IClassFixture<ApiFactory>
{
    private readonly HttpClient _client;

    public ApiIntegrationTests(ApiFactory factory)
    {
        _client = factory.CreateClient();
    }

    private async Task<string> LoginAsync(string login, string password)
    {
        var response = await _client.PostAsJsonAsync("/api/auth/login",
            new LoginRequest { Login = login, Password = password });
        response.EnsureSuccessStatusCode();
        var result = await response.Content.ReadFromJsonAsync<LoginResponse>();
        Assert.NotNull(result);
        Assert.False(string.IsNullOrWhiteSpace(result!.Token));
        return result.Token;
    }

    private void Authorize(string token)
    {
        _client.DefaultRequestHeaders.Authorization =
            new AuthenticationHeaderValue("Bearer", token);
    }

    [Fact]
    public async Task Swagger_IsAvailable()
    {
        var response = await _client.GetAsync("/swagger/v1/swagger.json");
        Assert.Equal(HttpStatusCode.OK, response.StatusCode);
    }

    [Fact]
    public async Task Login_Admin_ReturnsTokenAndRole()
    {
        var token = await LoginAsync("admin", "Admin123");
        Assert.True(token.Length > 100);
    }

    [Fact]
    public async Task Login_WrongPassword_ReturnsUnauthorized()
    {
        var response = await _client.PostAsJsonAsync("/api/auth/login",
            new LoginRequest { Login = "admin", Password = "wrong" });
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Requests_WithoutToken_ReturnsUnauthorized()
    {
        var response = await _client.GetAsync("/api/requests");
        Assert.Equal(HttpStatusCode.Unauthorized, response.StatusCode);
    }

    [Fact]
    public async Task Requests_WithAdminToken_ReturnsList()
    {
        Authorize(await LoginAsync("admin", "Admin123"));

        var list = await _client.GetFromJsonAsync<List<RequestListItem>>("/api/requests");

        Assert.NotNull(list);
        Assert.NotEmpty(list!);
    }

    [Fact]
    public async Task ProblemTypes_ReturnsSixTypes()
    {
        Authorize(await LoginAsync("operator", "Oper123"));

        var types = await _client.GetFromJsonAsync<List<ProblemTypeDto>>("/api/problem-types");

        Assert.NotNull(types);
        Assert.Equal(6, types!.Count);
    }

    [Fact]
    public async Task ReportPeriod_ReturnsSummary()
    {
        Authorize(await LoginAsync("admin", "Admin123"));

        var report = await _client.GetFromJsonAsync<ReportPeriodDto>(
            "/api/reports/period?from=2020-01-01&to=2030-12-31");

        Assert.NotNull(report);
        Assert.True(report!.ClosedTotal >= 1);
    }

    [Fact]
    public async Task Client_CannotReadClientsDirectory()
    {
        Authorize(await LoginAsync("client", "Client123"));

        var response = await _client.GetAsync("/api/clients");

        Assert.Equal(HttpStatusCode.Forbidden, response.StatusCode);
    }
}
