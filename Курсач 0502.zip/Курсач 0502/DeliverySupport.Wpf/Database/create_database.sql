/* =============================================================================
   Курсовой проект 05.02 — ИС «Техническая поддержка службы доставки»
   Скрипт создания базы данных MS SQL Server.
   Все объекты создаются в текущей базе данных (user92_db) с префиксом DS_,
   чтобы не конфликтовать с таблицами других проектов на общем учебном сервере.
   ============================================================================= */

SET NOCOUNT ON;
GO

/* ---------- Удаление объектов в порядке зависимостей ---------- */
IF OBJECT_ID(N'dbo.DS_sp_ОтчетЗаПериодДетально', N'P') IS NOT NULL DROP PROCEDURE dbo.DS_sp_ОтчетЗаПериодДетально;
IF OBJECT_ID(N'dbo.DS_sp_ОтчетЗаПериод', N'P') IS NOT NULL DROP PROCEDURE dbo.DS_sp_ОтчетЗаПериод;
IF OBJECT_ID(N'dbo.DS_sp_ИзменитьСтатусЗаявки', N'P') IS NOT NULL DROP PROCEDURE dbo.DS_sp_ИзменитьСтатусЗаявки;
IF OBJECT_ID(N'dbo.DS_sp_НазначитьИсполнителя', N'P') IS NOT NULL DROP PROCEDURE dbo.DS_sp_НазначитьИсполнителя;
IF OBJECT_ID(N'dbo.DS_sp_СоздатьЗаявку', N'P') IS NOT NULL DROP PROCEDURE dbo.DS_sp_СоздатьЗаявку;
IF OBJECT_ID(N'dbo.DS_vw_НагрузкаСотрудников', N'V') IS NOT NULL DROP VIEW dbo.DS_vw_НагрузкаСотрудников;
IF OBJECT_ID(N'dbo.DS_vw_ВыполненныеЗаявки', N'V') IS NOT NULL DROP VIEW dbo.DS_vw_ВыполненныеЗаявки;
IF OBJECT_ID(N'dbo.DS_vw_РеестрЗаявок', N'V') IS NOT NULL DROP VIEW dbo.DS_vw_РеестрЗаявок;
IF OBJECT_ID(N'dbo.DS_ИсторияЗаявок', N'U') IS NOT NULL DROP TABLE dbo.DS_ИсторияЗаявок;
IF OBJECT_ID(N'dbo.DS_Заявки', N'U') IS NOT NULL DROP TABLE dbo.DS_Заявки;
IF OBJECT_ID(N'dbo.DS_Сотрудники', N'U') IS NOT NULL DROP TABLE dbo.DS_Сотрудники;
IF OBJECT_ID(N'dbo.DS_Клиенты', N'U') IS NOT NULL DROP TABLE dbo.DS_Клиенты;
IF OBJECT_ID(N'dbo.DS_СтатусыЗаявок', N'U') IS NOT NULL DROP TABLE dbo.DS_СтатусыЗаявок;
IF OBJECT_ID(N'dbo.DS_Приоритеты', N'U') IS NOT NULL DROP TABLE dbo.DS_Приоритеты;
IF OBJECT_ID(N'dbo.DS_ТипыПроблем', N'U') IS NOT NULL DROP TABLE dbo.DS_ТипыПроблем;
IF OBJECT_ID(N'dbo.DS_Пользователи', N'U') IS NOT NULL DROP TABLE dbo.DS_Пользователи;
IF OBJECT_ID(N'dbo.DS_Роли', N'U') IS NOT NULL DROP TABLE dbo.DS_Роли;
GO

/* ---------------------------- Справочники ---------------------------------- */

CREATE TABLE dbo.DS_Роли (
    idРоли       int IDENTITY(1,1) NOT NULL CONSTRAINT PK_DS_Роли PRIMARY KEY,
    Название     nvarchar(50)  NOT NULL CONSTRAINT UQ_DS_Роли_Название UNIQUE,
    Описание     nvarchar(200) NULL
);
GO

CREATE TABLE dbo.DS_Пользователи (
    idПользователя  int IDENTITY(1,1) NOT NULL CONSTRAINT PK_DS_Пользователи PRIMARY KEY,
    Логин           nvarchar(50)  NOT NULL CONSTRAINT UQ_DS_Пользователи_Логин UNIQUE,
    ХешПароля       nvarchar(200) NOT NULL,
    ФИО             nvarchar(150) NOT NULL,
    Телефон         nvarchar(20)  NOT NULL,
    Email           nvarchar(100) NULL,
    idРоли          int           NOT NULL,
    Заблокирован    bit           NOT NULL CONSTRAINT DF_DS_Пользователи_Блок DEFAULT (0),
    ДатаРегистрации datetime2(0)  NOT NULL CONSTRAINT DF_DS_Пользователи_Дата DEFAULT (SYSDATETIME()),
    ПоследнийВход   datetime2(0)  NULL
);
GO

CREATE TABLE dbo.DS_Клиенты (
    idКлиента        int IDENTITY(1,1) NOT NULL CONSTRAINT PK_DS_Клиенты PRIMARY KEY,
    idПользователя   int           NOT NULL CONSTRAINT UQ_DS_Клиенты_Пользователь UNIQUE,
    Адрес            nvarchar(250) NULL,
    Организация      nvarchar(150) NULL,
    ДатаРегистрации  datetime2(0)  NOT NULL CONSTRAINT DF_DS_Клиенты_Дата DEFAULT (SYSDATETIME())
);
GO

CREATE TABLE dbo.DS_Сотрудники (
    idСотрудника     int IDENTITY(1,1) NOT NULL CONSTRAINT PK_DS_Сотрудники PRIMARY KEY,
    idПользователя   int           NOT NULL CONSTRAINT UQ_DS_Сотрудники_Пользователь UNIQUE,
    Должность        nvarchar(100) NOT NULL,
    Специализация    nvarchar(150) NOT NULL,
    Активен          bit           NOT NULL CONSTRAINT DF_DS_Сотрудники_Активен DEFAULT (1),
    ДатаПриема       date          NOT NULL
);
GO

CREATE TABLE dbo.DS_ТипыПроблем (
    idТипа          int IDENTITY(1,1) NOT NULL CONSTRAINT PK_DS_ТипыПроблем PRIMARY KEY,
    Название        nvarchar(120) NOT NULL CONSTRAINT UQ_DS_ТипыПроблем_Название UNIQUE,
    Описание        nvarchar(500) NULL,
    НормативЧасов   int           NOT NULL CONSTRAINT DF_DS_ТипыПроблем_Норматив DEFAULT (24),
    CONSTRAINT CK_DS_ТипыПроблем_Норматив CHECK (НормативЧасов BETWEEN 1 AND 720)
);
GO

CREATE TABLE dbo.DS_Приоритеты (
    idПриоритета int IDENTITY(1,1) NOT NULL CONSTRAINT PK_DS_Приоритеты PRIMARY KEY,
    Название     nvarchar(20) NOT NULL CONSTRAINT UQ_DS_Приоритеты_Название UNIQUE,
    Вес          int          NOT NULL CONSTRAINT UQ_DS_Приоритеты_Вес UNIQUE,
    CONSTRAINT CK_DS_Приоритеты_Вес CHECK (Вес BETWEEN 1 AND 4)
);
GO

CREATE TABLE dbo.DS_СтатусыЗаявок (
    idСтатуса    int IDENTITY(1,1) NOT NULL CONSTRAINT PK_DS_СтатусыЗаявок PRIMARY KEY,
    Название     nvarchar(30) NOT NULL CONSTRAINT UQ_DS_СтатусыЗаявок_Название UNIQUE,
    Закрывающий  bit          NOT NULL CONSTRAINT DF_DS_Статусы_Закр DEFAULT (0),
    Порядок      int          NOT NULL
);
GO

/* ---------------------------- Основные таблицы ----------------------------- */

CREATE TABLE dbo.DS_Заявки (
    idЗаявки          int IDENTITY(1,1) NOT NULL CONSTRAINT PK_DS_Заявки PRIMARY KEY,
    НомерЗаявки       nvarchar(20)   NOT NULL CONSTRAINT UQ_DS_Заявки_Номер UNIQUE,
    idКлиента         int            NOT NULL,
    idТипа            int            NOT NULL,
    idПриоритета      int            NOT NULL,
    idСтатуса         int            NOT NULL,
    idИсполнителя     int            NULL,
    ДатаСоздания      datetime2(0)   NOT NULL CONSTRAINT DF_DS_Заявки_Дата DEFAULT (SYSDATETIME()),
    ОписаниеПроблемы  nvarchar(1000) NOT NULL,
    Результат         nvarchar(1000) NULL,
    ДатаЗакрытия      datetime2(0)   NULL,
    CONSTRAINT CK_DS_Заявки_ДатаЗакрытия CHECK
        (ДатаЗакрытия IS NULL OR ДатаЗакрытия >= ДатаСоздания)
);
GO

CREATE TABLE dbo.DS_ИсторияЗаявок (
    idИстории      int IDENTITY(1,1) NOT NULL CONSTRAINT PK_DS_ИсторияЗаявок PRIMARY KEY,
    idЗаявки       int           NOT NULL,
    idПользователя int           NOT NULL,
    СтарыйСтатус   nvarchar(30)  NULL,
    НовыйСтатус    nvarchar(30)  NOT NULL,
    Комментарий    nvarchar(500) NULL,
    ДатаИзменения  datetime2(0)  NOT NULL CONSTRAINT DF_DS_История_Дата DEFAULT (SYSDATETIME())
);
GO

/* ------------------------------ Связи -------------------------------------- */

ALTER TABLE dbo.DS_Пользователи ADD CONSTRAINT FK_DS_Пользователи_Роли
    FOREIGN KEY (idРоли) REFERENCES dbo.DS_Роли (idРоли);
ALTER TABLE dbo.DS_Клиенты ADD CONSTRAINT FK_DS_Клиенты_Пользователи
    FOREIGN KEY (idПользователя) REFERENCES dbo.DS_Пользователи (idПользователя)
    ON DELETE CASCADE;
ALTER TABLE dbo.DS_Сотрудники ADD CONSTRAINT FK_DS_Сотрудники_Пользователи
    FOREIGN KEY (idПользователя) REFERENCES dbo.DS_Пользователи (idПользователя)
    ON DELETE CASCADE;
ALTER TABLE dbo.DS_Заявки ADD CONSTRAINT FK_DS_Заявки_Клиенты
    FOREIGN KEY (idКлиента) REFERENCES dbo.DS_Клиенты (idКлиента);
ALTER TABLE dbo.DS_Заявки ADD CONSTRAINT FK_DS_Заявки_Типы
    FOREIGN KEY (idТипа) REFERENCES dbo.DS_ТипыПроблем (idТипа);
ALTER TABLE dbo.DS_Заявки ADD CONSTRAINT FK_DS_Заявки_Приоритеты
    FOREIGN KEY (idПриоритета) REFERENCES dbo.DS_Приоритеты (idПриоритета);
ALTER TABLE dbo.DS_Заявки ADD CONSTRAINT FK_DS_Заявки_Статусы
    FOREIGN KEY (idСтатуса) REFERENCES dbo.DS_СтатусыЗаявок (idСтатуса);
ALTER TABLE dbo.DS_Заявки ADD CONSTRAINT FK_DS_Заявки_Исполнитель
    FOREIGN KEY (idИсполнителя) REFERENCES dbo.DS_Сотрудники (idСотрудника)
    ON DELETE SET NULL;
ALTER TABLE dbo.DS_ИсторияЗаявок ADD CONSTRAINT FK_DS_История_Заявки
    FOREIGN KEY (idЗаявки) REFERENCES dbo.DS_Заявки (idЗаявки) ON DELETE CASCADE;
ALTER TABLE dbo.DS_ИсторияЗаявок ADD CONSTRAINT FK_DS_История_Пользователи
    FOREIGN KEY (idПользователя) REFERENCES dbo.DS_Пользователи (idПользователя);
GO

/* ------------------------------ Индексы ------------------------------------ */

CREATE INDEX IX_DS_Заявки_Статус ON dbo.DS_Заявки (idСтатуса, ДатаСоздания);
CREATE INDEX IX_DS_Заявки_Исполнитель ON dbo.DS_Заявки (idИсполнителя, idСтатуса);
CREATE INDEX IX_DS_Заявки_Клиент ON dbo.DS_Заявки (idКлиента, ДатаСоздания);
CREATE INDEX IX_DS_История_Заявка ON dbo.DS_ИсторияЗаявок (idЗаявки, ДатаИзменения);
CREATE UNIQUE INDEX UQ_DS_Пользователи_Телефон ON dbo.DS_Пользователи (Телефон);
CREATE INDEX IX_DS_ТипыПроблем_Название ON dbo.DS_ТипыПроблем (Название);
GO

/* --------------------------- Представления --------------------------------- */

CREATE VIEW dbo.DS_vw_РеестрЗаявок AS
SELECT z.idЗаявки, z.НомерЗаявки, kp.ФИО AS Клиент, tp.Название AS ТипПроблемы,
       p.Название AS Приоритет, s.Название AS Статус,
       ISNULL(st.ФИО, N'—') AS Исполнитель, z.ДатаСоздания,
       DATEADD(HOUR, tp.НормативЧасов, z.ДатаСоздания) AS ПлановыйСрок,
       z.idКлиента, z.idИсполнителя, s.idСтатуса, p.Вес AS ВесПриоритета
FROM dbo.DS_Заявки z
JOIN dbo.DS_Клиенты k ON k.idКлиента = z.idКлиента
JOIN dbo.DS_Пользователи kp ON kp.idПользователя = k.idПользователя
JOIN dbo.DS_ТипыПроблем tp ON tp.idТипа = z.idТипа
JOIN dbo.DS_Приоритеты p ON p.idПриоритета = z.idПриоритета
JOIN dbo.DS_СтатусыЗаявок s ON s.idСтатуса = z.idСтатуса
LEFT JOIN dbo.DS_Сотрудники so ON so.idСотрудника = z.idИсполнителя
LEFT JOIN dbo.DS_Пользователи st ON st.idПользователя = so.idПользователя;
GO

CREATE VIEW dbo.DS_vw_ВыполненныеЗаявки AS
SELECT z.idЗаявки, z.НомерЗаявки, tp.Название AS ТипПроблемы,
       p.Название AS Приоритет, s.Название AS Статус,
       z.ДатаСоздания, z.ДатаЗакрытия,
       DATEDIFF(MINUTE, z.ДатаСоздания, z.ДатаЗакрытия) AS МинутНаВыполнение,
       CASE WHEN z.ДатаЗакрытия >
                 DATEADD(HOUR, tp.НормативЧасов, z.ДатаСоздания)
            THEN 1 ELSE 0 END AS Просрочена
FROM dbo.DS_Заявки z
JOIN dbo.DS_ТипыПроблем tp ON tp.idТипа = z.idТипа
JOIN dbo.DS_Приоритеты p ON p.idПриоритета = z.idПриоритета
JOIN dbo.DS_СтатусыЗаявок s ON s.idСтатуса = z.idСтатуса
WHERE s.Закрывающий = 1 AND z.ДатаЗакрытия IS NOT NULL;
GO

CREATE VIEW dbo.DS_vw_НагрузкаСотрудников AS
SELECT s.idСотрудника, u.ФИО AS Сотрудник, s.Должность, s.Активен,
       COUNT(z.idЗаявки) AS ВсегоЗаявок,
       SUM(CASE WHEN st.Закрывающий = 0 THEN 1 ELSE 0 END) AS ВРаботе,
       SUM(CASE WHEN st.Закрывающий = 1 THEN 1 ELSE 0 END) AS Закрыто,
       SUM(CASE WHEN z.ДатаЗакрытия IS NOT NULL AND z.ДатаЗакрытия >
                     DATEADD(HOUR, tp.НормативЧасов, z.ДатаСоздания)
                THEN 1 ELSE 0 END) AS Просрочено
FROM dbo.DS_Сотрудники s
JOIN dbo.DS_Пользователи u ON u.idПользователя = s.idПользователя
LEFT JOIN dbo.DS_Заявки z ON z.idИсполнителя = s.idСотрудника
LEFT JOIN dbo.DS_СтатусыЗаявок st ON st.idСтатуса = z.idСтатуса
LEFT JOIN dbo.DS_ТипыПроблем tp ON tp.idТипа = z.idТипа
GROUP BY s.idСотрудника, u.ФИО, s.Должность, s.Активен;
GO

/* -------------------------- Хранимые процедуры ----------------------------- */

CREATE PROCEDURE dbo.DS_sp_СоздатьЗаявку
    @idКлиента int, @idТипа int, @idПриоритета int, @idПользователя int,
    @Описание nvarchar(1000), @НовыйНомер nvarchar(20) OUTPUT, @idЗаявки int OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @idСтатуса int = (SELECT idСтатуса FROM dbo.DS_СтатусыЗаявок WHERE Название = N'Новая');

    -- Вставляем строку с временным уникальным номером, затем заменяем его
    -- на номер вида TS-ГОД-000000N, где N — это idЗаявки.
    INSERT INTO dbo.DS_Заявки (НомерЗаявки, idКлиента, idТипа, idПриоритета,
                               idСтатуса, ОписаниеПроблемы)
    VALUES (N'P' + RIGHT(CONVERT(nvarchar(36), NEWID()), 19),
            @idКлиента, @idТипа, @idПриоритета, @idСтатуса, @Описание);

    SET @idЗаявки = SCOPE_IDENTITY();
    SET @НовыйНомер = N'TS-' + CONVERT(nvarchar(4), YEAR(SYSDATETIME())) + N'-'
                    + RIGHT(N'000000' + CONVERT(nvarchar(10), @idЗаявки), 6);

    UPDATE dbo.DS_Заявки SET НомерЗаявки = @НовыйНомер WHERE idЗаявки = @idЗаявки;

    INSERT INTO dbo.DS_ИсторияЗаявок (idЗаявки, idПользователя, СтарыйСтатус,
                                      НовыйСтатус, Комментарий)
    VALUES (@idЗаявки, @idПользователя, NULL, N'Новая', N'Заявка создана');
END;
GO

CREATE PROCEDURE dbo.DS_sp_НазначитьИсполнителя
    @idЗаявки int, @idСотрудника int, @idПользователя int
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    -- Исполнителем может быть только активный сотрудник.
    IF NOT EXISTS (SELECT 1 FROM dbo.DS_Сотрудники
                   WHERE idСотрудника = @idСотрудника AND Активен = 1)
        THROW 51001, N'Сотрудник не найден или неактивен', 1;

    BEGIN TRANSACTION;
    BEGIN TRY
        DECLARE @Старый nvarchar(30) =
            (SELECT s.Название FROM dbo.DS_Заявки z
             JOIN dbo.DS_СтатусыЗаявок s ON s.idСтатуса = z.idСтатуса
             WHERE z.idЗаявки = @idЗаявки);
        DECLARE @idНазначена int = (SELECT idСтатуса FROM dbo.DS_СтатусыЗаявок WHERE Название = N'Назначена');

        UPDATE dbo.DS_Заявки
           SET idИсполнителя = @idСотрудника, idСтатуса = @idНазначена
         WHERE idЗаявки = @idЗаявки;

        INSERT INTO dbo.DS_ИсторияЗаявок (idЗаявки, idПользователя, СтарыйСтатус,
                                          НовыйСтатус, Комментарий)
        VALUES (@idЗаявки, @idПользователя, @Старый, N'Назначена', N'Назначен исполнитель');

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH;
END;
GO

CREATE PROCEDURE dbo.DS_sp_ИзменитьСтатусЗаявки
    @idЗаявки int, @НовыйСтатус nvarchar(30), @idПользователя int,
    @Комментарий nvarchar(500) = NULL, @Результат nvarchar(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @Старый nvarchar(30) =
        (SELECT s.Название FROM dbo.DS_Заявки z
         JOIN dbo.DS_СтатусыЗаявок s ON s.idСтатуса = z.idСтатуса
         WHERE z.idЗаявки = @idЗаявки);
    DECLARE @idНовый int = (SELECT idСтатуса FROM dbo.DS_СтатусыЗаявок WHERE Название = @НовыйСтатус);
    DECLARE @Закрывающий bit = (SELECT Закрывающий FROM dbo.DS_СтатусыЗаявок WHERE idСтатуса = @idНовый);

    IF @idНовый IS NULL
        THROW 51004, N'Неизвестный статус заявки', 1;

    -- Контроль допустимых переходов статусов.
    IF @Старый IS NOT NULL AND @Старый <> @НовыйСтатус
       AND NOT (
            (@Старый = N'Новая'           AND @НовыйСтатус IN (N'Назначена', N'Отменена'))
         OR (@Старый = N'Назначена'       AND @НовыйСтатус IN (N'В работе', N'Отменена'))
         OR (@Старый = N'В работе'        AND @НовыйСтатус IN (N'Ожидает клиента', N'Решена', N'Отменена'))
         OR (@Старый = N'Ожидает клиента' AND @НовыйСтатус IN (N'В работе', N'Решена', N'Отменена'))
         OR (@Старый = N'Решена'          AND @НовыйСтатус IN (N'Закрыта', N'В работе'))
       )
        THROW 51003, N'Недопустимый переход статуса заявки', 1;

    -- Закрыть заявку можно только после заполнения результата решения.
    IF @НовыйСтатус = N'Закрыта'
       AND (@Результат IS NULL OR LTRIM(RTRIM(@Результат)) = N'')
       AND NOT EXISTS (SELECT 1 FROM dbo.DS_Заявки
                       WHERE idЗаявки = @idЗаявки
                         AND Результат IS NOT NULL
                         AND LTRIM(RTRIM(Результат)) <> N'')
        THROW 51002, N'Нельзя закрыть заявку без результата решения', 1;

    UPDATE dbo.DS_Заявки
       SET idСтатуса = @idНовый,
           Результат = ISNULL(@Результат, Результат),
           ДатаЗакрытия = CASE WHEN @Закрывающий = 1 THEN SYSDATETIME() ELSE ДатаЗакрытия END
     WHERE idЗаявки = @idЗаявки;

    INSERT INTO dbo.DS_ИсторияЗаявок (idЗаявки, idПользователя, СтарыйСтатус,
                                      НовыйСтатус, Комментарий)
    VALUES (@idЗаявки, @idПользователя, @Старый, @НовыйСтатус, @Комментарий);
END;
GO

CREATE PROCEDURE dbo.DS_sp_ОтчетЗаПериод
    @ДатаС date, @ДатаПо date
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
        COUNT(*) AS ВсегоЗакрыто,
        SUM(CASE WHEN Просрочена = 1 THEN 1 ELSE 0 END) AS Просрочено,
        CAST(AVG(CAST(МинутНаВыполнение AS float)) / 60.0 AS decimal(10,2)) AS СреднееЧасов
    FROM dbo.DS_vw_ВыполненныеЗаявки
    WHERE CAST(ДатаЗакрытия AS date) BETWEEN @ДатаС AND @ДатаПо;
END;
GO

CREATE PROCEDURE dbo.DS_sp_ОтчетЗаПериодДетально
    @ДатаС date, @ДатаПо date
AS
BEGIN
    SET NOCOUNT ON;
    SELECT v.НомерЗаявки, v.ТипПроблемы, v.Приоритет, v.Статус,
           v.ДатаСоздания, v.ДатаЗакрытия, v.МинутНаВыполнение, v.Просрочена,
           kp.ФИО AS Клиент, ISNULL(st.ФИО, N'—') AS Исполнитель
    FROM dbo.DS_vw_ВыполненныеЗаявки v
    JOIN dbo.DS_Заявки z ON z.idЗаявки = v.idЗаявки
    JOIN dbo.DS_Клиенты k ON k.idКлиента = z.idКлиента
    JOIN dbo.DS_Пользователи kp ON kp.idПользователя = k.idПользователя
    LEFT JOIN dbo.DS_Сотрудники so ON so.idСотрудника = z.idИсполнителя
    LEFT JOIN dbo.DS_Пользователи st ON st.idПользователя = so.idПользователя
    WHERE CAST(v.ДатаЗакрытия AS date) BETWEEN @ДатаС AND @ДатаПо
    ORDER BY v.ДатаЗакрытия;
END;
GO

/* ---------------------------- Демонстрационные данные ---------------------- */

INSERT INTO dbo.DS_Роли (Название, Описание) VALUES
 (N'Клиент', N'Клиент службы доставки'),
 (N'Оператор', N'Оператор технической поддержки'),
 (N'Специалист', N'Специалист поддержки'),
 (N'Администратор', N'Администратор системы');
GO

INSERT INTO dbo.DS_Приоритеты (Название, Вес) VALUES
 (N'Низкий', 1), (N'Средний', 2), (N'Высокий', 3), (N'Критический', 4);
GO

INSERT INTO dbo.DS_СтатусыЗаявок (Название, Закрывающий, Порядок) VALUES
 (N'Новая', 0, 1), (N'Назначена', 0, 2), (N'В работе', 0, 3),
 (N'Ожидает клиента', 0, 4), (N'Решена', 0, 5), (N'Закрыта', 1, 6),
 (N'Отменена', 1, 7);
GO

INSERT INTO dbo.DS_ТипыПроблем (Название, Описание, НормативЧасов) VALUES
 (N'Задержка доставки', N'Отправление не доставлено в срок', 24),
 (N'Повреждение груза', N'Повреждена упаковка или содержимое', 8),
 (N'Потеря отправления', N'Груз не найден в сортировочном центре', 48),
 (N'Ошибка в адресе', N'Неверный или неполный адрес доставки', 12),
 (N'Вопрос по оплате', N'Спор по стоимости или оплате', 24),
 (N'Качество обслуживания', N'Жалоба на курьера или оператора', 36);
GO

/* Пользователи: пароль хешируется SHA2_256 от строки в кодировке UTF-16LE.
   admin / Admin123, operator / Oper123, spec / Spec123, client / Client123 */
INSERT INTO dbo.DS_Пользователи (Логин, ХешПароля, ФИО, Телефон, Email, idРоли) VALUES
 (N'admin',    CONVERT(nvarchar(64), HASHBYTES('SHA2_256', N'Admin123'), 2),
  N'Охапкин Егор',        N'+7 (920) 000-00-01', N'admin@delivery.ru',
  (SELECT idРоли FROM dbo.DS_Роли WHERE Название = N'Администратор')),
 (N'operator', CONVERT(nvarchar(64), HASHBYTES('SHA2_256', N'Oper123'), 2),
  N'Смирнова Анна',       N'+7 (920) 000-00-02', N'operator@delivery.ru',
  (SELECT idРоли FROM dbo.DS_Роли WHERE Название = N'Оператор')),
 (N'spec',     CONVERT(nvarchar(64), HASHBYTES('SHA2_256', N'Spec123'), 2),
  N'Смирнов Михаил',      N'+7 (920) 000-00-03', N'spec@delivery.ru',
  (SELECT idРоли FROM dbo.DS_Роли WHERE Название = N'Специалист')),
 (N'client',   CONVERT(nvarchar(64), HASHBYTES('SHA2_256', N'Client123'), 2),
  N'Иванов Иван',         N'+7 (920) 000-00-04', N'client@mail.ru',
  (SELECT idРоли FROM dbo.DS_Роли WHERE Название = N'Клиент'));
GO

INSERT INTO dbo.DS_Клиенты (idПользователя, Адрес, Организация)
SELECT idПользователя, N'г. Ярославль, ул. Свободы, д. 10', N'ООО «Ромашка»'
FROM dbo.DS_Пользователи WHERE Логин = N'client';
GO

INSERT INTO dbo.DS_Сотрудники (idПользователя, Должность, Специализация, Активен, ДатаПриема)
SELECT idПользователя, N'Специалист поддержки', N'доставка, претензии, оплата', 1, '2025-02-01'
FROM dbo.DS_Пользователи WHERE Логин = N'spec';
GO

/* Демонстрационные заявки */
DECLARE @idКлиента int = (SELECT idКлиента FROM dbo.DS_Клиенты);
DECLARE @idПользователя int = (SELECT idПользователя FROM dbo.DS_Пользователи WHERE Логин = N'client');
DECLARE @idТип1 int = (SELECT idТипа FROM dbo.DS_ТипыПроблем WHERE Название = N'Задержка доставки');
DECLARE @idТип2 int = (SELECT idТипа FROM dbo.DS_ТипыПроблем WHERE Название = N'Повреждение груза');
DECLARE @idВысокий int = (SELECT idПриоритета FROM dbo.DS_Приоритеты WHERE Название = N'Высокий');
DECLARE @idСредний int = (SELECT idПриоритета FROM dbo.DS_Приоритеты WHERE Название = N'Средний');
DECLARE @idНовая int = (SELECT idСтатуса FROM dbo.DS_СтатусыЗаявок WHERE Название = N'Новая');
DECLARE @idЗакрыта int = (SELECT idСтатуса FROM dbo.DS_СтатусыЗаявок WHERE Название = N'Закрыта');
DECLARE @idСотрудника int = (SELECT idСотрудника FROM dbo.DS_Сотрудники);

INSERT INTO dbo.DS_Заявки (НомерЗаявки, idКлиента, idТипа, idПриоритета, idСтатуса,
                           idИсполнителя, ДатаСоздания, ОписаниеПроблемы, Результат, ДатаЗакрытия)
VALUES
 (N'TS-2026-000001', @idКлиента, @idТип1, @idВысокий, @idНовая, NULL,
  DATEADD(DAY, -1, SYSDATETIME()), N'Отправление задерживается более двух дней', NULL, NULL),
 (N'TS-2026-000002', @idКлиента, @idТип2, @idСредний, @idЗакрыта, @idСотрудника,
  DATEADD(DAY, -10, SYSDATETIME()), N'Повреждена упаковка при доставке', N'Оформлена компенсация',
  DATEADD(DAY, -9, SYSDATETIME()));
GO

PRINT N'База данных DS_* успешно создана.';
GO
