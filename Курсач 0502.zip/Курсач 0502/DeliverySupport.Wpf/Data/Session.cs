using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Data
{
    /// <summary>Текущая сессия: вошедший пользователь и его роль.</summary>
    public static class Session
    {
        public static User CurrentUser { get; set; }
        public static int? ClientId { get; set; }
        public static int? EmployeeId { get; set; }

        public static string Role => CurrentUser?.Роль ?? string.Empty;

        public static bool IsAdmin => Role == "Администратор";
        public static bool IsOperator => Role == "Оператор";
        public static bool IsSpecialist => Role == "Специалист";
        public static bool IsClient => Role == "Клиент";

        /// <summary>Может создавать/назначать исполнителя и вести реестр.</summary>
        public static bool CanManageRequests => IsAdmin || IsOperator || IsSpecialist;

        public static void Clear()
        {
            CurrentUser = null;
            ClientId = null;
            EmployeeId = null;
        }
    }
}
