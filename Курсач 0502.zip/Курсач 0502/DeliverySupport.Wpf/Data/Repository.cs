using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Data
{
    /// <summary>
    /// Методы доступа к данным. Все запросы параметризованы, имена объектов
    /// соответствуют префиксу DS_ в базе данных.
    /// </summary>
    public static class Repository
    {
        // ----------------------------- Аутентификация -----------------------------

        public static User Authenticate(string login, string password)
        {
            const string sql = @"
SELECT u.idПользователя, u.Логин, u.ХешПароля, u.ФИО, u.Телефон, u.Email,
       u.idРоли, r.Название AS Роль, u.Заблокирован, u.ДатаРегистрации, u.ПоследнийВход
FROM dbo.DS_Пользователи u
JOIN dbo.DS_Роли r ON r.idРоли = u.idРоли
WHERE u.Логин = @login";

            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn, sql, Db.P("@login", login)))
            using (var rdr = cmd.ExecuteReader())
            {
                if (!rdr.Read()) return null;
                var user = MapUser(rdr);
                string hash = rdr["ХешПароля"].ToString();
                if (!PasswordHasher.Verify(password, hash)) return null;
                if (user.Заблокирован) throw new InvalidOperationException(
                    "Учётная запись заблокирована администратором.");
                return user;
            }
        }

        public static void UpdateLastLogin(int userId)
        {
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "UPDATE dbo.DS_Пользователи SET ПоследнийВход = SYSDATETIME() WHERE idПользователя = @id",
                Db.P("@id", userId)))
                cmd.ExecuteNonQuery();
        }

        public static void LoadProfileLinks(int userId, string role)
        {
            using (var conn = Db.Open())
            {
                if (role == "Клиент")
                {
                    using (var cmd = Db.Command(conn,
                        "SELECT idКлиента FROM dbo.DS_Клиенты WHERE idПользователя = @id",
                        Db.P("@id", userId)))
                    {
                        var o = cmd.ExecuteScalar();
                        Session.ClientId = o == null ? (int?)null : Convert.ToInt32(o);
                    }
                }
                else if (role == "Специалист")
                {
                    using (var cmd = Db.Command(conn,
                        "SELECT idСотрудника FROM dbo.DS_Сотрудники WHERE idПользователя = @id",
                        Db.P("@id", userId)))
                    {
                        var o = cmd.ExecuteScalar();
                        Session.EmployeeId = o == null ? (int?)null : Convert.ToInt32(o);
                    }
                }
            }
        }

        public static bool LoginExists(string login)
        {
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "SELECT COUNT(*) FROM dbo.DS_Пользователи WHERE Логин = @login",
                Db.P("@login", login)))
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
        }

        /// <summary>Регистрация клиента: пользователь + запись клиента.</summary>
        public static void RegisterClient(string login, string password, string fio,
            string phone, string email, string address, string organization)
        {
            phone = Validation.NormalizePhone(phone) ?? phone;
            using (var conn = Db.Open())
            using (var tx = conn.BeginTransaction())
            {
                try
                {
                    int roleId;
                    using (var cmd = Db.Command(conn,
                        "SELECT idРоли FROM dbo.DS_Роли WHERE Название = N'Клиент'", null))
                    {
                        cmd.Transaction = tx;
                        roleId = Convert.ToInt32(cmd.ExecuteScalar());
                    }

                    int userId;
                    using (var cmd = Db.Command(conn, @"
INSERT INTO dbo.DS_Пользователи (Логин, ХешПароля, ФИО, Телефон, Email, idРоли)
VALUES (@login, @hash, @fio, @phone, @email, @role);
SELECT SCOPE_IDENTITY();",
                        Db.P("@login", login), Db.P("@hash", PasswordHasher.Hash(password)),
                        Db.P("@fio", fio), Db.P("@phone", phone),
                        Db.P("@email", (object)email ?? DBNull.Value), Db.P("@role", roleId)))
                    {
                        cmd.Transaction = tx;
                        userId = Convert.ToInt32(cmd.ExecuteScalar());
                    }

                    using (var cmd = Db.Command(conn, @"
INSERT INTO dbo.DS_Клиенты (idПользователя, Адрес, Организация)
VALUES (@uid, @addr, @org)",
                        Db.P("@uid", userId),
                        Db.P("@addr", (object)address ?? DBNull.Value),
                        Db.P("@org", (object)organization ?? DBNull.Value)))
                    {
                        cmd.Transaction = tx;
                        cmd.ExecuteNonQuery();
                    }

                    tx.Commit();
                }
                catch
                {
                    tx.Rollback();
                    throw;
                }
            }
        }

        // ------------------------------- Заявки ----------------------------------

        private const string RequestRegistrySql = @"
SELECT idЗаявки, НомерЗаявки, Клиент, ТипПроблемы, Приоритет, Статус,
       Исполнитель, ДатаСоздания, ПлановыйСрок, idКлиента, idИсполнителя,
       idСтатуса, ВесПриоритета
FROM dbo.DS_vw_РеестрЗаявок
WHERE (@clientId IS NULL OR idКлиента = @clientId)
  AND (@statusId IS NULL OR idСтатуса = @statusId)
  AND (@execId IS NULL OR idИсполнителя = @execId)
  AND (@dateFrom IS NULL OR ДатаСоздания >= @dateFrom)
  AND (@dateTo IS NULL OR ДатаСоздания < DATEADD(DAY, 1, @dateTo))
  AND (@search IS NULL
       OR НомерЗаявки LIKE '%' + @search + '%'
       OR Клиент LIKE '%' + @search + '%'
       OR ТипПроблемы LIKE '%' + @search + '%')
ORDER BY ВесПриоритета DESC, ДатаСоздания DESC";

        public static List<RequestItem> GetRequests(int? clientId, int? statusId,
            int? execId, string search)
        {
            return GetRequests(clientId, statusId, execId, search, null, null);
        }

        public static List<RequestItem> GetRequests(int? clientId, int? statusId,
            int? execId, string search, DateTime? dateFrom, DateTime? dateTo)
        {
            var list = new List<RequestItem>();
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn, RequestRegistrySql,
                Db.P("@clientId", (object)clientId ?? DBNull.Value),
                Db.P("@statusId", (object)statusId ?? DBNull.Value),
                Db.P("@execId", (object)execId ?? DBNull.Value),
                Db.P("@dateFrom", dateFrom.HasValue ? (object)dateFrom.Value.Date : DBNull.Value),
                Db.P("@dateTo", dateTo.HasValue ? (object)dateTo.Value.Date : DBNull.Value),
                Db.P("@search", string.IsNullOrWhiteSpace(search) ? (object)DBNull.Value : search)))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                {
                    list.Add(new RequestItem
                    {
                        Id = (int)rdr["idЗаявки"],
                        Номер = rdr["НомерЗаявки"].ToString(),
                        Клиент = rdr["Клиент"].ToString(),
                        ТипПроблемы = rdr["ТипПроблемы"].ToString(),
                        Приоритет = rdr["Приоритет"].ToString(),
                        Статус = rdr["Статус"].ToString(),
                        Исполнитель = rdr["Исполнитель"].ToString(),
                        ДатаСоздания = (DateTime)rdr["ДатаСоздания"],
                        ПлановыйСрок = (DateTime)rdr["ПлановыйСрок"],
                        IdКлиента = (int)rdr["idКлиента"],
                        IdИсполнителя = rdr["idИсполнителя"] as int?,
                        IdСтатуса = (int)rdr["idСтатуса"],
                        ВесПриоритета = (int)rdr["ВесПриоритета"]
                    });
                }
            }
            return list;
        }

        public static RequestDetail GetRequestDetail(int id)
        {
            const string sql = @"
SELECT z.idЗаявки, z.НомерЗаявки, z.idКлиента, kp.ФИО AS Клиент, kp.Телефон,
       k.Адрес, z.idТипа, tp.Название AS ТипПроблемы, z.idПриоритета,
       p.Название AS Приоритет, z.idСтатуса, s.Название AS Статус,
       z.idИсполнителя, st.ФИО AS Исполнитель, z.ДатаСоздания, z.ДатаЗакрытия,
       z.ОписаниеПроблемы, z.Результат
FROM dbo.DS_Заявки z
JOIN dbo.DS_Клиенты k ON k.idКлиента = z.idКлиента
JOIN dbo.DS_Пользователи kp ON kp.idПользователя = k.idПользователя
JOIN dbo.DS_ТипыПроблем tp ON tp.idТипа = z.idТипа
JOIN dbo.DS_Приоритеты p ON p.idПриоритета = z.idПриоритета
JOIN dbo.DS_СтатусыЗаявок s ON s.idСтатуса = z.idСтатуса
LEFT JOIN dbo.DS_Сотрудники so ON so.idСотрудника = z.idИсполнителя
LEFT JOIN dbo.DS_Пользователи st ON st.idПользователя = so.idПользователя
WHERE z.idЗаявки = @id";

            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn, sql, Db.P("@id", id)))
            using (var rdr = cmd.ExecuteReader())
            {
                if (!rdr.Read()) return null;
                return new RequestDetail
                {
                    Id = (int)rdr["idЗаявки"],
                    Номер = rdr["НомерЗаявки"].ToString(),
                    IdКлиента = (int)rdr["idКлиента"],
                    Клиент = rdr["Клиент"].ToString(),
                    Телефон = rdr["Телефон"].ToString(),
                    Адрес = rdr["Адрес"] as string,
                    IdТипа = (int)rdr["idТипа"],
                    ТипПроблемы = rdr["ТипПроблемы"].ToString(),
                    IdПриоритета = (int)rdr["idПриоритета"],
                    Приоритет = rdr["Приоритет"].ToString(),
                    IdСтатуса = (int)rdr["idСтатуса"],
                    Статус = rdr["Статус"].ToString(),
                    IdИсполнителя = rdr["idИсполнителя"] as int?,
                    Исполнитель = rdr["Исполнитель"] as string,
                    ДатаСоздания = (DateTime)rdr["ДатаСоздания"],
                    ДатаЗакрытия = rdr["ДатаЗакрытия"] as DateTime?,
                    ОписаниеПроблемы = rdr["ОписаниеПроблемы"].ToString(),
                    Результат = rdr["Результат"] as string
                };
            }
        }

        public static List<HistoryEntry> GetHistory(int requestId)
        {
            const string sql = @"
SELECT h.idИстории, u.ФИО AS Пользователь, h.СтарыйСтатус, h.НовыйСтатус,
       h.Комментарий, h.ДатаИзменения
FROM dbo.DS_ИсторияЗаявок h
JOIN dbo.DS_Пользователи u ON u.idПользователя = h.idПользователя
WHERE h.idЗаявки = @id
ORDER BY h.ДатаИзменения";

            var list = new List<HistoryEntry>();
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn, sql, Db.P("@id", requestId)))
            using (var rdr = cmd.ExecuteReader())
            {
                while (rdr.Read())
                {
                    list.Add(new HistoryEntry
                    {
                        Id = (int)rdr["idИстории"],
                        Пользователь = rdr["Пользователь"].ToString(),
                        СтарыйСтатус = rdr["СтарыйСтатус"] as string,
                        НовыйСтатус = rdr["НовыйСтатус"].ToString(),
                        Комментарий = rdr["Комментарий"] as string,
                        Дата = (DateTime)rdr["ДатаИзменения"]
                    });
                }
            }
            return list;
        }

        /// <summary>Создание заявки через хранимую процедуру.</summary>
        public static int CreateRequest(int clientId, int typeId, int priorityId,
            int userId, string description, out string number)
        {
            using (var conn = Db.Open())
            using (var cmd = new SqlCommand("dbo.DS_sp_СоздатьЗаявку", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idКлиента", clientId);
                cmd.Parameters.AddWithValue("@idТипа", typeId);
                cmd.Parameters.AddWithValue("@idПриоритета", priorityId);
                cmd.Parameters.AddWithValue("@idПользователя", userId);
                cmd.Parameters.AddWithValue("@Описание", description);

                var pNumber = new SqlParameter("@НовыйНомер", SqlDbType.NVarChar, 20)
                { Direction = ParameterDirection.Output };
                var pId = new SqlParameter("@idЗаявки", SqlDbType.Int)
                { Direction = ParameterDirection.Output };
                cmd.Parameters.Add(pNumber);
                cmd.Parameters.Add(pId);

                cmd.ExecuteNonQuery();
                number = pNumber.Value as string;
                return Convert.ToInt32(pId.Value);
            }
        }

        public static void AssignExecutor(int requestId, int employeeId, int userId)
        {
            using (var conn = Db.Open())
            using (var cmd = new SqlCommand("dbo.DS_sp_НазначитьИсполнителя", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idЗаявки", requestId);
                cmd.Parameters.AddWithValue("@idСотрудника", employeeId);
                cmd.Parameters.AddWithValue("@idПользователя", userId);
                cmd.ExecuteNonQuery();
            }
        }

        public static void ChangeStatus(int requestId, string status, int userId,
            string comment, string result)
        {
            using (var conn = Db.Open())
            using (var cmd = new SqlCommand("dbo.DS_sp_ИзменитьСтатусЗаявки", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@idЗаявки", requestId);
                cmd.Parameters.AddWithValue("@НовыйСтатус", status);
                cmd.Parameters.AddWithValue("@idПользователя", userId);
                cmd.Parameters.AddWithValue("@Комментарий", (object)comment ?? DBNull.Value);
                cmd.Parameters.AddWithValue("@Результат", (object)result ?? DBNull.Value);
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>Следующий номер заявки вида TS-ГОД-0000001.</summary>
        public static string GenerateNumber()
        {
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "SELECT ISNULL(MAX(idЗаявки),0) + 1 FROM dbo.DS_Заявки"))
            {
                int next = Convert.ToInt32(cmd.ExecuteScalar());
                return $"TS-{DateTime.Now:yyyy}-{next:D6}";
            }
        }

        // ------------------------------ Справочники -------------------------------

        public static List<ReferenceItem> GetStatuses()
        {
            var list = new List<ReferenceItem>();
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "SELECT idСтатуса, Название, Порядок FROM dbo.DS_СтатусыЗаявок ORDER BY Порядок"))
            using (var rdr = cmd.ExecuteReader())
                while (rdr.Read())
                    list.Add(new ReferenceItem
                    {
                        Id = (int)rdr["idСтатуса"],
                        Название = rdr["Название"].ToString(),
                        Доп1 = rdr["Порядок"].ToString()
                    });
            return list;
        }

        public static List<ReferenceItem> GetPriorities()
        {
            var list = new List<ReferenceItem>();
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "SELECT idПриоритета, Название, Вес FROM dbo.DS_Приоритеты ORDER BY Вес"))
            using (var rdr = cmd.ExecuteReader())
                while (rdr.Read())
                    list.Add(new ReferenceItem
                    {
                        Id = (int)rdr["idПриоритета"],
                        Название = rdr["Название"].ToString(),
                        Доп1 = rdr["Вес"].ToString()
                    });
            return list;
        }

        public static List<ReferenceItem> GetProblemTypes()
        {
            var list = new List<ReferenceItem>();
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "SELECT idТипа, Название, НормативЧасов, Описание FROM dbo.DS_ТипыПроблем ORDER BY Название"))
            using (var rdr = cmd.ExecuteReader())
                while (rdr.Read())
                    list.Add(new ReferenceItem
                    {
                        Id = (int)rdr["idТипа"],
                        Название = rdr["Название"].ToString(),
                        Доп1 = rdr["НормативЧасов"].ToString(),
                        Доп2 = rdr["Описание"] as string
                    });
            return list;
        }

        public static bool ProblemTypeExists(string name, int? excludeId)
        {
            using (var conn = Db.Open())
            using (var cmd = excludeId.HasValue
                ? Db.Command(conn,
                    "SELECT COUNT(*) FROM dbo.DS_ТипыПроблем WHERE Название = @n AND idТипа <> @id",
                    Db.P("@n", name), Db.P("@id", excludeId.Value))
                : Db.Command(conn,
                    "SELECT COUNT(*) FROM dbo.DS_ТипыПроблем WHERE Название = @n",
                    Db.P("@n", name)))
                return Convert.ToInt32(cmd.ExecuteScalar()) > 0;
        }

        public static void AddProblemType(string name, int hours, string description)
        {
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "INSERT INTO dbo.DS_ТипыПроблем (Название, НормативЧасов, Описание) VALUES (@n, @h, @d)",
                Db.P("@n", name), Db.P("@h", hours),
                Db.P("@d", (object)description ?? DBNull.Value)))
                cmd.ExecuteNonQuery();
        }

        public static void UpdateProblemType(int id, string name, int hours, string description)
        {
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "UPDATE dbo.DS_ТипыПроблем SET Название=@n, НормативЧасов=@h, Описание=@d WHERE idТипа=@id",
                Db.P("@n", name), Db.P("@h", hours),
                Db.P("@d", (object)description ?? DBNull.Value), Db.P("@id", id)))
                cmd.ExecuteNonQuery();
        }

        public static void DeleteProblemType(int id)
        {
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "DELETE FROM dbo.DS_ТипыПроблем WHERE idТипа=@id", Db.P("@id", id)))
                cmd.ExecuteNonQuery();
        }

        public static List<Role> GetRoles()
        {
            var list = new List<Role>();
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "SELECT idРоли, Название, Описание FROM dbo.DS_Роли ORDER BY idРоли"))
            using (var rdr = cmd.ExecuteReader())
                while (rdr.Read())
                    list.Add(new Role
                    {
                        Id = (int)rdr["idРоли"],
                        Название = rdr["Название"].ToString(),
                        Описание = rdr["Описание"] as string
                    });
            return list;
        }

        // -------------------------------- Клиенты ---------------------------------

        public static List<Client> GetClients(string search)
        {
            const string sql = @"
SELECT k.idКлиента, k.idПользователя, u.ФИО, u.Телефон, u.Email,
       k.Адрес, k.Организация, k.ДатаРегистрации
FROM dbo.DS_Клиенты k
JOIN dbo.DS_Пользователи u ON u.idПользователя = k.idПользователя
WHERE (@s IS NULL OR u.ФИО LIKE '%' + @s + '%' OR u.Телефон LIKE '%' + @s + '%'
       OR k.Организация LIKE '%' + @s + '%')
ORDER BY u.ФИО";

            var list = new List<Client>();
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn, sql,
                Db.P("@s", string.IsNullOrWhiteSpace(search) ? (object)DBNull.Value : search)))
            using (var rdr = cmd.ExecuteReader())
                while (rdr.Read())
                    list.Add(new Client
                    {
                        Id = (int)rdr["idКлиента"],
                        IdПользователя = (int)rdr["idПользователя"],
                        ФИО = rdr["ФИО"].ToString(),
                        Телефон = rdr["Телефон"].ToString(),
                        Email = rdr["Email"] as string,
                        Адрес = rdr["Адрес"] as string,
                        Организация = rdr["Организация"] as string,
                        ДатаРегистрации = (DateTime)rdr["ДатаРегистрации"]
                    });
            return list;
        }

        public static void UpdateClient(int clientId, string fio, string phone,
            string email, string address, string organization)
        {
            using (var conn = Db.Open())
            using (var tx = conn.BeginTransaction())
            {
                try
                {
                    int userId;
                    using (var cmd = Db.Command(conn,
                        "SELECT idПользователя FROM dbo.DS_Клиенты WHERE idКлиента=@id",
                        Db.P("@id", clientId)))
                    {
                        cmd.Transaction = tx;
                        userId = Convert.ToInt32(cmd.ExecuteScalar());
                    }

                    using (var cmd = Db.Command(conn,
                        "UPDATE dbo.DS_Пользователи SET ФИО=@fio, Телефон=@phone, Email=@email WHERE idПользователя=@uid",
                        Db.P("@fio", fio), Db.P("@phone", phone),
                        Db.P("@email", (object)email ?? DBNull.Value), Db.P("@uid", userId)))
                    {
                        cmd.Transaction = tx;
                        cmd.ExecuteNonQuery();
                    }

                    using (var cmd = Db.Command(conn,
                        "UPDATE dbo.DS_Клиенты SET Адрес=@addr, Организация=@org WHERE idКлиента=@id",
                        Db.P("@addr", (object)address ?? DBNull.Value),
                        Db.P("@org", (object)organization ?? DBNull.Value),
                        Db.P("@id", clientId)))
                    {
                        cmd.Transaction = tx;
                        cmd.ExecuteNonQuery();
                    }

                    tx.Commit();
                }
                catch { tx.Rollback(); throw; }
            }
        }

        // ------------------------------- Сотрудники -------------------------------

        public static List<Employee> GetEmployees(bool onlyActive)
        {
            const string sql = @"
SELECT s.idСотрудника, s.idПользователя, u.ФИО, u.Телефон, u.Email,
       s.Должность, s.Специализация, s.Активен, s.ДатаПриема
FROM dbo.DS_Сотрудники s
JOIN dbo.DS_Пользователи u ON u.idПользователя = s.idПользователя
WHERE (@onlyActive = 0 OR s.Активен = 1)
ORDER BY u.ФИО";

            var list = new List<Employee>();
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn, sql, Db.P("@onlyActive", onlyActive ? 1 : 0)))
            using (var rdr = cmd.ExecuteReader())
                while (rdr.Read())
                    list.Add(new Employee
                    {
                        Id = (int)rdr["idСотрудника"],
                        IdПользователя = (int)rdr["idПользователя"],
                        ФИО = rdr["ФИО"].ToString(),
                        Телефон = rdr["Телефон"].ToString(),
                        Email = rdr["Email"] as string,
                        Должность = rdr["Должность"].ToString(),
                        Специализация = rdr["Специализация"].ToString(),
                        Активен = (bool)rdr["Активен"],
                        ДатаПриема = (DateTime)rdr["ДатаПриема"]
                    });
            return list;
        }

        public static void SaveEmployee(int? employeeId, string fio, string phone,
            string email, string position, string specialization, bool active)
        {
            using (var conn = Db.Open())
            using (var tx = conn.BeginTransaction())
            {
                try
                {
                    if (employeeId.HasValue)
                    {
                        int userId;
                        using (var cmd = Db.Command(conn,
                            "SELECT idПользователя FROM dbo.DS_Сотрудники WHERE idСотрудника=@id",
                            Db.P("@id", employeeId.Value)))
                        {
                            cmd.Transaction = tx;
                            userId = Convert.ToInt32(cmd.ExecuteScalar());
                        }
                        using (var cmd = Db.Command(conn,
                            "UPDATE dbo.DS_Пользователи SET ФИО=@fio, Телефон=@phone, Email=@email WHERE idПользователя=@uid",
                            Db.P("@fio", fio), Db.P("@phone", phone),
                            Db.P("@email", (object)email ?? DBNull.Value), Db.P("@uid", userId)))
                        { cmd.Transaction = tx; cmd.ExecuteNonQuery(); }

                        using (var cmd = Db.Command(conn,
                            "UPDATE dbo.DS_Сотрудники SET Должность=@p, Специализация=@s, Активен=@a WHERE idСотрудника=@id",
                            Db.P("@p", position), Db.P("@s", specialization),
                            Db.P("@a", active), Db.P("@id", employeeId.Value)))
                        { cmd.Transaction = tx; cmd.ExecuteNonQuery(); }
                    }
                    else
                    {
                        int roleId;
                        using (var cmd = Db.Command(conn,
                            "SELECT idРоли FROM dbo.DS_Роли WHERE Название = N'Специалист'", null))
                        { cmd.Transaction = tx; roleId = Convert.ToInt32(cmd.ExecuteScalar()); }

                        string login = "spec_" + Guid.NewGuid().ToString("N").Substring(0, 8);
                        string hash = PasswordHasher.Hash("Spec123");

                        int userId;
                        using (var cmd = Db.Command(conn, @"
INSERT INTO dbo.DS_Пользователи (Логин, ХешПароля, ФИО, Телефон, Email, idРоли)
VALUES (@login, @hash, @fio, @phone, @email, @role);
SELECT SCOPE_IDENTITY();",
                            Db.P("@login", login), Db.P("@hash", hash), Db.P("@fio", fio),
                            Db.P("@phone", phone), Db.P("@email", (object)email ?? DBNull.Value),
                            Db.P("@role", roleId)))
                        { cmd.Transaction = tx; userId = Convert.ToInt32(cmd.ExecuteScalar()); }

                        using (var cmd = Db.Command(conn, @"
INSERT INTO dbo.DS_Сотрудники (idПользователя, Должность, Специализация, Активен, ДатаПриема)
VALUES (@uid, @p, @s, @a, CAST(SYSDATETIME() AS date))",
                            Db.P("@uid", userId), Db.P("@p", position),
                            Db.P("@s", specialization), Db.P("@a", active)))
                        { cmd.Transaction = tx; cmd.ExecuteNonQuery(); }
                    }
                    tx.Commit();
                }
                catch { tx.Rollback(); throw; }
            }
        }

        // ----------------------------- Пользователи -------------------------------

        public static List<User> GetUsers(string search)
        {
            const string sql = @"
SELECT u.idПользователя, u.Логин, u.ФИО, u.Телефон, u.Email, u.idРоли,
       r.Название AS Роль, u.Заблокирован, u.ДатаРегистрации, u.ПоследнийВход
FROM dbo.DS_Пользователи u
JOIN dbo.DS_Роли r ON r.idРоли = u.idРоли
WHERE (@s IS NULL OR u.Логин LIKE '%' + @s + '%' OR u.ФИО LIKE '%' + @s + '%')
ORDER BY u.ФИО";

            var list = new List<User>();
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn, sql,
                Db.P("@s", string.IsNullOrWhiteSpace(search) ? (object)DBNull.Value : search)))
            using (var rdr = cmd.ExecuteReader())
                while (rdr.Read())
                    list.Add(MapUser(rdr));
            return list;
        }

        public static void SetUserBlocked(int userId, bool blocked)
        {
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "UPDATE dbo.DS_Пользователи SET Заблокирован=@b WHERE idПользователя=@id",
                Db.P("@b", blocked), Db.P("@id", userId)))
                cmd.ExecuteNonQuery();
        }

        public static void ResetPassword(int userId, string newPassword)
        {
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "UPDATE dbo.DS_Пользователи SET ХешПароля=@h WHERE idПользователя=@id",
                Db.P("@h", PasswordHasher.Hash(newPassword)), Db.P("@id", userId)))
                cmd.ExecuteNonQuery();
        }

        public static void UpdateProfile(int userId, string fio, string phone, string email)
        {
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn,
                "UPDATE dbo.DS_Пользователи SET ФИО=@fio, Телефон=@phone, Email=@email WHERE idПользователя=@id",
                Db.P("@fio", fio), Db.P("@phone", phone),
                Db.P("@email", (object)email ?? DBNull.Value), Db.P("@id", userId)))
                cmd.ExecuteNonQuery();
        }

        public static void ChangePassword(int userId, string objectNewPassword)
        {
            ResetPassword(userId, objectNewPassword);
        }

        // -------------------------------- Отчёты ----------------------------------

        public static ReportPeriodRow GetReportPeriod(DateTime from, DateTime to)        {
            using (var conn = Db.Open())
            using (var cmd = new SqlCommand("dbo.DS_sp_ОтчетЗаПериод", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ДатаС", from.Date);
                cmd.Parameters.AddWithValue("@ДатаПо", to.Date);
                using (var rdr = cmd.ExecuteReader())
                {
                    if (!rdr.Read()) return new ReportPeriodRow();
                    return new ReportPeriodRow
                    {
                        ВсегоЗакрыто = rdr["ВсегоЗакрыто"] == DBNull.Value ? 0 : Convert.ToInt32(rdr["ВсегоЗакрыто"]),
                        Просрочено = rdr["Просрочено"] == DBNull.Value ? 0 : Convert.ToInt32(rdr["Просрочено"]),
                        СреднееЧасов = rdr["СреднееЧасов"] == DBNull.Value ? 0 : Convert.ToDecimal(rdr["СреднееЧасов"])
                    };
                }
            }
        }

        public static List<ReportByTypeRow> GetReportByType(DateTime from, DateTime to)
        {
            const string sql = @"
SELECT tp.Название AS ТипПроблемы,
       COUNT(*) AS Всего,
       SUM(CASE WHEN s.Закрывающий = 1 THEN 1 ELSE 0 END) AS Закрыто,
       SUM(CASE WHEN z.ДатаЗакрытия IS NOT NULL
                 AND z.ДатаЗакрытия > DATEADD(HOUR, tp.НормативЧасов, z.ДатаСоздания)
                THEN 1 ELSE 0 END) AS Просрочено
FROM dbo.DS_Заявки z
JOIN dbo.DS_ТипыПроблем tp ON tp.idТипа = z.idТипа
JOIN dbo.DS_СтатусыЗаявок s ON s.idСтатуса = z.idСтатуса
WHERE CAST(z.ДатаСоздания AS date) BETWEEN @from AND @to
GROUP BY tp.Название
ORDER BY Всего DESC";

            var list = new List<ReportByTypeRow>();
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn, sql,
                Db.P("@from", from.Date), Db.P("@to", to.Date)))
            using (var rdr = cmd.ExecuteReader())
                while (rdr.Read())
                    list.Add(new ReportByTypeRow
                    {
                        ТипПроблемы = rdr["ТипПроблемы"].ToString(),
                        Всего = Convert.ToInt32(rdr["Всего"]),
                        Закрыто = Convert.ToInt32(rdr["Закрыто"]),
                        Просрочено = Convert.ToInt32(rdr["Просрочено"])
                    });
            return list;
        }

        /// <summary>Детальный список выполненных заявок за период.</summary>
        public static List<ReportDetailRow> GetReportDetail(DateTime from, DateTime to)
        {
            var list = new List<ReportDetailRow>();
            using (var conn = Db.Open())
            using (var cmd = new SqlCommand("dbo.DS_sp_ОтчетЗаПериодДетально", conn))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ДатаС", from.Date);
                cmd.Parameters.AddWithValue("@ДатаПо", to.Date);
                using (var rdr = cmd.ExecuteReader())
                    while (rdr.Read())
                        list.Add(new ReportDetailRow
                        {
                            НомерЗаявки = rdr["НомерЗаявки"].ToString(),
                            ТипПроблемы = rdr["ТипПроблемы"].ToString(),
                            Приоритет = rdr["Приоритет"].ToString(),
                            Статус = rdr["Статус"].ToString(),
                            ДатаСоздания = (DateTime)rdr["ДатаСоздания"],
                            ДатаЗакрытия = rdr["ДатаЗакрытия"] as DateTime?,
                            МинутНаВыполнение = rdr["МинутНаВыполнение"] as int?,
                            Просрочена = Convert.ToBoolean(rdr["Просрочена"]),
                            Клиент = rdr["Клиент"].ToString(),
                            Исполнитель = rdr["Исполнитель"].ToString()
                        });
            }
            return list;
        }

        /// <summary>Нагрузка сотрудников из представления DS_vw_НагрузкаСотрудников.</summary>
        public static List<EmployeeLoadRow> GetEmployeeLoad()
        {
            const string sql = @"
SELECT idСотрудника, Сотрудник, Должность, Активен, ВсегоЗаявок,
       ВРаботе, Закрыто, Просрочено
FROM dbo.DS_vw_НагрузкаСотрудников
ORDER BY ВРаботе DESC, ВсегоЗаявок DESC, Сотрудник";

            var list = new List<EmployeeLoadRow>();
            using (var conn = Db.Open())
            using (var cmd = Db.Command(conn, sql))
            using (var rdr = cmd.ExecuteReader())
                while (rdr.Read())
                    list.Add(new EmployeeLoadRow
                    {
                        IdСотрудника = (int)rdr["idСотрудника"],
                        Сотрудник = rdr["Сотрудник"].ToString(),
                        Должность = rdr["Должность"].ToString(),
                        Активен = Convert.ToBoolean(rdr["Активен"]),
                        ВсегоЗаявок = Convert.ToInt32(rdr["ВсегоЗаявок"]),
                        ВРаботе = Convert.ToInt32(rdr["ВРаботе"]),
                        Закрыто = Convert.ToInt32(rdr["Закрыто"]),
                        Просрочено = Convert.ToInt32(rdr["Просрочено"])
                    });
            return list;
        }

        // -------------------------------- Утилиты ---------------------------------

        private static User MapUser(IDataRecord r)
        {
            return new User
            {
                Id = (int)r["idПользователя"],
                Логин = r["Логин"].ToString(),
                ФИО = r["ФИО"].ToString(),
                Телефон = r["Телефон"].ToString(),
                Email = r["Email"] as string,
                IdРоли = (int)r["idРоли"],
                Роль = r["Роль"].ToString(),
                Заблокирован = (bool)r["Заблокирован"],
                ДатаРегистрации = (DateTime)r["ДатаРегистрации"],
                ПоследнийВход = r["ПоследнийВход"] as DateTime?
            };
        }
    }
}
