using System;
using System.Security.Cryptography;
using System.Text;

namespace DeliverySupport.Wpf.Data
{
    /// <summary>
    /// Хеширование паролей.
    /// Новые пароли сохраняются с солью в формате S1$соль$хеш (Base64).
    /// Поддерживается и прежний формат — SHA-256 от строки UTF-16LE без соли:
    /// так сервер вычисляет HASHBYTES('SHA2_256', N'пароль'), поэтому
    /// демонстрационные учётные записи из скрипта БД продолжают работать.
    /// </summary>
    public static class PasswordHasher
    {
        private const string SaltedPrefix = "S1$";
        private const int SaltSize = 16;

        /// <summary>Создаёт хеш нового пароля с криптографической солью.</summary>
        public static string Hash(string password)
        {
            string safe = password ?? string.Empty;
            byte[] salt = new byte[SaltSize];
            using (var rng = RandomNumberGenerator.Create())
                rng.GetBytes(salt);

            byte[] hash = ComputeSaltedHash(safe, salt);
            return SaltedPrefix + Convert.ToBase64String(salt) + "$" + Convert.ToBase64String(hash);
        }

        /// <summary>Проверяет пароль в новом (с солью) или старом (без соли) формате.</summary>
        public static bool Verify(string password, string storedHash)
        {
            if (string.IsNullOrEmpty(storedHash)) return false;
            storedHash = storedHash.Trim();

            if (storedHash.StartsWith(SaltedPrefix, StringComparison.Ordinal))
                return VerifySalted(password ?? string.Empty, storedHash);

            // Обратная совместимость с хешами, созданными HASHBYTES('SHA2_256', N'...').
            return FixedTimeEquals(
                Encoding.ASCII.GetBytes(LegacyHash(password)),
                Encoding.ASCII.GetBytes(storedHash.ToUpperInvariant()));
        }

        /// <summary>Хеш без соли (совместим с SQL Server HASHBYTES).</summary>
        public static string LegacyHash(string password)
        {
            using (var sha = SHA256.Create())
            {
                byte[] bytes = Encoding.Unicode.GetBytes(password ?? string.Empty);
                return ToHex(sha.ComputeHash(bytes));
            }
        }

        /// <summary>Требуется ли обновить хеш до формата с солью после успешного входа.</summary>
        public static bool NeedsRehash(string storedHash)
        {
            return string.IsNullOrEmpty(storedHash)
                || !storedHash.Trim().StartsWith(SaltedPrefix, StringComparison.Ordinal);
        }

        private static bool VerifySalted(string password, string storedHash)
        {
            string[] parts = storedHash.Split('$');
            if (parts.Length != 3) return false;
            try
            {
                byte[] salt = Convert.FromBase64String(parts[1]);
                byte[] expected = Convert.FromBase64String(parts[2]);
                byte[] actual = ComputeSaltedHash(password, salt);
                return FixedTimeEquals(expected, actual);
            }
            catch (FormatException)
            {
                return false;
            }
        }

        private static byte[] ComputeSaltedHash(string password, byte[] salt)
        {
            byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
            byte[] data = new byte[salt.Length + passwordBytes.Length];
            Buffer.BlockCopy(salt, 0, data, 0, salt.Length);
            Buffer.BlockCopy(passwordBytes, 0, data, salt.Length, passwordBytes.Length);

            using (var sha = SHA256.Create())
                return sha.ComputeHash(data);
        }

        private static string ToHex(byte[] hash)
        {
            var sb = new StringBuilder(hash.Length * 2);
            foreach (byte b in hash)
                sb.Append(b.ToString("X2"));
            return sb.ToString();
        }

        private static bool FixedTimeEquals(byte[] a, byte[] b)
        {
            if (a == null || b == null || a.Length != b.Length) return false;
            int diff = 0;
            for (int i = 0; i < a.Length; i++)
                diff |= a[i] ^ b[i];
            return diff == 0;
        }
    }
}
