using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DeliverySupport.Wpf.Data
{
    /// <summary>
    /// Слой доступа к данным: единая точка получения соединения и служебные
    /// методы для выполнения параметризованных команд ADO.NET.
    /// Строка подключения берётся из App.config, но может быть переопределена
    /// на время работы из окна входа (сервер, база, пользователь SQL).
    /// </summary>
    public static class Db
    {
        private const string DefaultConnectionString =
            "data source=stud-mssql.sttec.yar.ru,38325;user id=user92_db;password=user92;" +
            "trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework";

        /// <summary>Строка, заданная пользователем в окне входа; null — использовать App.config.</summary>
        public static string RuntimeConnectionString { get; private set; }

        public static string ConnectionString
        {
            get
            {
                if (!string.IsNullOrWhiteSpace(RuntimeConnectionString))
                    return RuntimeConnectionString;

                var cs = ConfigurationManager.ConnectionStrings["DeliverySupport"];
                if (cs != null && !string.IsNullOrWhiteSpace(cs.ConnectionString))
                    return cs.ConnectionString;
                // Запасная строка на случай отсутствия App.config.
                return DefaultConnectionString;
            }
        }

        /// <summary>Параметры текущего подключения для отображения в окне входа.</summary>
        public static string ServerName => Builder().DataSource;
        public static string DatabaseName => Builder().InitialCatalog;
        public static string SqlUser => Builder().UserID;

        /// <summary>Подключается с указанными параметрами до конца сеанса приложения.</summary>
        public static void UseRuntimeConnection(string server, string database,
            string user, string password)
        {
            RuntimeConnectionString = BuildConnectionString(server, database, user, password);
        }

        /// <summary>Возвращает к строке подключения из App.config.</summary>
        public static void ResetRuntimeConnection()
        {
            RuntimeConnectionString = null;
        }

        public static string BuildConnectionString(string server, string database,
            string user, string password)
        {
            var b = Builder();
            if (!string.IsNullOrWhiteSpace(server)) b.DataSource = server.Trim();
            if (!string.IsNullOrWhiteSpace(database)) b.InitialCatalog = database.Trim();
            b.IntegratedSecurity = false;
            b.UserID = user ?? string.Empty;
            b.Password = password ?? string.Empty;
            b.TrustServerCertificate = true;
            b.MultipleActiveResultSets = true;
            b.ApplicationName = "EntityFramework";
            return b.ConnectionString;
        }

        public static SqlConnection Open()
        {
            var conn = new SqlConnection(ConnectionString);
            conn.Open();
            return conn;
        }

        public static SqlCommand Command(SqlConnection conn, string sql,
            params SqlParameter[] parameters)
        {
            var cmd = new SqlCommand(sql, conn);
            if (parameters != null && parameters.Length > 0)
                cmd.Parameters.AddRange(parameters);
            return cmd;
        }

        public static SqlParameter P(string name, object value)
        {
            return new SqlParameter(name, value ?? DBNull.Value);
        }

        /// <summary>Проверка доступности сервера и базы данных.</summary>
        public static bool TestConnection(out string error)
        {
            return TestConnection(ConnectionString, out error);
        }

        public static bool TestConnection(string connectionString, out string error)
        {
            try
            {
                using (var conn = new SqlConnection(connectionString))
                using (var cmd = new SqlCommand("SELECT 1", conn))
                {
                    conn.Open();
                    cmd.ExecuteScalar();
                }
                error = null;
                return true;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
        }

        private static SqlConnectionStringBuilder Builder()
        {
            try
            {
                return new SqlConnectionStringBuilder(
                    string.IsNullOrWhiteSpace(RuntimeConnectionString)
                        ? (ConfigurationManager.ConnectionStrings["DeliverySupport"]?.ConnectionString
                           ?? DefaultConnectionString)
                        : RuntimeConnectionString);
            }
            catch
            {
                return new SqlConnectionStringBuilder(DefaultConnectionString);
            }
        }
    }
}
