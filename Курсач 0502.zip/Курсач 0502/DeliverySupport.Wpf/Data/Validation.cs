using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace DeliverySupport.Wpf.Data
{
    /// <summary>
    /// Проверка форматов вводимых данных. Правила соответствуют пояснительной
    /// записке: телефон — 11 цифр с кодом 7, логин 4–14 символов, пароль 6–14.
    /// </summary>
    public static class Validation
    {
        private static readonly Regex LoginRegex =
            new Regex(@"^[A-Za-z][A-Za-z0-9_]{3,13}$", RegexOptions.Compiled);

        private static readonly Regex EmailRegex =
            new Regex(@"^[^@\s]+@[^@\s]+\.[A-Za-zА-Яа-я]{2,}$", RegexOptions.Compiled);

        public static string DigitsOnly(string value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            return new string(value.Where(char.IsDigit).ToArray());
        }

        /// <summary>Приводит телефон к виду +7XXXXXXXXXX (11 цифр) или возвращает null.</summary>
        public static string NormalizePhone(string value)
        {
            string digits = DigitsOnly(value);
            if (digits.Length == 11 && digits[0] == '8') digits = "7" + digits.Substring(1);
            if (digits.Length == 10) digits = "7" + digits;
            return digits.Length == 11 && digits[0] == '7' ? "+" + digits : null;
        }

        public static bool IsValidPhone(string value) => NormalizePhone(value) != null;

        public static bool IsValidLogin(string value) =>
            !string.IsNullOrWhiteSpace(value) && LoginRegex.IsMatch(value.Trim());

        public static bool IsValidPassword(string value) =>
            !string.IsNullOrEmpty(value) && value.Length >= 6 && value.Length <= 14;

        public static bool IsValidEmail(string value) =>
            string.IsNullOrWhiteSpace(value) || EmailRegex.IsMatch(value.Trim());

        public static bool IsValidFio(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return false;
            string[] parts = value.Trim().Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            return parts.Length >= 2 && value.Trim().Length >= 5;
        }

        public static bool TryValidatePhone(string value, out string error)
        {
            if (IsValidPhone(value)) { error = null; return true; }
            error = "Телефон должен содержать 11 цифр и начинаться с +7 (например, +7 920 000-00-01).";
            return false;
        }

        public static bool TryValidateLogin(string value, out string error)
        {
            if (IsValidLogin(value)) { error = null; return true; }
            error = "Логин: 4–14 символов, начинается с буквы, допустимы буквы, цифры и подчёркивание.";
            return false;
        }

        public static bool TryValidatePassword(string value, out string error)
        {
            if (IsValidPassword(value)) { error = null; return true; }
            error = "Пароль должен содержать от 6 до 14 символов.";
            return false;
        }

        public static bool TryValidateEmail(string value, out string error)
        {
            if (IsValidEmail(value)) { error = null; return true; }
            error = "Укажите корректный адрес электронной почты.";
            return false;
        }
    }
}
