using System;
using System.Windows;
using System.Windows.Threading;
using DeliverySupport.Wpf.Views;

namespace DeliverySupport.Wpf
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var splash = new SplashWindow();
            splash.Show();

            var timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(1200) };
            timer.Tick += (s, args) =>
            {
                timer.Stop();
                var login = new LoginWindow();
                login.Show();
                splash.Close();
            };
            timer.Start();
        }
    }
}
