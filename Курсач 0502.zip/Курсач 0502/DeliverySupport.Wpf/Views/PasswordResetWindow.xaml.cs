using System.Windows;

namespace DeliverySupport.Wpf.Views
{
    public partial class PasswordResetWindow : Window
    {
        public string NewPassword { get; private set; }

        public PasswordResetWindow(string userName)
        {
            InitializeComponent();
            lblUser.Text = "Пользователь: " + userName;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            lblError.Visibility = Visibility.Collapsed;
            if (txtPwd.Password.Length < 6)
            { ShowError("Пароль должен содержать минимум 6 символов."); return; }
            if (txtPwd.Password != txtPwd2.Password)
            { ShowError("Пароли не совпадают."); return; }

            NewPassword = txtPwd.Password;
            DialogResult = true;
            Close();
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void ShowError(string t)
        {
            lblError.Text = t;
            lblError.Visibility = Visibility.Visible;
        }
    }
}
