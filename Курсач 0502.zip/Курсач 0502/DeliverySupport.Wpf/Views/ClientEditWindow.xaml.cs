using System;
using System.Windows;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Views
{
    public partial class ClientEditWindow : Window
    {
        private readonly Client _client;

        public ClientEditWindow(Client client)
        {
            InitializeComponent();
            _client = client;
            lblLogin.Text = "Учётная запись: " + client.ФИО;
            txtFio.Text = client.ФИО;
            txtPhone.Text = client.Телефон;
            txtEmail.Text = client.Email;
            txtOrganization.Text = client.Организация;
            txtAddress.Text = client.Адрес;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            lblError.Visibility = Visibility.Collapsed;
            if (txtFio.Text.Trim().Length < 5)
            { ShowError("Укажите ФИО полностью."); return; }
            if (txtPhone.Text.Trim().Length < 5)
            { ShowError("Укажите телефон."); return; }

            try
            {
                Repository.UpdateClient(_client.Id, txtFio.Text.Trim(), txtPhone.Text.Trim(),
                    txtEmail.Text.Trim(), txtAddress.Text.Trim(), txtOrganization.Text.Trim());
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                ShowError("Не удалось сохранить: " + ex.Message);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void ShowError(string t)
        {
            lblError.Text = t;
            lblError.Visibility = Visibility.Visible;
        }
    }
}
