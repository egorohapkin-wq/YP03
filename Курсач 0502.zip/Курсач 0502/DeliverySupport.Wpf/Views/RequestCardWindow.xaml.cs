using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Views
{
    public partial class RequestCardWindow : Window
    {
        /// <summary>
        /// Допустимые переходы статусов. Те же правила контролирует
        /// хранимая процедура DS_sp_ИзменитьСтатусЗаявки (THROW 51003).
        /// </summary>
        private static readonly Dictionary<string, string[]> Transitions =
            new Dictionary<string, string[]>
            {
                { "Новая",           new[] { "Назначена", "Отменена" } },
                { "Назначена",       new[] { "В работе", "Отменена" } },
                { "В работе",        new[] { "Ожидает клиента", "Решена", "Отменена" } },
                { "Ожидает клиента", new[] { "В работе", "Решена", "Отменена" } },
                { "Решена",          new[] { "Закрыта", "В работе" } }
            };

        private int? _requestId;
        private bool _isNew;
        private string _currentResult;
        private string _currentStatus;
        private bool _canClientCancel;

        public RequestCardWindow(int? requestId)
        {
            InitializeComponent();
            _requestId = requestId;
            _isNew = !requestId.HasValue;

            Loaded += (s, e) => Build();
        }

        private void Build()
        {
            try
            {
                if (_isNew) BuildCreateMode();
                else BuildViewMode();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки карточки: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ------------------------------ Создание ---------------------------------

        private void BuildCreateMode()
        {
            lblTitle.Text = "Новая заявка";
            lblSubtitle.Text = "Регистрация обращения клиента";
            lblStatusBadge.Text = "Новая";
            panelCreate.Visibility = Visibility.Visible;
            panelView.Visibility = Visibility.Collapsed;
            tabActions.Visibility = Visibility.Collapsed;
            tabHistory.Visibility = Visibility.Collapsed;
            btnSave.Visibility = Visibility.Visible;
            tabs.SelectedItem = tabMain;
            SetTabHeadersVisible(false);

            var types = Repository.GetProblemTypes();
            cmbType.ItemsSource = types;
            cmbType.DisplayMemberPath = "Название";
            if (types.Count > 0) cmbType.SelectedIndex = 0;

            var priorities = Repository.GetPriorities();
            cmbPriority.ItemsSource = priorities;
            cmbPriority.DisplayMemberPath = "Название";
            if (priorities.Count > 0) cmbPriority.SelectedIndex = 0;

            if (Session.IsClient)
            {
                // Клиент создаёт заявку от своего имени — поле клиента фиксировано.
                var me = Repository.GetClients(null).FirstOrDefault(c => c.Id == Session.ClientId);
                if (me != null) cmbClient.ItemsSource = new[] { me };
                cmbClient.DisplayMemberPath = "ФИО";
                cmbClient.SelectedIndex = 0;
                cmbClient.IsEnabled = false;
            }
            else
            {
                var clients = Repository.GetClients(null);
                cmbClient.ItemsSource = clients;
                cmbClient.DisplayMemberPath = "ФИО";
                if (clients.Count > 0) cmbClient.SelectedIndex = 0;
            }
        }

        // ----------------------------- Просмотр ----------------------------------

        private void BuildViewMode()
        {
            var r = Repository.GetRequestDetail(_requestId.Value);
            if (r == null)
            {
                MessageBox.Show("Заявка не найдена.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                Close();
                return;
            }

            lblTitle.Text = "Заявка " + r.Номер;
            lblSubtitle.Text = "Создана " + r.ДатаСоздания.ToString("dd.MM.yyyy HH:mm");
            lblStatusBadge.Text = r.Статус;
            _currentStatus = r.Статус;

            panelCreate.Visibility = Visibility.Collapsed;
            panelView.Visibility = Visibility.Visible;
            tabActions.Visibility = Visibility.Visible;
            tabHistory.Visibility = Visibility.Visible;
            btnSave.Visibility = Visibility.Collapsed;
            SetTabHeadersVisible(true);

            vClient.Text = r.Клиент;
            vPhone.Text = r.Телефон;
            vAddress.Text = string.IsNullOrWhiteSpace(r.Адрес) ? "—" : r.Адрес;
            vCreated.Text = r.ДатаСоздания.ToString("dd.MM.yyyy HH:mm");
            vClosed.Text = r.ДатаЗакрытия?.ToString("dd.MM.yyyy HH:mm") ?? "—";
            vExecutor.Text = string.IsNullOrWhiteSpace(r.Исполнитель) ? "не назначен" : r.Исполнитель;
            vType.Text = r.ТипПроблемы;
            vPriority.Text = r.Приоритет;
            vDescription.Text = r.ОписаниеПроблемы;
            vResult.Text = string.IsNullOrWhiteSpace(r.Результат) ? "—" : r.Результат;
            _currentResult = r.Результат;

            // Клиент может отменить только новую заявку.
            _canClientCancel = Session.IsClient && r.Статус == "Новая"
                && (!Session.ClientId.HasValue || r.IdКлиента == Session.ClientId.Value);
            btnCancelRequest.Visibility = _canClientCancel
                ? Visibility.Visible : Visibility.Collapsed;

            // Доступность вкладки «Обработка».
            bool canProcess = Session.CanManageRequests;
            if (Session.IsSpecialist && r.IdИсполнителя != Session.EmployeeId)
                canProcess = false;
            bool canAssign = Session.IsAdmin || Session.IsOperator;
            tabActions.Visibility = canProcess ? Visibility.Visible : Visibility.Collapsed;

            var employees = Repository.GetEmployees(true);
            cmbExecutor.ItemsSource = employees;
            cmbExecutor.DisplayMemberPath = "ФИО";
            cmbExecutor.SelectedValuePath = "Id";
            if (r.IdИсполнителя.HasValue) cmbExecutor.SelectedValue = r.IdИсполнителя.Value;
            btnAssign.IsEnabled = canAssign;
            cmbExecutor.IsEnabled = canAssign;

            var statuses = Repository.GetStatuses();
            if (Session.IsSpecialist)
            {
                var allowed = new[] { "В работе", "Ожидает клиента", "Решена", "Закрыта" };
                statuses = statuses.Where(s => allowed.Contains(s.Название)).ToList();
            }
            // Показываем только статусы, допустимые для текущего состояния заявки.
            statuses = statuses
                .Where(s => IsTransitionAllowed(_currentStatus, s.Название))
                .ToList();

            cmbNewStatus.ItemsSource = statuses;
            cmbNewStatus.DisplayMemberPath = "Название";
            cmbNewStatus.SelectedIndex = statuses.Count > 0 ? 0 : -1;
            cmbNewStatus.IsEnabled = statuses.Count > 0;
            btnChangeStatus.IsEnabled = statuses.Count > 0;

            LoadHistory();
        }

        private static bool IsTransitionAllowed(string from, string to)
        {
            if (string.IsNullOrEmpty(from) || string.IsNullOrEmpty(to)) return false;
            return Transitions.TryGetValue(from, out string[] allowed)
                   && allowed.Contains(to);
        }

        private void LoadHistory()
        {
            gridHistory.ItemsSource = Repository.GetHistory(_requestId.Value);
        }

        /// <summary>
        /// В режиме создания доступна только одна вкладка, поэтому полосу
        /// заголовков скрываем — иначе она выглядит как отдельная кнопка.
        /// </summary>
        private void SetTabHeadersVisible(bool visible)
        {
            tabs.ApplyTemplate();
            if (tabs.Template.FindName("HeaderPanel", tabs) is FrameworkElement header)
                header.Visibility = visible ? Visibility.Visible : Visibility.Collapsed;
        }

        // ------------------------------ Действия ---------------------------------

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int clientId;
                if (Session.IsClient)
                {
                    if (!Session.ClientId.HasValue)
                    {
                        MessageBox.Show("Для вашей учётной записи не найден профиль клиента.",
                            "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                        return;
                    }
                    clientId = Session.ClientId.Value;
                }
                else
                {
                    var client = cmbClient.SelectedItem as Client;
                    if (client == null)
                    {
                        MessageBox.Show("Выберите клиента.", "Проверка",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }
                    clientId = client.Id;
                }

                var type = cmbType.SelectedItem as ReferenceItem;
                var priority = cmbPriority.SelectedItem as ReferenceItem;
                string description = txtDescriptionCreate.Text.Trim();

                if (type == null || priority == null)
                {
                    MessageBox.Show("Выберите тип проблемы и приоритет.", "Проверка",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                if (description.Length < 10)
                {
                    MessageBox.Show("Опишите проблему подробнее (не менее 10 символов).", "Проверка",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                string number;
                int id = Repository.CreateRequest(clientId, type.Id, priority.Id,
                    Session.CurrentUser.Id, description, out number);

                MessageBox.Show($"Заявка {number} успешно создана.", "Готово",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                // Переключаем окно в режим просмотра созданной заявки.
                _isNew = false;
                _requestId = id;
                Build();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось создать заявку: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnAssign_Click(object sender, RoutedEventArgs e)
        {
            if (!_requestId.HasValue) return;
            var emp = cmbExecutor.SelectedItem as Employee;
            if (emp == null)
            {
                MessageBox.Show("Выберите сотрудника.", "Назначение",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            try
            {
                Repository.AssignExecutor(_requestId.Value, emp.Id, Session.CurrentUser.Id);
                MessageBox.Show("Исполнитель назначен.", "Готово",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                Build();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка назначения: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnChangeStatus_Click(object sender, RoutedEventArgs e)
        {
            if (!_requestId.HasValue) return;
            if (!btnChangeStatus.IsEnabled)
            {
                MessageBox.Show("Для заявки в текущем статусе нет доступных переходов.",
                    "Статус", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var status = cmbNewStatus.SelectedItem as ReferenceItem;
            if (status == null)
            {
                MessageBox.Show("Выберите статус.", "Статус",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (status.Название == "Закрыта"
                && string.IsNullOrWhiteSpace(txtResult.Text)
                && string.IsNullOrWhiteSpace(_currentResult))
            {
                MessageBox.Show("Перед закрытием заявки заполните результат решения.",
                    "Статус", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            try
            {
                Repository.ChangeStatus(_requestId.Value, status.Название,
                    Session.CurrentUser.Id, txtComment.Text.Trim(), txtResult.Text.Trim());
                MessageBox.Show("Статус изменён.", "Готово",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                txtComment.Clear();
                txtResult.Clear();
                Build();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка изменения статуса: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancelRequest_Click(object sender, RoutedEventArgs e)
        {
            if (!_requestId.HasValue || !_canClientCancel) return;
            if (MessageBox.Show(this, "Отменить заявку? Действие нельзя отменить.",
                    "Отмена заявки", MessageBoxButton.YesNo, MessageBoxImage.Question)
                != MessageBoxResult.Yes) return;
            try
            {
                Repository.ChangeStatus(_requestId.Value, "Отменена",
                    Session.CurrentUser.Id, "Заявка отменена клиентом", null);
                MessageBox.Show("Заявка отменена.", "Готово",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                Build();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось отменить заявку: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = !_isNew;
            Close();
        }
    }
}
