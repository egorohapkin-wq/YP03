using System;
using System.Windows;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Views
{
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
            Loaded += (s, e) => txtLogin.Focus();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            lblError.Visibility = Visibility.Collapsed;
            string login = txtLogin.Text.Trim();
            string pwd = txtPassword.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(pwd))
            {
                ShowError("Введите логин и пароль.");
                return;
            }

            try
            {
                btnLogin.IsEnabled = false;

                User user = Repository.Authenticate(login, pwd);
                if (user == null)
                {
                    ShowError("Неверный логин или пароль.");
                    return;
                }

                Session.CurrentUser = user;
                Repository.UpdateLastLogin(user.Id);
                Repository.LoadProfileLinks(user.Id, user.Роль);

                var main = new MainWindow();
                main.Show();
                Close();
            }
            catch (Exception ex)
            {
                ShowError("Ошибка подключения: " + ex.Message);
            }
            finally
            {
                btnLogin.IsEnabled = true;
            }
        }

        private void BtnRegister_Click(object sender, RoutedEventArgs e)
        {
            var reg = new RegisterWindow { Owner = this };
            if (reg.ShowDialog() == true)
                ShowInfo("Регистрация завершена. Теперь можно войти в систему.");
        }

        private void ShowError(string text)
        {
            lblError.Text = text;
            lblError.Visibility = Visibility.Visible;
        }

        private void ShowInfo(string text)
        {
            MessageBox.Show(this, text, "Регистрация",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }
    }
}
