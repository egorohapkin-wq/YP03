using System;
using System.Data.SqlClient;
using System.Windows;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Views
{
    public partial class ProblemTypeEditWindow : Window
    {
        private readonly ReferenceItem _item;

        public ProblemTypeEditWindow(ReferenceItem item)
        {
            InitializeComponent();
            _item = item;
            if (item == null)
            {
                lblTitle.Text = "Новый тип проблемы";
                txtHours.Text = "24";
            }
            else
            {
                lblTitle.Text = "Тип проблемы";
                txtName.Text = item.Название;
                txtHours.Text = item.Доп1;
                txtDescription.Text = item.Доп2;
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            lblError.Visibility = Visibility.Collapsed;
            string name = txtName.Text.Trim();
            if (name.Length < 3) { ShowError("Укажите название."); return; }

            int hours;
            if (!int.TryParse(txtHours.Text.Trim(), out hours) || hours < 1 || hours > 720)
            { ShowError("Норматив должен быть числом от 1 до 720."); return; }

            try
            {
                if (Repository.ProblemTypeExists(name, _item == null ? (int?)null : _item.Id))
                {
                    ShowError("Тип проблемы «" + name + "» уже есть в справочнике.");
                    return;
                }

                if (_item == null)
                    Repository.AddProblemType(name, hours, txtDescription.Text.Trim());
                else
                    Repository.UpdateProblemType(_item.Id, name, hours, txtDescription.Text.Trim());

                DialogResult = true;
                Close();
            }
            catch (SqlException ex) when (ex.Number == 2601 || ex.Number == 2627)
            {
                ShowError("Тип проблемы с таким названием уже есть в справочнике.");
            }
            catch (Exception ex)
            {
                ShowError("Не удалось сохранить: " + ex.Message);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void ShowError(string t)
        {
            lblError.Text = t;
            lblError.Visibility = Visibility.Visible;
        }
    }
}
