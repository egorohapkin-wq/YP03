using System.Windows;
using DeliverySupport.Wpf.Data;

namespace DeliverySupport.Wpf.Views
{
    public partial class AboutWindow : Window
    {
        public AboutWindow()
        {
            InitializeComponent();
            lblConnection.Text = "Сервер: " + Db.ServerName +
                                 "\nБаза данных: " + Db.DatabaseName +
                                 "\nПользователь SQL: " + Db.SqlUser;
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e) => Close();
    }
}
