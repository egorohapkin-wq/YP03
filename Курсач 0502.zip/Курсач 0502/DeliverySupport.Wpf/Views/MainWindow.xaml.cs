using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Views.Pages;

namespace DeliverySupport.Wpf.Views
{
    public partial class MainWindow : Window
    {
        private readonly DispatcherTimer _clock = new DispatcherTimer();

        public MainWindow()
        {
            InitializeComponent();

            lblUser.Text = Session.CurrentUser?.ФИО;
            lblRole.Text = Session.CurrentUser?.Роль;

            ApplyRolePermissions();

            _clock.Interval = TimeSpan.FromSeconds(30);
            _clock.Tick += (s, e) => UpdateClock();
            _clock.Start();
            UpdateClock();

            Navigate("requests");
        }

        private void ApplyRolePermissions()
        {
            // Клиент видит только свои заявки и профиль.
            navClients.Visibility = Session.CanManageRequests ? Visibility.Visible : Visibility.Collapsed;
            navEmployees.Visibility = Session.IsAdmin ? Visibility.Visible : Visibility.Collapsed;
            navReports.Visibility = Session.CanManageRequests ? Visibility.Visible : Visibility.Collapsed;
            navUsers.Visibility = Session.IsAdmin ? Visibility.Visible : Visibility.Collapsed;
            navReferences.Visibility = Session.IsAdmin ? Visibility.Visible : Visibility.Collapsed;
        }

        private void UpdateClock()
        {
            lblClock.Text = DateTime.Now.ToString("dd.MM.yyyy  HH:mm");
        }

        private void Nav_Click(object sender, RoutedEventArgs e)
        {
            var rb = sender as RadioButton;
            if (rb?.Tag is string key) Navigate(key);
        }

        private void Navigate(string key)
        {
            UserControl page;
            switch (key)
            {
                case "clients": page = new ClientsPage(); lblPageTitle.Text = "Клиенты"; break;
                case "employees": page = new EmployeesPage(); lblPageTitle.Text = "Сотрудники"; break;
                case "reports": page = new ReportsPage(); lblPageTitle.Text = "Отчёты"; break;
                case "users": page = new UsersPage(); lblPageTitle.Text = "Пользователи"; break;
                case "references": page = new ReferencesPage(); lblPageTitle.Text = "Справочники"; break;
                case "profile": page = new ProfilePage(); lblPageTitle.Text = "Профиль"; break;
                default: page = new RequestsPage(); lblPageTitle.Text = "Заявки"; break;
            }
            contentHost.Content = page;
        }

        // --------------------------- Горячие клавиши -----------------------------

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.F5)
            {
                RefreshCurrentPage();
                e.Handled = true;
            }
            else if (e.Key == Key.N && Keyboard.Modifiers == ModifierKeys.Control)
            {
                if (Session.IsClient || Session.IsAdmin || Session.IsOperator)
                {
                    var card = new RequestCardWindow(null) { Owner = this };
                    if (card.ShowDialog() == true) RefreshCurrentPage();
                }
                e.Handled = true;
            }
            else if (e.Key == Key.F && Keyboard.Modifiers == ModifierKeys.Control)
            {
                var requests = contentHost.Content as RequestsPage;
                if (requests != null) requests.FocusSearch();
                else Navigate("requests");
                e.Handled = true;
            }
            else if (e.Key == Key.Escape)
            {
                Close();
            }
        }

        private void RefreshCurrentPage()
        {
            var requests = contentHost.Content as RequestsPage;
            if (requests != null) { requests.RefreshData(); return; }
            var reports = contentHost.Content as ReportsPage;
            if (reports != null) { reports.RefreshData(); return; }
        }

        // ------------------------------ Окна -------------------------------------

        private void BtnAbout_Click(object sender, RoutedEventArgs e)
        {
            var w = new AboutWindow { Owner = this };
            w.ShowDialog();
        }

        private void BtnLogout_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show(this, "Выйти из системы?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            Session.Clear();
            var login = new LoginWindow();
            login.Show();
            Close();
        }
    }
}
