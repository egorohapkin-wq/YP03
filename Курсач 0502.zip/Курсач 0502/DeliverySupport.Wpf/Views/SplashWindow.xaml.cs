using System.Windows;

namespace DeliverySupport.Wpf.Views
{
    public partial class SplashWindow : Window
    {
        public SplashWindow()
        {
            InitializeComponent();
        }
    }
}
