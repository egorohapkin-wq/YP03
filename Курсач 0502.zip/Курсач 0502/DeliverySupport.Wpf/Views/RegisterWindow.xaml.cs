using System;
using System.Windows;
using DeliverySupport.Wpf.Data;

namespace DeliverySupport.Wpf.Views
{
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            lblError.Visibility = Visibility.Collapsed;

            string fio = txtFio.Text.Trim();
            string login = txtLogin.Text.Trim();
            string pwd = txtPassword.Password;
            string pwd2 = txtPassword2.Password;
            string phone = txtPhone.Text.Trim();

            if (!Validation.IsValidFio(fio))
            { ShowError("Укажите ФИО полностью (минимум имя и фамилия)."); return; }
            if (!Validation.TryValidateLogin(login, out string loginError))
            { ShowError(loginError); return; }
            if (!Validation.TryValidatePassword(pwd, out string pwdError))
            { ShowError(pwdError); return; }
            if (pwd != pwd2)
            { ShowError("Пароли не совпадают."); return; }
            if (!Validation.TryValidatePhone(phone, out string phoneError))
            { ShowError(phoneError); return; }
            if (!Validation.TryValidateEmail(txtEmail.Text.Trim(), out string emailError))
            { ShowError(emailError); return; }

            try
            {
                if (Repository.LoginExists(login))
                { ShowError("Пользователь с таким логином уже существует."); return; }

                Repository.RegisterClient(login, pwd, fio, phone,
                    txtEmail.Text.Trim(), txtAddress.Text.Trim(), txtOrganization.Text.Trim());

                DialogResult = true;
                Close();
            }
            catch (System.Data.SqlClient.SqlException ex) when (ex.Number == 2601 || ex.Number == 2627)
            {
                ShowError("Пользователь с таким логином или телефоном уже зарегистрирован.");
            }
            catch (Exception ex)
            {
                ShowError("Не удалось зарегистрироваться: " + ex.Message);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void ShowError(string text)
        {
            lblError.Text = text;
            lblError.Visibility = Visibility.Visible;
        }
    }
}
