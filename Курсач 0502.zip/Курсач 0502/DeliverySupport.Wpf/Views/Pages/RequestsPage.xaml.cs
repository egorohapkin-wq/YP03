using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Views.Pages
{
    public partial class RequestsPage : UserControl
    {
        private bool _loading;

        public RequestsPage()
        {
            InitializeComponent();

            if (Session.IsClient)
            {
                btnCreate.Visibility = Visibility.Visible;
                btnAssign.Visibility = Visibility.Collapsed;
                lblScope.Text = "Показаны только ваши заявки.";
            }
            else if (Session.IsSpecialist)
            {
                btnCreate.Visibility = Visibility.Collapsed;
                btnAssign.Visibility = Visibility.Collapsed;
                lblScope.Text = "Показаны только заявки, назначенные на вас.";
            }
            else
            {
                btnCreate.Visibility = Session.CanManageRequests ? Visibility.Visible : Visibility.Collapsed;
                btnAssign.Visibility = Session.IsAdmin || Session.IsOperator ? Visibility.Visible : Visibility.Collapsed;
                lblScope.Text = "Все заявки службы поддержки.";
            }

            LoadStatuses();
            LoadExecutors();
            LoadData();
        }

        /// <summary>Горячая клавиша F5.</summary>
        public void RefreshData() => LoadData();

        /// <summary>Горячая клавиша Ctrl+F.</summary>
        public void FocusSearch()
        {
            txtSearch.Focus();
            txtSearch.SelectAll();
        }

        private void LoadStatuses()
        {
            _loading = true;
            try
            {
                var statuses = Repository.GetStatuses();
                var items = new List<ReferenceItem>
                {
                    new ReferenceItem { Id = -1, Название = "Все статусы" }
                };
                items.AddRange(statuses);

                cmbStatus.ItemsSource = items;
                cmbStatus.DisplayMemberPath = "Название";
                cmbStatus.SelectedIndex = 0;
            }
            finally { _loading = false; }
        }

        private void LoadExecutors()
        {
            // Фильтр по исполнителю имеет смысл только для администратора и оператора:
            // специалист и так видит лишь назначенные на него заявки.
            if (!(Session.IsAdmin || Session.IsOperator))
            {
                lblExecutor.Visibility = Visibility.Collapsed;
                cmbExecutor.Visibility = Visibility.Collapsed;
                return;
            }

            _loading = true;
            try
            {
                var items = new List<Employee>
                {
                    new Employee { Id = -1, ФИО = "Все исполнители" }
                };
                items.AddRange(Repository.GetEmployees(true));

                cmbExecutor.ItemsSource = items;
                cmbExecutor.DisplayMemberPath = "ФИО";
                cmbExecutor.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить список исполнителей: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally { _loading = false; }
        }

        private void LoadData()
        {
            try
            {
                int? clientId = Session.IsClient ? Session.ClientId : (int?)null;
                int? statusId = null;
                if (cmbStatus.SelectedItem is ReferenceItem ri && ri.Id > 0)
                    statusId = ri.Id;

                int? execId = null;
                if (Session.IsSpecialist)
                {
                    execId = Session.EmployeeId ?? -1;
                }
                else if ((Session.IsAdmin || Session.IsOperator)
                         && cmbExecutor.SelectedItem is Employee emp && emp.Id > 0)
                {
                    execId = emp.Id;
                }

                string search = txtSearch.Text.Trim();
                DateTime? from = dpFrom.SelectedDate;
                DateTime? to = dpTo.SelectedDate;

                if (from.HasValue && to.HasValue && from.Value.Date > to.Value.Date)
                {
                    MessageBox.Show("Дата начала больше даты окончания.", "Фильтр",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                var list = Repository.GetRequests(clientId, statusId, execId,
                    search, from, to);
                grid.ItemsSource = list;
                lblEmpty.Visibility = list.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить заявки: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Filter_Changed(object sender, EventArgs e)
        {
            if (_loading) return;
            LoadData();
        }

        private void FilterDate_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (_loading) return;
            LoadData();
        }

        private void BtnReset_Click(object sender, RoutedEventArgs e)
        {
            _loading = true;
            txtSearch.Text = "";
            cmbStatus.SelectedIndex = 0;
            if (cmbExecutor.Visibility == Visibility.Visible)
                cmbExecutor.SelectedIndex = 0;
            dpFrom.SelectedDate = null;
            dpTo.SelectedDate = null;
            _loading = false;
            LoadData();
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e) => LoadData();

        private void BtnCreate_Click(object sender, RoutedEventArgs e)
        {
            var card = new RequestCardWindow(null) { Owner = Window.GetWindow(this) };
            if (card.ShowDialog() == true) LoadData();
        }

        private void BtnAssign_Click(object sender, RoutedEventArgs e)
        {
            var item = grid.SelectedItem as RequestItem;
            if (item == null)
            {
                MessageBox.Show("Выберите заявку в списке.", "Назначение исполнителя",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var card = new RequestCardWindow(item.Id) { Owner = Window.GetWindow(this) };
            if (card.ShowDialog() == true) LoadData();
        }

        private void Grid_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var item = grid.SelectedItem as RequestItem;
            if (item == null) return;
            var card = new RequestCardWindow(item.Id) { Owner = Window.GetWindow(this) };
            if (card.ShowDialog() == true) LoadData();
        }
    }
}
