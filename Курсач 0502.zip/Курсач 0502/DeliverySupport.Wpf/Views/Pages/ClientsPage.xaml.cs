using System;
using System.Windows;
using System.Windows.Controls;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Views.Pages
{
    public partial class ClientsPage : UserControl
    {
        public ClientsPage()
        {
            InitializeComponent();
            Loaded += (s, e) => LoadData();
        }

        private void LoadData()
        {
            try
            {
                grid.ItemsSource = Repository.GetClients(txtSearch.Text.Trim());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить клиентов: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e) => LoadData();

        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) => LoadData();

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var c = grid.SelectedItem as Client;
            if (c == null)
            {
                MessageBox.Show("Выберите клиента.", "Изменение данных",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dlg = new ClientEditWindow(c) { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true) LoadData();
        }
    }
}
