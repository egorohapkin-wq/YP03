using System;
using System.Windows;
using System.Windows.Controls;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Views.Pages
{
    public partial class EmployeesPage : UserControl
    {
        public EmployeesPage()
        {
            InitializeComponent();
            chkOnlyActive.IsChecked = true;
            Loaded += (s, e) => LoadData();
        }

        private void LoadData()
        {
            try
            {
                grid.ItemsSource = Repository.GetEmployees(chkOnlyActive.IsChecked == true);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить сотрудников: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e) => LoadData();
        private void Chk_Changed(object sender, RoutedEventArgs e) => LoadData();

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new EmployeeEditWindow(null) { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true) LoadData();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var emp = grid.SelectedItem as Employee;
            if (emp == null)
            {
                MessageBox.Show("Выберите сотрудника.", "Изменение",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var dlg = new EmployeeEditWindow(emp) { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true) LoadData();
        }
    }
}
