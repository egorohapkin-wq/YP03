using System;
using System.Windows;
using System.Windows.Controls;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Views.Pages
{
    public partial class ReferencesPage : UserControl
    {
        public ReferencesPage()
        {
            InitializeComponent();
            Loaded += (s, e) => LoadData();
        }

        private void LoadData()
        {
            try
            {
                grid.ItemsSource = Repository.GetProblemTypes();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить справочник: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new ProblemTypeEditWindow(null) { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true) LoadData();
        }

        private void BtnEdit_Click(object sender, RoutedEventArgs e)
        {
            var item = grid.SelectedItem as ReferenceItem;
            if (item == null)
            {
                MessageBox.Show("Выберите запись.", "Справочник",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            var dlg = new ProblemTypeEditWindow(item) { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true) LoadData();
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var item = grid.SelectedItem as ReferenceItem;
            if (item == null)
            {
                MessageBox.Show("Выберите запись.", "Справочник",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (MessageBox.Show($"Удалить тип проблемы «{item.Название}»?",
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;

            try
            {
                Repository.DeleteProblemType(item.Id);
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось удалить запись. Возможно, по ней уже есть заявки.\n\n" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
