using System;
using System.Windows;
using System.Windows.Controls;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Views.Pages
{
    public partial class UsersPage : UserControl
    {
        public UsersPage()
        {
            InitializeComponent();
            Loaded += (s, e) => LoadData();
        }

        private void LoadData()
        {
            try
            {
                grid.ItemsSource = Repository.GetUsers(txtSearch.Text.Trim());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось загрузить пользователей: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e) => LoadData();
        private void TxtSearch_TextChanged(object sender, TextChangedEventArgs e) => LoadData();

        private void BtnResetPwd_Click(object sender, RoutedEventArgs e)
        {
            var u = grid.SelectedItem as User;
            if (u == null)
            {
                MessageBox.Show("Выберите пользователя.", "Сброс пароля",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dlg = new PasswordResetWindow(u.ФИО) { Owner = Window.GetWindow(this) };
            if (dlg.ShowDialog() == true)
            {
                Repository.ResetPassword(u.Id, dlg.NewPassword);
                MessageBox.Show("Пароль изменён.", "Готово",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void BtnToggleBlock_Click(object sender, RoutedEventArgs e)
        {
            var u = grid.SelectedItem as User;
            if (u == null)
            {
                MessageBox.Show("Выберите пользователя.", "Блокировка",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (u.Id == Session.CurrentUser.Id)
            {
                MessageBox.Show("Нельзя заблокировать собственную учётную запись.",
                    "Блокировка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            bool target = !u.Заблокирован;
            string action = target ? "заблокировать" : "разблокировать";
            if (MessageBox.Show($"Действительно {action} пользователя «{u.ФИО}»?",
                    "Подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                Repository.SetUserBlocked(u.Id, target);
                LoadData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка: " + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
