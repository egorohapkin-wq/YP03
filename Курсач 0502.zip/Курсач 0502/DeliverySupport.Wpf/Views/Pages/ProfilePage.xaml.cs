using System;
using System.Windows;
using System.Windows.Controls;
using DeliverySupport.Wpf.Data;

namespace DeliverySupport.Wpf.Views.Pages
{
    public partial class ProfilePage : UserControl
    {
        public ProfilePage()
        {
            InitializeComponent();
            var u = Session.CurrentUser;
            vLogin.Text = u.Логин;
            vRole.Text = u.Роль;
            txtFio.Text = u.ФИО;
            txtPhone.Text = u.Телефон;
            txtEmail.Text = u.Email;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            lblInfo.Visibility = Visibility.Collapsed;
            if (txtFio.Text.Trim().Length < 5)
            {
                MessageBox.Show("Укажите ФИО полностью.", "Профиль",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            try
            {
                Repository.UpdateProfile(Session.CurrentUser.Id, txtFio.Text.Trim(),
                    txtPhone.Text.Trim(), txtEmail.Text.Trim());
                Session.CurrentUser.ФИО = txtFio.Text.Trim();
                Session.CurrentUser.Телефон = txtPhone.Text.Trim();
                Session.CurrentUser.Email = txtEmail.Text.Trim();
                lblInfo.Text = "Данные сохранены.";
                lblInfo.Visibility = Visibility.Visible;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить: " + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnChangePwd_Click(object sender, RoutedEventArgs e)
        {
            lblError.Visibility = Visibility.Collapsed;

            try
            {
                var check = Repository.Authenticate(Session.CurrentUser.Логин, txtCurrent.Password);
                if (check == null)
                {
                    ShowError("Текущий пароль указан неверно.");
                    return;
                }
            }
            catch (Exception ex)
            {
                ShowError(ex.Message);
                return;
            }

            if (txtNew.Password.Length < 6)
            { ShowError("Новый пароль должен содержать минимум 6 символов."); return; }
            if (txtNew.Password != txtNew2.Password)
            { ShowError("Новые пароли не совпадают."); return; }

            try
            {
                Repository.ChangePassword(Session.CurrentUser.Id, txtNew.Password);
                txtCurrent.Clear(); txtNew.Clear(); txtNew2.Clear();
                MessageBox.Show("Пароль изменён.", "Профиль",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                ShowError("Не удалось изменить пароль: " + ex.Message);
            }
        }

        private void ShowError(string t)
        {
            lblError.Text = t;
            lblError.Visibility = Visibility.Visible;
        }
    }
}
