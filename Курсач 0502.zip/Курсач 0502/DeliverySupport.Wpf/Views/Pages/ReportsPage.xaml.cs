using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Views.Pages
{
    public partial class ReportsPage : UserControl
    {
        private List<ReportDetailRow> _details = new List<ReportDetailRow>();
        private List<EmployeeLoadRow> _load = new List<EmployeeLoadRow>();
        private List<ReportByTypeRow> _byType = new List<ReportByTypeRow>();
        private ReportPeriodRow _period = new ReportPeriodRow();

        public ReportsPage()
        {
            InitializeComponent();
            dpFrom.SelectedDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            dpTo.SelectedDate = DateTime.Now;
            Loaded += (s, e) => Build();
        }

        /// <summary>Горячая клавиша F5.</summary>
        public void RefreshData() => Build();

        private void Period_Changed(object sender, SelectionChangedEventArgs e)
        {
            if (IsLoaded) Build();
        }

        private void Build()
        {
            if (!dpFrom.SelectedDate.HasValue || !dpTo.SelectedDate.HasValue)
            {
                MessageBox.Show("Укажите период отчёта.", "Отчёт",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (dpFrom.SelectedDate > dpTo.SelectedDate)
            {
                MessageBox.Show("Дата начала больше даты окончания.", "Отчёт",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                DateTime from = dpFrom.SelectedDate.Value;
                DateTime to = dpTo.SelectedDate.Value;

                _period = Repository.GetReportPeriod(from, to);
                lblTotal.Text = _period.ВсегоЗакрыто.ToString();
                lblOverdue.Text = _period.Просрочено.ToString();
                lblAvg.Text = _period.СреднееЧасов.ToString("0.00");

                _details = Repository.GetReportDetail(from, to);
                _byType = Repository.GetReportByType(from, to);
                _load = Repository.GetEmployeeLoad();

                gridDetail.ItemsSource = _details;
                grid.ItemsSource = _byType;
                gridLoad.ItemsSource = _load;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось построить отчёт: " + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
