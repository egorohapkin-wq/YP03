using System;
using System.Windows;
using DeliverySupport.Wpf.Data;
using DeliverySupport.Wpf.Models;

namespace DeliverySupport.Wpf.Views
{
    public partial class EmployeeEditWindow : Window
    {
        private readonly Employee _employee;

        public EmployeeEditWindow(Employee employee)
        {
            InitializeComponent();
            _employee = employee;

            if (employee == null)
            {
                lblTitle.Text = "Новый сотрудник";
                lblHint.Text = "Будет создана учётная запись со стандартным паролем Spec123";
                chkActive.IsChecked = true;
            }
            else
            {
                lblTitle.Text = "Сотрудник";
                lblHint.Text = "Учётная запись сотрудника";
                txtFio.Text = employee.ФИО;
                txtPhone.Text = employee.Телефон;
                txtEmail.Text = employee.Email;
                txtPosition.Text = employee.Должность;
                txtSpecialization.Text = employee.Специализация;
                chkActive.IsChecked = employee.Активен;
            }
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            lblError.Visibility = Visibility.Collapsed;
            string fio = txtFio.Text.Trim();
            if (fio.Length < 5) { ShowError("Укажите ФИО полностью."); return; }
            if (txtPhone.Text.Trim().Length < 5) { ShowError("Укажите телефон."); return; }
            if (txtPosition.Text.Trim().Length < 3) { ShowError("Укажите должность."); return; }

            try
            {
                Repository.SaveEmployee(_employee?.Id, fio, txtPhone.Text.Trim(),
                    txtEmail.Text.Trim(), txtPosition.Text.Trim(),
                    txtSpecialization.Text.Trim(), chkActive.IsChecked == true);
                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                ShowError("Не удалось сохранить: " + ex.Message);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void ShowError(string t)
        {
            lblError.Text = t;
            lblError.Visibility = Visibility.Visible;
        }
    }
}
