# ИС «Техническая поддержка службы доставки»

Курсовой проект по МДК 05.02. Основное приложение — WPF на C# (.NET Framework 4.8),
база данных — Microsoft SQL Server, доступ к данным через ADO.NET
(`System.Data.SqlClient`), параметризованные запросы и хранимые процедуры.
Дополнительно в состав проекта входят REST API (ASP.NET Core 8, JWT, Swagger)
и автоматические тесты (xUnit).

## Состав решения

```
Курсач 0502/
  DeliverySupport.Wpf/         — WPF-приложение и скрипт БД
    Database/create_database.sql
    Data/                      — Db, Repository, Session, PasswordHasher, Validation
    Models/                    — модели предметной области
    Views/                     — окна
    Views/Pages/               — страницы рабочей области
  DeliverySupport.Api/         — REST API (net8.0, JWT, Swagger)
  DeliverySupport.Wpf.Tests/   — xUnit-тесты слоя данных (net48)
  DeliverySupport.Api.Tests/   — xUnit-интеграционные тесты API (net8.0)
```

## База данных

Скрипт создаёт объекты с префиксом `DS_` в текущей базе данных (`user92_db`), так как
на учебном сервере нет прав на создание отдельных баз данных:

* Таблицы: `DS_Роли`, `DS_Пользователи`, `DS_Клиенты`, `DS_Сотрудники`, `DS_ТипыПроблем`,
  `DS_Приоритеты`, `DS_СтатусыЗаявок`, `DS_Заявки`, `DS_ИсторияЗаявок`.
* Представления: `DS_vw_РеестрЗаявок`, `DS_vw_ВыполненныеЗаявки`,
  `DS_vw_НагрузкаСотрудников`.
* Хранимые процедуры: `DS_sp_СоздатьЗаявку`, `DS_sp_НазначитьИсполнителя`,
  `DS_sp_ИзменитьСтатусЗаявки`, `DS_sp_ОтчетЗаПериод`, `DS_sp_ОтчетЗаПериодДетально`.
* Ограничения: уникальность логина и телефона, уникальность номера заявки,
  контроль даты закрытия и норматива часов.

Применение скрипта:

```
sqlcmd -S "stud-mssql.sttec.yar.ru,38325" -U user92_db -P user92 -C -d user92_db -f 65001 -i "Database\create_database.sql"
```

## Строка подключения

```
data source=stud-mssql.sttec.yar.ru,38325;user id=user92_db;password=user92;
trustservercertificate=True;MultipleActiveResultSets=True;App=EntityFramework
```

Строка хранится в `App.config`. При необходимости её изменяют в этом файле и
перезапускают приложение.

## Демонстрационные учётные записи

| Роль          | Логин    | Пароль    |
|---------------|----------|-----------|
| Администратор | admin    | Admin123  |
| Оператор      | operator | Oper123   |
| Специалист    | spec     | Spec123   |
| Клиент        | client   | Client123 |

Новые пароли хранятся как `S1$соль$хеш` — SHA-256 с криптографической солью.
Демонстрационные записи используют прежний формат `SHA2_256` от UTF-16LE
(совместим с `HASHBYTES('SHA2_256', N'пароль')`); приложение поддерживает оба формата.

## Роли и возможности

* **Клиент** — создаёт заявки, видит только свои обращения, может отменить новую заявку.
* **Оператор** — ведёт реестр, назначает исполнителей, работает с клиентами и отчётами.
* **Специалист** — видит только назначенные на него заявки и меняет их статусы.
* **Администратор** — полный доступ, пользователи, справочники.

## Возможности приложения

* Реестр заявок с поиском, фильтром по статусу, исполнителю и периоду дат.
* Карточка заявки: назначение исполнителя, смена статуса, история изменений.
* Проверка активности сотрудника при назначении, запрет закрытия без результата,
  контроль допустимых переходов статусов на уровне БД и в карточке заявки.
* Отчёты: сводка за период, детальный список, распределение по типам, нагрузка сотрудников.
* Администрирование: пользователи, сотрудники, типы проблем.
* Окно «О программе», заставка при запуске, горячие клавиши.
* Валидация форматов: телефон (11 цифр), логин (4–14), пароль (6–14), e-mail.

### Горячие клавиши

| Клавиша | Действие |
|---------|----------|
| F5      | Обновить список / отчёт |
| Ctrl+N  | Новая заявка |
| Ctrl+F  | Переход к поиску |
| Esc     | Закрыть окно |

## Сборка и запуск WPF

```
"C:\Program Files\Microsoft Visual Studio\2022\Community\MSBuild\Current\Bin\MSBuild.exe" ^
  DeliverySupport.Wpf.csproj /t:Rebuild /p:Configuration=Debug
```

Готовый файл: `bin\Debug\DeliverySupport.Wpf.exe`.

## REST API

API находится в `..\DeliverySupport.Api` и использует ту же базу данных.

```
dotnet run --project ..\DeliverySupport.Api\DeliverySupport.Api.csproj --urls http://localhost:5080
```

Swagger: `http://localhost:5080/swagger`.

Основные endpoints:

| Метод | Путь | Назначение |
|-------|------|------------|
| POST | /api/auth/login | Получение JWT |
| POST | /api/auth/register | Регистрация клиента |
| GET | /api/requests | Реестр заявок с фильтрами |
| GET | /api/requests/{id} | Карточка и история заявки |
| POST | /api/requests | Создание заявки |
| POST | /api/requests/{id}/assign | Назначение исполнителя |
| POST | /api/requests/{id}/status | Смена статуса |
| POST | /api/requests/{id}/cancel | Отмена заявки клиентом |
| GET | /api/clients | Клиенты |
| GET | /api/employees | Сотрудники |
| GET | /api/employees/load | Нагрузка сотрудников |
| GET | /api/problem-types | Типы проблем |
| GET | /api/references/statuses | Статусы |
| GET | /api/references/priorities | Приоритеты |
| GET | /api/reports/period | Сводка за период |
| GET | /api/reports/by-type | Разрез по типам |
| GET | /api/reports/detail | Детальный отчёт |

Пример запроса:

```
curl -X POST http://localhost:5080/api/auth/login ^
  -H "Content-Type: application/json" ^
  -d "{\"login\":\"admin\",\"password\":\"Admin123\"}"
```

Полученный токен передаётся в заголовке `Authorization: Bearer <token>`.

## Тесты

```
dotnet test ..\DeliverySupport.Wpf.Tests\DeliverySupport.Wpf.Tests.csproj
dotnet test ..\DeliverySupport.Api.Tests\DeliverySupport.Api.Tests.csproj
```

Тесты WPF проверяют хеширование (соль и старый формат), валидацию и запросы слоя данных
к учебной БД. Тесты API проверяют Swagger, авторизацию, ограничения ролей и отчёты.
