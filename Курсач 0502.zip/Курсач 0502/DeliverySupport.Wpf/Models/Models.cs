using System;

namespace DeliverySupport.Wpf.Models
{
    public class Role
    {
        public int Id { get; set; }
        public string Название { get; set; }
        public string Описание { get; set; }
    }

    public class User
    {
        public int Id { get; set; }
        public string Логин { get; set; }
        public string ФИО { get; set; }
        public string Телефон { get; set; }
        public string Email { get; set; }
        public int IdРоли { get; set; }
        public string Роль { get; set; }
        public bool Заблокирован { get; set; }
        public DateTime ДатаРегистрации { get; set; }
        public DateTime? ПоследнийВход { get; set; }
    }

    public class Client
    {
        public int Id { get; set; }
        public int IdПользователя { get; set; }
        public string ФИО { get; set; }
        public string Телефон { get; set; }
        public string Email { get; set; }
        public string Адрес { get; set; }
        public string Организация { get; set; }
        public DateTime ДатаРегистрации { get; set; }
    }

    public class Employee
    {
        public int Id { get; set; }
        public int IdПользователя { get; set; }
        public string ФИО { get; set; }
        public string Телефон { get; set; }
        public string Email { get; set; }
        public string Должность { get; set; }
        public string Специализация { get; set; }
        public bool Активен { get; set; }
        public DateTime ДатаПриема { get; set; }
    }

    public class ProblemType
    {
        public int Id { get; set; }
        public string Название { get; set; }
        public string Описание { get; set; }
        public int НормативЧасов { get; set; }
    }

    public class Priority
    {
        public int Id { get; set; }
        public string Название { get; set; }
        public int Вес { get; set; }
    }

    public class Status
    {
        public int Id { get; set; }
        public string Название { get; set; }
        public bool Закрывающий { get; set; }
        public int Порядок { get; set; }
    }

    public class RequestItem
    {
        public int Id { get; set; }
        public string Номер { get; set; }
        public int IdКлиента { get; set; }
        public string Клиент { get; set; }
        public string ТипПроблемы { get; set; }
        public string Приоритет { get; set; }
        public string Статус { get; set; }
        public string Исполнитель { get; set; }
        public int? IdИсполнителя { get; set; }
        public DateTime ДатаСоздания { get; set; }
        public DateTime ПлановыйСрок { get; set; }
        public int ВесПриоритета { get; set; }
        public int IdСтатуса { get; set; }

        public bool Просрочена => DateTime.Now > ПлановыйСрок;
        public string СостояниеСрока => Просрочена ? "Просрочена" : "В срок";
    }

    public class RequestDetail
    {
        public int Id { get; set; }
        public string Номер { get; set; }
        public int IdКлиента { get; set; }
        public string Клиент { get; set; }
        public string Телефон { get; set; }
        public string Адрес { get; set; }
        public int IdТипа { get; set; }
        public string ТипПроблемы { get; set; }
        public int IdПриоритета { get; set; }
        public string Приоритет { get; set; }
        public int IdСтатуса { get; set; }
        public string Статус { get; set; }
        public int? IdИсполнителя { get; set; }
        public string Исполнитель { get; set; }
        public DateTime ДатаСоздания { get; set; }
        public DateTime? ДатаЗакрытия { get; set; }
        public string ОписаниеПроблемы { get; set; }
        public string Результат { get; set; }
    }

    public class HistoryEntry
    {
        public int Id { get; set; }
        public string Пользователь { get; set; }
        public string СтарыйСтатус { get; set; }
        public string НовыйСтатус { get; set; }
        public string Комментарий { get; set; }
        public DateTime Дата { get; set; }
    }

    public class ReferenceItem
    {
        public int Id { get; set; }
        public string Название { get; set; }
        public string Доп1 { get; set; }
        public string Доп2 { get; set; }
    }

    public class ReportPeriodRow
    {
        public int ВсегоЗакрыто { get; set; }
        public int Просрочено { get; set; }
        public decimal СреднееЧасов { get; set; }
    }

    public class ReportByTypeRow
    {
        public string ТипПроблемы { get; set; }
        public int Всего { get; set; }
        public int Закрыто { get; set; }
        public int Просрочено { get; set; }
    }

    public class ReportDetailRow
    {
        public string НомерЗаявки { get; set; }
        public string ТипПроблемы { get; set; }
        public string Приоритет { get; set; }
        public string Статус { get; set; }
        public DateTime ДатаСоздания { get; set; }
        public DateTime? ДатаЗакрытия { get; set; }
        public int? МинутНаВыполнение { get; set; }
        public bool Просрочена { get; set; }
        public string Клиент { get; set; }
        public string Исполнитель { get; set; }
    }

    public class EmployeeLoadRow
    {
        public int IdСотрудника { get; set; }
        public string Сотрудник { get; set; }
        public string Должность { get; set; }
        public bool Активен { get; set; }
        public int ВсегоЗаявок { get; set; }
        public int ВРаботе { get; set; }
        public int Закрыто { get; set; }
        public int Просрочено { get; set; }
    }
}
