using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle("ИС «Техническая поддержка службы доставки»")]
[assembly: AssemblyDescription("Курсовой проект МДК 05.02")]
[assembly: AssemblyProduct("DeliverySupport")]
[assembly: AssemblyCompany("Охапкин Егор")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
