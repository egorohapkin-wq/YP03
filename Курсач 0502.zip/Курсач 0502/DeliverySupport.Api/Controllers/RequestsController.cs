using System.Security.Claims;
using DeliverySupport.Api.Data;
using DeliverySupport.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace DeliverySupport.Api.Controllers;

[ApiController]
[Route("api/requests")]
[Authorize]
public class RequestsController : ControllerBase
{
    private readonly ApiRepository _repo;

    public RequestsController(ApiRepository repo)
    {
        _repo = repo;
    }

    private int CurrentUserId =>
        int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out int id) ? id : 0;

    private bool IsClient => User.IsInRole("Клиент");
    private bool IsSpecialist => User.IsInRole("Специалист");

    /// <summary>Реестр заявок с фильтрами (номер/клиент/тип, статус, исполнитель, даты).</summary>
    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] int? statusId,
        [FromQuery] int? executorId, [FromQuery] string? search,
        [FromQuery] DateTime? dateFrom, [FromQuery] DateTime? dateTo,
        CancellationToken ct)
    {
        int? clientId = null;
        if (IsClient)
        {
            clientId = await _repo.GetClientIdByUserIdAsync(CurrentUserId, ct);
            if (!clientId.HasValue) return Ok(Array.Empty<RequestListItem>());
        }
        if (IsSpecialist)
        {
            executorId = await _repo.GetEmployeeIdByUserIdAsync(CurrentUserId, ct);
            if (!executorId.HasValue) return Ok(Array.Empty<RequestListItem>());
        }

        var list = await _repo.GetRequestsAsync(clientId, statusId, executorId,
            search, dateFrom, dateTo, ct);
        return Ok(list);
    }

    /// <summary>Карточка заявки с историей изменений.</summary>
    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        var detail = await _repo.GetRequestDetailAsync(id, ct);
        if (detail == null) return NotFound(new { message = "Заявка не найдена." });
        if (IsClient)
        {
            int? clientId = await _repo.GetClientIdByUserIdAsync(CurrentUserId, ct);
            if (detail.ClientId != clientId) return Forbid();
        }
        if (IsSpecialist)
        {
            int? employeeId = await _repo.GetEmployeeIdByUserIdAsync(CurrentUserId, ct);
            if (detail.ExecutorId != employeeId) return Forbid();
        }
        return Ok(detail);
    }

    /// <summary>Создание заявки. Клиент создаёт от своего имени.</summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateRequestRequest request,
        CancellationToken ct)
    {
        if (request.ProblemTypeId <= 0 || request.PriorityId <= 0)
            return BadRequest(new { message = "Укажите тип проблемы и приоритет." });
        if (string.IsNullOrWhiteSpace(request.Description) || request.Description.Trim().Length < 10)
            return BadRequest(new { message = "Описание должно содержать не менее 10 символов." });

        int clientId;
        if (IsClient)
        {
            int? own = await _repo.GetClientIdByUserIdAsync(CurrentUserId, ct);
            if (!own.HasValue)
                return BadRequest(new { message = "Для учётной записи не найден профиль клиента." });
            clientId = own.Value;
        }
        else
        {
            if (!request.ClientId.HasValue || request.ClientId.Value <= 0)
                return BadRequest(new { message = "Укажите клиента." });
            clientId = request.ClientId.Value;
        }

        try
        {
            var created = await _repo.CreateRequestAsync(clientId, request.ProblemTypeId,
                request.PriorityId, CurrentUserId, request.Description.Trim(), ct);
            var detail = await _repo.GetRequestDetailAsync(created.Id, ct);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, detail);
        }
        catch (SqlException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    /// <summary>Назначение исполнителя (активный сотрудник).</summary>
    [HttpPost("{id:int}/assign")]
    [Authorize(Roles = "Администратор,Оператор")]
    public async Task<IActionResult> Assign(int id, [FromBody] AssignRequest request,
        CancellationToken ct)
    {
        if (request.EmployeeId <= 0)
            return BadRequest(new { message = "Укажите сотрудника." });
        try
        {
            await _repo.AssignExecutorAsync(id, request.EmployeeId, CurrentUserId, ct);
            return Ok(new { message = "Исполнитель назначен." });
        }
        catch (SqlException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    /// <summary>Изменение статуса заявки.</summary>
    [HttpPost("{id:int}/status")]
    [Authorize(Roles = "Администратор,Оператор,Специалист")]
    public async Task<IActionResult> ChangeStatus(int id,
        [FromBody] ChangeStatusRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Status))
            return BadRequest(new { message = "Укажите новый статус." });

        var detail = await _repo.GetRequestDetailAsync(id, ct);
        if (detail == null) return NotFound(new { message = "Заявка не найдена." });
        if (IsSpecialist)
        {
            int? employeeId = await _repo.GetEmployeeIdByUserIdAsync(CurrentUserId, ct);
            if (detail.ExecutorId != employeeId)
                return Forbid();
        }

        try
        {
            await _repo.ChangeStatusAsync(id, request.Status.Trim(), CurrentUserId,
                request.Comment, request.Result, ct);
            return Ok(new { message = "Статус изменён." });
        }
        catch (SqlException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }

    /// <summary>Отмена новой заявки клиентом.</summary>
    [HttpPost("{id:int}/cancel")]
    [Authorize(Roles = "Клиент")]
    public async Task<IActionResult> Cancel(int id, CancellationToken ct)
    {
        var detail = await _repo.GetRequestDetailAsync(id, ct);
        if (detail == null) return NotFound(new { message = "Заявка не найдена." });

        int? clientId = await _repo.GetClientIdByUserIdAsync(CurrentUserId, ct);
        if (detail.ClientId != clientId) return Forbid();
        if (detail.Status != "Новая")
            return BadRequest(new { message = "Отменить можно только новую заявку." });

        try
        {
            await _repo.ChangeStatusAsync(id, "Отменена", CurrentUserId,
                "Заявка отменена клиентом", null, ct);
            return Ok(new { message = "Заявка отменена." });
        }
        catch (SqlException ex)
        {
            return BadRequest(new { message = ex.Message });
        }
    }
}
