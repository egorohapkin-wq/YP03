using DeliverySupport.Api.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DeliverySupport.Api.Controllers;

[ApiController]
[Route("api/clients")]
[Authorize(Roles = "Администратор,Оператор,Специалист")]
public class ClientsController : ControllerBase
{
    private readonly ApiRepository _repo;

    public ClientsController(ApiRepository repo)
    {
        _repo = repo;
    }

    /// <summary>Список клиентов с поиском по ФИО, телефону и организации.</summary>
    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] string? search, CancellationToken ct)
    {
        return Ok(await _repo.GetClientsAsync(search, ct));
    }
}
