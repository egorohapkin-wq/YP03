using DeliverySupport.Api.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DeliverySupport.Api.Controllers;

[ApiController]
[Route("api/reports")]
[Authorize(Roles = "Администратор,Оператор,Специалист")]
public class ReportsController : ControllerBase
{
    private readonly ApiRepository _repo;

    public ReportsController(ApiRepository repo)
    {
        _repo = repo;
    }

    /// <summary>Сводка за период: закрыто, просрочено, среднее время.</summary>
    [HttpGet("period")]
    public async Task<IActionResult> Period([FromQuery] DateTime from,
        [FromQuery] DateTime to, CancellationToken ct)
    {
        if (from > to)
            return BadRequest(new { message = "Дата начала больше даты окончания." });
        return Ok(await _repo.GetReportPeriodAsync(from, to, ct));
    }

    /// <summary>Распределение заявок по типам проблем за период.</summary>
    [HttpGet("by-type")]
    public async Task<IActionResult> ByType([FromQuery] DateTime from,
        [FromQuery] DateTime to, CancellationToken ct)
    {
        if (from > to)
            return BadRequest(new { message = "Дата начала больше даты окончания." });
        return Ok(await _repo.GetReportByTypeAsync(from, to, ct));
    }

    /// <summary>Детальный список выполненных заявок за период.</summary>
    [HttpGet("detail")]
    public async Task<IActionResult> Detail([FromQuery] DateTime from,
        [FromQuery] DateTime to, CancellationToken ct)
    {
        if (from > to)
            return BadRequest(new { message = "Дата начала больше даты окончания." });
        return Ok(await _repo.GetReportDetailAsync(from, to, ct));
    }
}
