using DeliverySupport.Api.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DeliverySupport.Api.Controllers;

[ApiController]
[Route("api/employees")]
[Authorize]
public class EmployeesController : ControllerBase
{
    private readonly ApiRepository _repo;

    public EmployeesController(ApiRepository repo)
    {
        _repo = repo;
    }

    /// <summary>Сотрудники службы поддержки. onlyActive=true — только активные.</summary>
    [HttpGet]
    public async Task<IActionResult> Get([FromQuery] bool onlyActive = false,
        CancellationToken ct = default)
    {
        return Ok(await _repo.GetEmployeesAsync(onlyActive, ct));
    }

    /// <summary>Нагрузка сотрудников (представление DS_vw_НагрузкаСотрудников).</summary>
    [HttpGet("load")]
    [Authorize(Roles = "Администратор,Оператор,Специалист")]
    public async Task<IActionResult> GetLoad(CancellationToken ct)
    {
        return Ok(await _repo.GetEmployeeLoadAsync(ct));
    }
}
