using DeliverySupport.Api.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DeliverySupport.Api.Controllers;

[ApiController]
[Route("api/references")]
[Authorize]
public class ReferencesController : ControllerBase
{
    private readonly ApiRepository _repo;

    public ReferencesController(ApiRepository repo)
    {
        _repo = repo;
    }

    /// <summary>Статусы заявок.</summary>
    [HttpGet("statuses")]
    public async Task<IActionResult> GetStatuses(CancellationToken ct)
    {
        return Ok(await _repo.GetStatusesAsync(ct));
    }

    /// <summary>Приоритеты заявок.</summary>
    [HttpGet("priorities")]
    public async Task<IActionResult> GetPriorities(CancellationToken ct)
    {
        return Ok(await _repo.GetPrioritiesAsync(ct));
    }
}
