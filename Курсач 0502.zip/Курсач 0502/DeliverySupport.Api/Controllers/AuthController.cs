using DeliverySupport.Api.Data;
using DeliverySupport.Api.Models;
using DeliverySupport.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace DeliverySupport.Api.Controllers;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly ApiRepository _repo;
    private readonly JwtService _jwt;

    public AuthController(ApiRepository repo, JwtService jwt)
    {
        _repo = repo;
        _jwt = jwt;
    }

    /// <summary>Аутентификация и получение JWT-токена.</summary>
    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<IActionResult> Login([FromBody] LoginRequest request,
        CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Login) ||
            string.IsNullOrWhiteSpace(request.Password))
            return BadRequest(new { message = "Введите логин и пароль." });

        var user = await _repo.AuthenticateAsync(request.Login.Trim(), request.Password, ct);
        if (user == null)
            return Unauthorized(new { message = "Неверный логин или пароль." });
        if (user.Blocked)
            return Unauthorized(new { message = "Учётная запись заблокирована администратором." });

        await _repo.UpdateLastLoginAsync(user.Id, ct);
        user.LastLogin = DateTime.Now;

        var (token, expiresAt) = _jwt.CreateToken(user);
        return Ok(new LoginResponse { Token = token, ExpiresAt = expiresAt, User = user });
    }

    /// <summary>Регистрация нового клиента.</summary>
    [HttpPost("register")]
    [AllowAnonymous]
    public async Task<IActionResult> Register([FromBody] RegisterRequest request,
        CancellationToken ct)
    {
        if (!Validation.IsValidLogin(request.Login))
            return BadRequest(new { message = "Логин: 4–14 символов, начинается с буквы." });
        if (!Validation.IsValidPassword(request.Password))
            return BadRequest(new { message = "Пароль должен содержать 6–14 символов." });
        if (!Validation.IsValidFio(request.Fio))
            return BadRequest(new { message = "Укажите ФИО полностью." });
        if (!Validation.IsValidEmail(request.Email))
            return BadRequest(new { message = "Некорректный адрес электронной почты." });

        string? phone = Validation.NormalizePhone(request.Phone);
        if (phone == null)
            return BadRequest(new { message = "Телефон должен содержать 11 цифр." });

        try
        {
            if (await _repo.LoginExistsAsync(request.Login.Trim(), ct))
                return Conflict(new { message = "Пользователь с таким логином уже существует." });
            if (await _repo.PhoneExistsAsync(phone, ct))
                return Conflict(new { message = "Пользователь с таким телефоном уже существует." });

            await _repo.RegisterClientAsync(request, phone, ct);
            return StatusCode(StatusCodes.Status201Created,
                new { message = "Клиент зарегистрирован." });
        }
        catch (SqlException ex) when (ex.Number == 2601 || ex.Number == 2627)
        {
            return Conflict(new { message = "Логин или телефон уже используются." });
        }
    }
}
