using DeliverySupport.Api.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace DeliverySupport.Api.Controllers;

[ApiController]
[Route("api/problem-types")]
[Authorize]
public class ProblemTypesController : ControllerBase
{
    private readonly ApiRepository _repo;

    public ProblemTypesController(ApiRepository repo)
    {
        _repo = repo;
    }

    /// <summary>Справочник типов проблем с нормативами выполнения.</summary>
    [HttpGet]
    public async Task<IActionResult> Get(CancellationToken ct)
    {
        return Ok(await _repo.GetProblemTypesAsync(ct));
    }
}
