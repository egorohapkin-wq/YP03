namespace DeliverySupport.Api.Models;

public class LoginRequest
{
    public string Login { get; set; } = "";
    public string Password { get; set; } = "";
}

public class RegisterRequest
{
    public string Login { get; set; } = "";
    public string Password { get; set; } = "";
    public string Fio { get; set; } = "";
    public string Phone { get; set; } = "";
    public string? Email { get; set; }
    public string? Address { get; set; }
    public string? Organization { get; set; }
}

public class UserDto
{
    public int Id { get; set; }
    public string Login { get; set; } = "";
    public string Fio { get; set; } = "";
    public string Phone { get; set; } = "";
    public string? Email { get; set; }
    public string Role { get; set; } = "";
    public bool Blocked { get; set; }
    public DateTime RegisteredAt { get; set; }
    public DateTime? LastLogin { get; set; }
}

public class LoginResponse
{
    public string Token { get; set; } = "";
    public DateTime ExpiresAt { get; set; }
    public UserDto User { get; set; } = new();
}

public class RequestListItem
{
    public int Id { get; set; }
    public string Number { get; set; } = "";
    public int ClientId { get; set; }
    public string Client { get; set; } = "";
    public string ProblemType { get; set; } = "";
    public string Priority { get; set; } = "";
    public string Status { get; set; } = "";
    public string Executor { get; set; } = "";
    public int? ExecutorId { get; set; }
    public int StatusId { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime DueAt { get; set; }
    public bool Overdue => DateTime.Now > DueAt;
}

public class RequestDetail
{
    public int Id { get; set; }
    public string Number { get; set; } = "";
    public int ClientId { get; set; }
    public string Client { get; set; } = "";
    public string Phone { get; set; } = "";
    public string? Address { get; set; }
    public int ProblemTypeId { get; set; }
    public string ProblemType { get; set; } = "";
    public int PriorityId { get; set; }
    public string Priority { get; set; } = "";
    public int StatusId { get; set; }
    public string Status { get; set; } = "";
    public int? ExecutorId { get; set; }
    public string? Executor { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? ClosedAt { get; set; }
    public string Description { get; set; } = "";
    public string? Result { get; set; }
    public List<HistoryDto> History { get; set; } = new();
}

public class HistoryDto
{
    public string User { get; set; } = "";
    public string? OldStatus { get; set; }
    public string NewStatus { get; set; } = "";
    public string? Comment { get; set; }
    public DateTime ChangedAt { get; set; }
}

public class CreateRequestRequest
{
    public int? ClientId { get; set; }
    public int ProblemTypeId { get; set; }
    public int PriorityId { get; set; }
    public string Description { get; set; } = "";
}

public class AssignRequest
{
    public int EmployeeId { get; set; }
}

public class ChangeStatusRequest
{
    public string Status { get; set; } = "";
    public string? Comment { get; set; }
    public string? Result { get; set; }
}

public class ClientDto
{
    public int Id { get; set; }
    public string Fio { get; set; } = "";
    public string Phone { get; set; } = "";
    public string? Email { get; set; }
    public string? Address { get; set; }
    public string? Organization { get; set; }
    public DateTime RegisteredAt { get; set; }
}

public class EmployeeDto
{
    public int Id { get; set; }
    public string Fio { get; set; } = "";
    public string Phone { get; set; } = "";
    public string? Email { get; set; }
    public string Position { get; set; } = "";
    public string Specialization { get; set; } = "";
    public bool Active { get; set; }
    public DateTime HiredAt { get; set; }
}

public class ProblemTypeDto
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public int StandardHours { get; set; }
}

public class ReferenceDto
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public int Order { get; set; }
}

public class ReportPeriodDto
{
    public int ClosedTotal { get; set; }
    public int Overdue { get; set; }
    public decimal AverageHours { get; set; }
}

public class ReportByTypeDto
{
    public string ProblemType { get; set; } = "";
    public int Total { get; set; }
    public int Closed { get; set; }
    public int Overdue { get; set; }
}

public class ReportDetailDto
{
    public string Number { get; set; } = "";
    public string ProblemType { get; set; } = "";
    public string Priority { get; set; } = "";
    public string Status { get; set; } = "";
    public DateTime CreatedAt { get; set; }
    public DateTime? ClosedAt { get; set; }
    public int? Minutes { get; set; }
    public bool Overdue { get; set; }
    public string Client { get; set; } = "";
    public string Executor { get; set; } = "";
}

public class EmployeeLoadDto
{
    public int EmployeeId { get; set; }
    public string Employee { get; set; } = "";
    public string Position { get; set; } = "";
    public bool Active { get; set; }
    public int Total { get; set; }
    public int InWork { get; set; }
    public int Closed { get; set; }
    public int Overdue { get; set; }
}
