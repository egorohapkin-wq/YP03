namespace DeliverySupport.Api.Services;

public static class Validation
{
    public static string DigitsOnly(string value) =>
        new(value.Where(char.IsDigit).ToArray());

    public static string? NormalizePhone(string? value)
    {
        string digits = DigitsOnly(value ?? "");
        if (digits.Length == 11 && digits[0] == '8') digits = "7" + digits[1..];
        if (digits.Length == 10) digits = "7" + digits;
        return digits.Length == 11 && digits[0] == '7' ? "+" + digits : null;
    }

    public static bool IsValidLogin(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        value = value.Trim();
        if (value.Length < 4 || value.Length > 14) return false;
        if (!char.IsLetter(value[0])) return false;
        return value.All(c => char.IsLetterOrDigit(c) || c == '_');
    }

    public static bool IsValidPassword(string? value) =>
        !string.IsNullOrEmpty(value) && value.Length >= 6 && value.Length <= 14;

    public static bool IsValidFio(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        var parts = value.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);
        return parts.Length >= 2 && value.Trim().Length >= 5;
    }

    public static bool IsValidEmail(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return true;
        value = value.Trim();
        int at = value.IndexOf('@');
        int dot = value.LastIndexOf('.');
        return at > 0 && dot > at + 1 && dot < value.Length - 1;
    }
}
