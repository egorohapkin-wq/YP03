using System.Security.Cryptography;
using System.Text;

namespace DeliverySupport.Api.Services;

/// <summary>
/// Проверка паролей: новые хеши S1$соль$хеш (SHA-256 с солью),
/// старые — SHA-256 от UTF-16LE (совместимо с HASHBYTES('SHA2_256', N'...')).
/// </summary>
public static class PasswordHasher
{
    private const string SaltedPrefix = "S1$";

    public static string Hash(string password)
    {
        string safe = password ?? "";
        byte[] salt = RandomNumberGenerator.GetBytes(16);
        byte[] hash = ComputeSalted(safe, salt);
        return SaltedPrefix + Convert.ToBase64String(salt) + "$" + Convert.ToBase64String(hash);
    }

    public static bool Verify(string password, string storedHash)
    {
        if (string.IsNullOrEmpty(storedHash)) return false;
        storedHash = storedHash.Trim();

        if (storedHash.StartsWith(SaltedPrefix, StringComparison.Ordinal))
        {
            string[] parts = storedHash.Split('$');
            if (parts.Length != 3) return false;
            try
            {
                byte[] salt = Convert.FromBase64String(parts[1]);
                byte[] expected = Convert.FromBase64String(parts[2]);
                return CryptographicOperations.FixedTimeEquals(
                    expected, ComputeSalted(password ?? "", salt));
            }
            catch (FormatException)
            {
                return false;
            }
        }

        byte[] legacy = Encoding.ASCII.GetBytes(LegacyHash(password));
        return CryptographicOperations.FixedTimeEquals(
            legacy, Encoding.ASCII.GetBytes(storedHash.ToUpperInvariant()));
    }

    public static string LegacyHash(string password)
    {
        byte[] hash = SHA256.HashData(Encoding.Unicode.GetBytes(password ?? ""));
        return Convert.ToHexString(hash);
    }

    private static byte[] ComputeSalted(string password, byte[] salt)
    {
        byte[] pwd = Encoding.UTF8.GetBytes(password);
        byte[] data = new byte[salt.Length + pwd.Length];
        Buffer.BlockCopy(salt, 0, data, 0, salt.Length);
        Buffer.BlockCopy(pwd, 0, data, salt.Length, pwd.Length);
        return SHA256.HashData(data);
    }
}
