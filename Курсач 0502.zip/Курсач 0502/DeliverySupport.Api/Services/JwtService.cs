using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using DeliverySupport.Api.Models;
using Microsoft.IdentityModel.Tokens;

namespace DeliverySupport.Api.Services;

public class JwtService
{
    private readonly IConfiguration _configuration;

    public JwtService(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public (string Token, DateTime ExpiresAt) CreateToken(UserDto user)
    {
        var jwt = _configuration.GetSection("Jwt");
        string key = jwt["Key"] ?? throw new InvalidOperationException("Не задан Jwt:Key");
        string issuer = jwt["Issuer"] ?? "DeliverySupport.Api";
        string audience = jwt["Audience"] ?? "DeliverySupport.Clients";
        int minutes = int.TryParse(jwt["LifetimeMinutes"], out int m) ? m : 480;

        var claims = new List<Claim>
        {
            new(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.Login),
            new(ClaimTypes.Role, user.Role),
            new("fio", user.Fio),
            new("login", user.Login)
        };

        var credentials = new SigningCredentials(
            new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)),
            SecurityAlgorithms.HmacSha256);

        DateTime expires = DateTime.UtcNow.AddMinutes(minutes);
        var token = new JwtSecurityToken(
            issuer: issuer,
            audience: audience,
            claims: claims,
            notBefore: DateTime.UtcNow,
            expires: expires,
            signingCredentials: credentials);

        return (new JwtSecurityTokenHandler().WriteToken(token), expires);
    }
}
