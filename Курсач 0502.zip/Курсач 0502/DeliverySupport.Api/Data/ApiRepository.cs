using DeliverySupport.Api.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace DeliverySupport.Api.Data;

/// <summary>Все запросы API к базе данных (ADO.NET, параметризованные команды).</summary>
public class ApiRepository
{
    private readonly ApiDb _db;

    public ApiRepository(ApiDb db)
    {
        _db = db;
    }

    private static string S(SqlDataReader r, string name) =>
        r[name] == DBNull.Value ? "" : Convert.ToString(r[name]) ?? "";

    private static string? SN(SqlDataReader r, string name) =>
        r[name] == DBNull.Value ? null : Convert.ToString(r[name]);

    private static int I(SqlDataReader r, string name) => Convert.ToInt32(r[name]);

    private static int? IN(SqlDataReader r, string name) =>
        r[name] == DBNull.Value ? null : Convert.ToInt32(r[name]);

    private static DateTime D(SqlDataReader r, string name) =>
        Convert.ToDateTime(r[name]);

    private static DateTime? DN(SqlDataReader r, string name) =>
        r[name] == DBNull.Value ? null : Convert.ToDateTime(r[name]);

    private static bool B(SqlDataReader r, string name) => Convert.ToBoolean(r[name]);

    // ----------------------------- Аутентификация -----------------------------

    public async Task<UserDto?> AuthenticateAsync(string login, string password,
        CancellationToken ct)
    {
        const string sql = @"
SELECT u.idПользователя, u.Логин, u.ХешПароля, u.ФИО, u.Телефон, u.Email,
       r.Название AS Роль, u.Заблокирован, u.ДатаРегистрации, u.ПоследнийВход
FROM dbo.DS_Пользователи u
JOIN dbo.DS_Роли r ON r.idРоли = u.idРоли
WHERE u.Логин = @login";

        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.Add(ApiDb.P("@login", login));
        using var rdr = await cmd.ExecuteReaderAsync(ct);
        if (!await rdr.ReadAsync(ct)) return null;

        string storedHash = S(rdr, "ХешПароля");
        var user = MapUser(rdr);
        return Services.PasswordHasher.Verify(password, storedHash) ? user : null;
    }

    public async Task UpdateLastLoginAsync(int userId, CancellationToken ct)
    {
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(
            "UPDATE dbo.DS_Пользователи SET ПоследнийВход = SYSDATETIME() WHERE idПользователя = @id",
            conn);
        cmd.Parameters.Add(ApiDb.P("@id", userId));
        await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<bool> LoginExistsAsync(string login, CancellationToken ct)
    {
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(
            "SELECT COUNT(*) FROM dbo.DS_Пользователи WHERE Логин = @login", conn);
        cmd.Parameters.Add(ApiDb.P("@login", login));
        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct)) > 0;
    }

    public async Task<bool> PhoneExistsAsync(string phone, CancellationToken ct)
    {
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(
            "SELECT COUNT(*) FROM dbo.DS_Пользователи WHERE Телефон = @phone", conn);
        cmd.Parameters.Add(ApiDb.P("@phone", phone));
        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct)) > 0;
    }

    public async Task RegisterClientAsync(RegisterRequest request, string phone,
        CancellationToken ct)
    {
        using var conn = await _db.OpenAsync(ct);
        using var tx = conn.BeginTransaction();
        try
        {
            int roleId;
            using (var cmd = new SqlCommand(
                "SELECT idРоли FROM dbo.DS_Роли WHERE Название = N'Клиент'", conn, tx))
                roleId = Convert.ToInt32(await cmd.ExecuteScalarAsync(ct));

            int userId;
            using (var cmd = new SqlCommand(@"
INSERT INTO dbo.DS_Пользователи (Логин, ХешПароля, ФИО, Телефон, Email, idРоли)
VALUES (@login, @hash, @fio, @phone, @email, @role);
SELECT SCOPE_IDENTITY();", conn, tx))
            {
                cmd.Parameters.Add(ApiDb.P("@login", request.Login));
                cmd.Parameters.Add(ApiDb.P("@hash", Services.PasswordHasher.Hash(request.Password)));
                cmd.Parameters.Add(ApiDb.P("@fio", request.Fio));
                cmd.Parameters.Add(ApiDb.P("@phone", phone));
                cmd.Parameters.Add(ApiDb.P("@email", string.IsNullOrWhiteSpace(request.Email) ? null : request.Email));
                cmd.Parameters.Add(ApiDb.P("@role", roleId));
                userId = Convert.ToInt32(await cmd.ExecuteScalarAsync(ct));
            }

            using (var cmd = new SqlCommand(@"
INSERT INTO dbo.DS_Клиенты (idПользователя, Адрес, Организация)
VALUES (@uid, @addr, @org)", conn, tx))
            {
                cmd.Parameters.Add(ApiDb.P("@uid", userId));
                cmd.Parameters.Add(ApiDb.P("@addr", string.IsNullOrWhiteSpace(request.Address) ? null : request.Address));
                cmd.Parameters.Add(ApiDb.P("@org", string.IsNullOrWhiteSpace(request.Organization) ? null : request.Organization));
                await cmd.ExecuteNonQueryAsync(ct);
            }

            await tx.CommitAsync(ct);
        }
        catch
        {
            await tx.RollbackAsync(ct);
            throw;
        }
    }

    public async Task<int?> GetClientIdByUserIdAsync(int userId, CancellationToken ct)
    {
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(
            "SELECT idКлиента FROM dbo.DS_Клиенты WHERE idПользователя = @id", conn);
        cmd.Parameters.Add(ApiDb.P("@id", userId));
        var o = await cmd.ExecuteScalarAsync(ct);
        return o == null || o == DBNull.Value ? null : Convert.ToInt32(o);
    }

    public async Task<int?> GetEmployeeIdByUserIdAsync(int userId, CancellationToken ct)
    {
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(
            "SELECT idСотрудника FROM dbo.DS_Сотрудники WHERE idПользователя = @id", conn);
        cmd.Parameters.Add(ApiDb.P("@id", userId));
        var o = await cmd.ExecuteScalarAsync(ct);
        return o == null || o == DBNull.Value ? null : Convert.ToInt32(o);
    }

    // -------------------------------- Заявки ----------------------------------

    public async Task<List<RequestListItem>> GetRequestsAsync(int? clientId,
        int? statusId, int? execId, string? search, DateTime? dateFrom, DateTime? dateTo,
        CancellationToken ct)
    {
        const string sql = @"
SELECT idЗаявки, НомерЗаявки, Клиент, ТипПроблемы, Приоритет, Статус,
       Исполнитель, ДатаСоздания, ПлановыйСрок, idКлиента, idИсполнителя,
       idСтатуса, ВесПриоритета
FROM dbo.DS_vw_РеестрЗаявок
WHERE (@clientId IS NULL OR idКлиента = @clientId)
  AND (@statusId IS NULL OR idСтатуса = @statusId)
  AND (@execId IS NULL OR idИсполнителя = @execId)
  AND (@dateFrom IS NULL OR ДатаСоздания >= @dateFrom)
  AND (@dateTo IS NULL OR ДатаСоздания < DATEADD(DAY, 1, @dateTo))
  AND (@search IS NULL
       OR НомерЗаявки LIKE '%' + @search + '%'
       OR Клиент LIKE '%' + @search + '%'
       OR ТипПроблемы LIKE '%' + @search + '%')
ORDER BY ВесПриоритета DESC, ДатаСоздания DESC";

        var list = new List<RequestListItem>();
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.Add(ApiDb.P("@clientId", clientId));
        cmd.Parameters.Add(ApiDb.P("@statusId", statusId));
        cmd.Parameters.Add(ApiDb.P("@execId", execId));
        cmd.Parameters.Add(ApiDb.P("@dateFrom", dateFrom?.Date));
        cmd.Parameters.Add(ApiDb.P("@dateTo", dateTo?.Date));
        cmd.Parameters.Add(ApiDb.P("@search", string.IsNullOrWhiteSpace(search) ? null : search));

        using var rdr = await cmd.ExecuteReaderAsync(ct);
        while (await rdr.ReadAsync(ct))
        {
            list.Add(new RequestListItem
            {
                Id = I(rdr, "idЗаявки"),
                Number = S(rdr, "НомерЗаявки"),
                Client = S(rdr, "Клиент"),
                ProblemType = S(rdr, "ТипПроблемы"),
                Priority = S(rdr, "Приоритет"),
                Status = S(rdr, "Статус"),
                Executor = S(rdr, "Исполнитель"),
                CreatedAt = D(rdr, "ДатаСоздания"),
                DueAt = D(rdr, "ПлановыйСрок"),
                ClientId = I(rdr, "idКлиента"),
                ExecutorId = IN(rdr, "idИсполнителя"),
                StatusId = I(rdr, "idСтатуса")
            });
        }
        return list;
    }

    public async Task<RequestDetail?> GetRequestDetailAsync(int id, CancellationToken ct)
    {
        const string sql = @"
SELECT z.idЗаявки, z.НомерЗаявки, z.idКлиента, kp.ФИО AS Клиент, kp.Телефон,
       k.Адрес, z.idТипа, tp.Название AS ТипПроблемы, z.idПриоритета,
       p.Название AS Приоритет, z.idСтатуса, s.Название AS Статус,
       z.idИсполнителя, st.ФИО AS Исполнитель, z.ДатаСоздания, z.ДатаЗакрытия,
       z.ОписаниеПроблемы, z.Результат
FROM dbo.DS_Заявки z
JOIN dbo.DS_Клиенты k ON k.idКлиента = z.idКлиента
JOIN dbo.DS_Пользователи kp ON kp.idПользователя = k.idПользователя
JOIN dbo.DS_ТипыПроблем tp ON tp.idТипа = z.idТипа
JOIN dbo.DS_Приоритеты p ON p.idПриоритета = z.idПриоритета
JOIN dbo.DS_СтатусыЗаявок s ON s.idСтатуса = z.idСтатуса
LEFT JOIN dbo.DS_Сотрудники so ON so.idСотрудника = z.idИсполнителя
LEFT JOIN dbo.DS_Пользователи st ON st.idПользователя = so.idПользователя
WHERE z.idЗаявки = @id";

        RequestDetail? detail = null;
        using (var conn = await _db.OpenAsync(ct))
        using (var cmd = new SqlCommand(sql, conn))
        {
            cmd.Parameters.Add(ApiDb.P("@id", id));
            using var rdr = await cmd.ExecuteReaderAsync(ct);
            if (!await rdr.ReadAsync(ct)) return null;
            detail = new RequestDetail
            {
                Id = I(rdr, "idЗаявки"),
                Number = S(rdr, "НомерЗаявки"),
                ClientId = I(rdr, "idКлиента"),
                Client = S(rdr, "Клиент"),
                Phone = S(rdr, "Телефон"),
                Address = SN(rdr, "Адрес"),
                ProblemTypeId = I(rdr, "idТипа"),
                ProblemType = S(rdr, "ТипПроблемы"),
                PriorityId = I(rdr, "idПриоритета"),
                Priority = S(rdr, "Приоритет"),
                StatusId = I(rdr, "idСтатуса"),
                Status = S(rdr, "Статус"),
                ExecutorId = IN(rdr, "idИсполнителя"),
                Executor = SN(rdr, "Исполнитель"),
                CreatedAt = D(rdr, "ДатаСоздания"),
                ClosedAt = DN(rdr, "ДатаЗакрытия"),
                Description = S(rdr, "ОписаниеПроблемы"),
                Result = SN(rdr, "Результат")
            };
        }

        detail.History = await GetHistoryAsync(id, ct);
        return detail;
    }

    public async Task<List<HistoryDto>> GetHistoryAsync(int requestId, CancellationToken ct)
    {
        const string sql = @"
SELECT u.ФИО AS Пользователь, h.СтарыйСтатус, h.НовыйСтатус,
       h.Комментарий, h.ДатаИзменения
FROM dbo.DS_ИсторияЗаявок h
JOIN dbo.DS_Пользователи u ON u.idПользователя = h.idПользователя
WHERE h.idЗаявки = @id
ORDER BY h.ДатаИзменения";

        var list = new List<HistoryDto>();
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.Add(ApiDb.P("@id", requestId));
        using var rdr = await cmd.ExecuteReaderAsync(ct);
        while (await rdr.ReadAsync(ct))
            list.Add(new HistoryDto
            {
                User = S(rdr, "Пользователь"),
                OldStatus = SN(rdr, "СтарыйСтатус"),
                NewStatus = S(rdr, "НовыйСтатус"),
                Comment = SN(rdr, "Комментарий"),
                ChangedAt = D(rdr, "ДатаИзменения")
            });
        return list;
    }

    public async Task<(int Id, string Number)> CreateRequestAsync(int clientId,
        int typeId, int priorityId, int userId, string description, CancellationToken ct)
    {
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand("dbo.DS_sp_СоздатьЗаявку", conn)
        {
            CommandType = CommandType.StoredProcedure
        };
        cmd.Parameters.Add(ApiDb.P("@idКлиента", clientId));
        cmd.Parameters.Add(ApiDb.P("@idТипа", typeId));
        cmd.Parameters.Add(ApiDb.P("@idПриоритета", priorityId));
        cmd.Parameters.Add(ApiDb.P("@idПользователя", userId));
        cmd.Parameters.Add(ApiDb.P("@Описание", description));
        var pNumber = new SqlParameter("@НовыйНомер", SqlDbType.NVarChar, 20)
        { Direction = ParameterDirection.Output };
        var pId = new SqlParameter("@idЗаявки", SqlDbType.Int)
        { Direction = ParameterDirection.Output };
        cmd.Parameters.Add(pNumber);
        cmd.Parameters.Add(pId);

        await cmd.ExecuteNonQueryAsync(ct);
        return (Convert.ToInt32(pId.Value), Convert.ToString(pNumber.Value) ?? "");
    }

    public async Task AssignExecutorAsync(int requestId, int employeeId, int userId,
        CancellationToken ct)
    {
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand("dbo.DS_sp_НазначитьИсполнителя", conn)
        {
            CommandType = CommandType.StoredProcedure
        };
        cmd.Parameters.Add(ApiDb.P("@idЗаявки", requestId));
        cmd.Parameters.Add(ApiDb.P("@idСотрудника", employeeId));
        cmd.Parameters.Add(ApiDb.P("@idПользователя", userId));
        await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task ChangeStatusAsync(int requestId, string status, int userId,
        string? comment, string? result, CancellationToken ct)
    {
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand("dbo.DS_sp_ИзменитьСтатусЗаявки", conn)
        {
            CommandType = CommandType.StoredProcedure
        };
        cmd.Parameters.Add(ApiDb.P("@idЗаявки", requestId));
        cmd.Parameters.Add(ApiDb.P("@НовыйСтатус", status));
        cmd.Parameters.Add(ApiDb.P("@idПользователя", userId));
        cmd.Parameters.Add(ApiDb.P("@Комментарий", string.IsNullOrWhiteSpace(comment) ? null : comment));
        cmd.Parameters.Add(ApiDb.P("@Результат", string.IsNullOrWhiteSpace(result) ? null : result));
        await cmd.ExecuteNonQueryAsync(ct);
    }

    // ------------------------------ Справочники -------------------------------

    public async Task<List<ClientDto>> GetClientsAsync(string? search, CancellationToken ct)
    {
        const string sql = @"
SELECT k.idКлиента, u.ФИО, u.Телефон, u.Email, k.Адрес, k.Организация, k.ДатаРегистрации
FROM dbo.DS_Клиенты k
JOIN dbo.DS_Пользователи u ON u.idПользователя = k.idПользователя
WHERE (@s IS NULL OR u.ФИО LIKE '%' + @s + '%' OR u.Телефон LIKE '%' + @s + '%'
       OR k.Организация LIKE '%' + @s + '%')
ORDER BY u.ФИО";

        var list = new List<ClientDto>();
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.Add(ApiDb.P("@s", string.IsNullOrWhiteSpace(search) ? null : search));
        using var rdr = await cmd.ExecuteReaderAsync(ct);
        while (await rdr.ReadAsync(ct))
            list.Add(new ClientDto
            {
                Id = I(rdr, "idКлиента"),
                Fio = S(rdr, "ФИО"),
                Phone = S(rdr, "Телефон"),
                Email = SN(rdr, "Email"),
                Address = SN(rdr, "Адрес"),
                Organization = SN(rdr, "Организация"),
                RegisteredAt = D(rdr, "ДатаРегистрации")
            });
        return list;
    }

    public async Task<List<EmployeeDto>> GetEmployeesAsync(bool onlyActive,
        CancellationToken ct)
    {
        const string sql = @"
SELECT s.idСотрудника, u.ФИО, u.Телефон, u.Email, s.Должность,
       s.Специализация, s.Активен, s.ДатаПриема
FROM dbo.DS_Сотрудники s
JOIN dbo.DS_Пользователи u ON u.idПользователя = s.idПользователя
WHERE (@onlyActive = 0 OR s.Активен = 1)
ORDER BY u.ФИО";

        var list = new List<EmployeeDto>();
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.Add(ApiDb.P("@onlyActive", onlyActive ? 1 : 0));
        using var rdr = await cmd.ExecuteReaderAsync(ct);
        while (await rdr.ReadAsync(ct))
            list.Add(new EmployeeDto
            {
                Id = I(rdr, "idСотрудника"),
                Fio = S(rdr, "ФИО"),
                Phone = S(rdr, "Телефон"),
                Email = SN(rdr, "Email"),
                Position = S(rdr, "Должность"),
                Specialization = S(rdr, "Специализация"),
                Active = B(rdr, "Активен"),
                HiredAt = D(rdr, "ДатаПриема")
            });
        return list;
    }

    public async Task<List<ProblemTypeDto>> GetProblemTypesAsync(CancellationToken ct)
    {
        const string sql = @"
SELECT idТипа, Название, Описание, НормативЧасов
FROM dbo.DS_ТипыПроблем ORDER BY Название";
        var list = new List<ProblemTypeDto>();
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(sql, conn);
        using var rdr = await cmd.ExecuteReaderAsync(ct);
        while (await rdr.ReadAsync(ct))
            list.Add(new ProblemTypeDto
            {
                Id = I(rdr, "idТипа"),
                Name = S(rdr, "Название"),
                Description = SN(rdr, "Описание"),
                StandardHours = I(rdr, "НормативЧасов")
            });
        return list;
    }

    public async Task<List<ReferenceDto>> GetStatusesAsync(CancellationToken ct)
    {
        const string sql =
            "SELECT idСтатуса, Название, Порядок FROM dbo.DS_СтатусыЗаявок ORDER BY Порядок";
        var list = new List<ReferenceDto>();
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(sql, conn);
        using var rdr = await cmd.ExecuteReaderAsync(ct);
        while (await rdr.ReadAsync(ct))
            list.Add(new ReferenceDto
            {
                Id = I(rdr, "idСтатуса"),
                Name = S(rdr, "Название"),
                Order = I(rdr, "Порядок")
            });
        return list;
    }

    public async Task<List<ReferenceDto>> GetPrioritiesAsync(CancellationToken ct)
    {
        const string sql =
            "SELECT idПриоритета, Название, Вес FROM dbo.DS_Приоритеты ORDER BY Вес";
        var list = new List<ReferenceDto>();
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(sql, conn);
        using var rdr = await cmd.ExecuteReaderAsync(ct);
        while (await rdr.ReadAsync(ct))
            list.Add(new ReferenceDto
            {
                Id = I(rdr, "idПриоритета"),
                Name = S(rdr, "Название"),
                Order = I(rdr, "Вес")
            });
        return list;
    }

    // -------------------------------- Отчёты ----------------------------------

    public async Task<ReportPeriodDto> GetReportPeriodAsync(DateTime from, DateTime to,
        CancellationToken ct)
    {
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand("dbo.DS_sp_ОтчетЗаПериод", conn)
        {
            CommandType = CommandType.StoredProcedure
        };
        cmd.Parameters.Add(ApiDb.P("@ДатаС", from.Date));
        cmd.Parameters.Add(ApiDb.P("@ДатаПо", to.Date));
        using var rdr = await cmd.ExecuteReaderAsync(ct);
        if (!await rdr.ReadAsync(ct)) return new ReportPeriodDto();
        return new ReportPeriodDto
        {
            ClosedTotal = rdr["ВсегоЗакрыто"] == DBNull.Value ? 0 : Convert.ToInt32(rdr["ВсегоЗакрыто"]),
            Overdue = rdr["Просрочено"] == DBNull.Value ? 0 : Convert.ToInt32(rdr["Просрочено"]),
            AverageHours = rdr["СреднееЧасов"] == DBNull.Value ? 0 : Convert.ToDecimal(rdr["СреднееЧасов"])
        };
    }

    public async Task<List<ReportByTypeDto>> GetReportByTypeAsync(DateTime from,
        DateTime to, CancellationToken ct)
    {
        const string sql = @"
SELECT tp.Название AS ТипПроблемы,
       COUNT(*) AS Всего,
       SUM(CASE WHEN s.Закрывающий = 1 THEN 1 ELSE 0 END) AS Закрыто,
       SUM(CASE WHEN z.ДатаЗакрытия IS NOT NULL
                 AND z.ДатаЗакрытия > DATEADD(HOUR, tp.НормативЧасов, z.ДатаСоздания)
                THEN 1 ELSE 0 END) AS Просрочено
FROM dbo.DS_Заявки z
JOIN dbo.DS_ТипыПроблем tp ON tp.idТипа = z.idТипа
JOIN dbo.DS_СтатусыЗаявок s ON s.idСтатуса = z.idСтатуса
WHERE CAST(z.ДатаСоздания AS date) BETWEEN @from AND @to
GROUP BY tp.Название
ORDER BY Всего DESC";

        var list = new List<ReportByTypeDto>();
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.Add(ApiDb.P("@from", from.Date));
        cmd.Parameters.Add(ApiDb.P("@to", to.Date));
        using var rdr = await cmd.ExecuteReaderAsync(ct);
        while (await rdr.ReadAsync(ct))
            list.Add(new ReportByTypeDto
            {
                ProblemType = S(rdr, "ТипПроблемы"),
                Total = I(rdr, "Всего"),
                Closed = I(rdr, "Закрыто"),
                Overdue = I(rdr, "Просрочено")
            });
        return list;
    }

    public async Task<List<ReportDetailDto>> GetReportDetailAsync(DateTime from,
        DateTime to, CancellationToken ct)
    {
        var list = new List<ReportDetailDto>();
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand("dbo.DS_sp_ОтчетЗаПериодДетально", conn)
        {
            CommandType = CommandType.StoredProcedure
        };
        cmd.Parameters.Add(ApiDb.P("@ДатаС", from.Date));
        cmd.Parameters.Add(ApiDb.P("@ДатаПо", to.Date));
        using var rdr = await cmd.ExecuteReaderAsync(ct);
        while (await rdr.ReadAsync(ct))
            list.Add(new ReportDetailDto
            {
                Number = S(rdr, "НомерЗаявки"),
                ProblemType = S(rdr, "ТипПроблемы"),
                Priority = S(rdr, "Приоритет"),
                Status = S(rdr, "Статус"),
                CreatedAt = D(rdr, "ДатаСоздания"),
                ClosedAt = DN(rdr, "ДатаЗакрытия"),
                Minutes = IN(rdr, "МинутНаВыполнение"),
                Overdue = B(rdr, "Просрочена"),
                Client = S(rdr, "Клиент"),
                Executor = S(rdr, "Исполнитель")
            });
        return list;
    }

    public async Task<List<EmployeeLoadDto>> GetEmployeeLoadAsync(CancellationToken ct)
    {
        const string sql = @"
SELECT idСотрудника, Сотрудник, Должность, Активен, ВсегоЗаявок,
       ВРаботе, Закрыто, Просрочено
FROM dbo.DS_vw_НагрузкаСотрудников
ORDER BY ВРаботе DESC, ВсегоЗаявок DESC, Сотрудник";

        var list = new List<EmployeeLoadDto>();
        using var conn = await _db.OpenAsync(ct);
        using var cmd = new SqlCommand(sql, conn);
        using var rdr = await cmd.ExecuteReaderAsync(ct);
        while (await rdr.ReadAsync(ct))
            list.Add(new EmployeeLoadDto
            {
                EmployeeId = I(rdr, "idСотрудника"),
                Employee = S(rdr, "Сотрудник"),
                Position = S(rdr, "Должность"),
                Active = B(rdr, "Активен"),
                Total = I(rdr, "ВсегоЗаявок"),
                InWork = I(rdr, "ВРаботе"),
                Closed = I(rdr, "Закрыто"),
                Overdue = I(rdr, "Просрочено")
            });
        return list;
    }

    private static UserDto MapUser(SqlDataReader r) => new()
    {
        Id = I(r, "idПользователя"),
        Login = S(r, "Логин"),
        Fio = S(r, "ФИО"),
        Phone = S(r, "Телефон"),
        Email = SN(r, "Email"),
        Role = S(r, "Роль"),
        Blocked = B(r, "Заблокирован"),
        RegisteredAt = D(r, "ДатаРегистрации"),
        LastLogin = DN(r, "ПоследнийВход")
    };
}
