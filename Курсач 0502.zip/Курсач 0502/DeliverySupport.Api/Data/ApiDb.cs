using Microsoft.Data.SqlClient;

namespace DeliverySupport.Api.Data;

/// <summary>Фабрика подключений к MS SQL Server для API.</summary>
public class ApiDb
{
    private readonly string _connectionString;

    public ApiDb(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("DeliverySupport")
            ?? throw new InvalidOperationException(
                "В appsettings.json не задана строка подключения DeliverySupport.");
    }

    public async Task<SqlConnection> OpenAsync(CancellationToken ct = default)
    {
        var conn = new SqlConnection(_connectionString);
        await conn.OpenAsync(ct);
        return conn;
    }

    public static SqlParameter P(string name, object? value) =>
        new(name, value ?? DBNull.Value);
}
