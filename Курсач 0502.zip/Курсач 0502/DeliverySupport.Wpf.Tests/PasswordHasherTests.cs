using DeliverySupport.Wpf.Data;
using Xunit;

namespace DeliverySupport.Wpf.Tests;

public class PasswordHasherTests
{
    [Fact]
    public void Hash_ReturnsSaltedFormat_AndVerifies()
    {
        string hash = PasswordHasher.Hash("Test123");

        Assert.StartsWith("S1$", hash);
        Assert.True(PasswordHasher.Verify("Test123", hash));
        Assert.False(PasswordHasher.Verify("test123", hash));
        Assert.False(PasswordHasher.Verify("Test1234", hash));
    }

    [Fact]
    public void Hash_IsSalted_SoSamePasswordGivesDifferentHashes()
    {
        string a = PasswordHasher.Hash("SamePassword");
        string b = PasswordHasher.Hash("SamePassword");

        Assert.NotEqual(a, b);
        Assert.True(PasswordHasher.Verify("SamePassword", a));
        Assert.True(PasswordHasher.Verify("SamePassword", b));
    }

    [Fact]
    public void Verify_SupportsLegacyHashWithoutSalt()
    {
        // HASHBYTES('SHA2_256', N'Admin123') из скрипта create_database.sql
        const string legacy =
            "B48728584C9A1E68291C83CA26696090A51EEB435BB207009969D1743F4BA397";

        Assert.True(PasswordHasher.Verify("Admin123", legacy));
        Assert.False(PasswordHasher.Verify("Admin124", legacy));
    }

    [Fact]
    public void NeedsRehash_DetectsLegacyAndSaltedHashes()
    {
        Assert.True(PasswordHasher.NeedsRehash("B48728584C9A1E68291C83CA26696090A51EEB435BB207009969D1743F4BA397"));
        Assert.False(PasswordHasher.NeedsRehash(PasswordHasher.Hash("Secret1")));
    }
}
