using System;
using System.Linq;
using DeliverySupport.Wpf.Data;
using Xunit;

namespace DeliverySupport.Wpf.Tests;

/// <summary>
/// Интеграционные тесты слоя данных. Если учебный сервер MS SQL недоступен,
/// тесты завершаются без падения (проверяется только среда без БД).
/// </summary>
public class RepositoryIntegrationTests
{
    private static bool DbAvailable()
    {
        return Db.TestConnection(out _);
    }

    [Fact]
    public void Authenticate_Admin_ReturnsAdministrator()
    {
        if (!DbAvailable()) return;

        var user = Repository.Authenticate("admin", "Admin123");

        Assert.NotNull(user);
        Assert.Equal("Администратор", user.Роль);
        Assert.False(user.Заблокирован);
    }

    [Fact]
    public void Authenticate_WrongPassword_ReturnsNull()
    {
        if (!DbAvailable()) return;

        Assert.Null(Repository.Authenticate("admin", "WrongPassword"));
    }

    [Fact]
    public void GetStatuses_ContainsSevenStatuses()
    {
        if (!DbAvailable()) return;

        var statuses = Repository.GetStatuses();

        Assert.Equal(7, statuses.Count);
        Assert.Contains(statuses, s => s.Название == "Закрыта");
    }

    [Fact]
    public void GetEmployeeLoad_ReturnsRowsWithCounters()
    {
        if (!DbAvailable()) return;

        var load = Repository.GetEmployeeLoad();

        Assert.NotEmpty(load);
        Assert.All(load, row =>
        {
            Assert.False(string.IsNullOrWhiteSpace(row.Сотрудник));
            Assert.True(row.ВсегоЗаявок >= 0);
            Assert.True(row.ВРаботе >= 0);
            Assert.True(row.Закрыто >= 0);
        });
    }

    [Fact]
    public void GetRequests_FilterByExecutor_ReturnsOnlyAssigned()
    {
        if (!DbAvailable()) return;

        var all = Repository.GetRequests(null, null, null, null);
        var assigned = all.FirstOrDefault(r => r.IdИсполнителя.HasValue);
        if (assigned == null) return; // в демонстрационных данных нет назначенных заявок

        var filtered = Repository.GetRequests(null, null, assigned.IdИсполнителя, null);

        Assert.NotEmpty(filtered);
        Assert.All(filtered, r => Assert.Equal(assigned.IdИсполнителя, r.IdИсполнителя));
    }

    [Fact]
    public void GetReportDetail_ForWidePeriod_ReturnsClosedRequests()
    {
        if (!DbAvailable()) return;

        var rows = Repository.GetReportDetail(
            new DateTime(2020, 1, 1), new DateTime(2030, 12, 31));

        Assert.NotEmpty(rows);
        Assert.All(rows, r => Assert.False(string.IsNullOrWhiteSpace(r.НомерЗаявки)));
    }
}
