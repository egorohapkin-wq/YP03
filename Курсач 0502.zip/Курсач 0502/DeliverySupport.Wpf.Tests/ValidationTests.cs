using DeliverySupport.Wpf.Data;
using Xunit;

namespace DeliverySupport.Wpf.Tests;

public class ValidationTests
{
    [Theory]
    [InlineData("+7 (920) 000-00-01", "+79200000001")]
    [InlineData("8 920 000 00 01", "+79200000001")]
    [InlineData("9200000001", "+79200000001")]
    public void NormalizePhone_AcceptsCommonFormats(string input, string expected)
    {
        Assert.Equal(expected, Validation.NormalizePhone(input));
    }

    [Theory]
    [InlineData("123")]
    [InlineData("+7 920 000")]
    [InlineData("")]
    public void NormalizePhone_RejectsShortNumbers(string input)
    {
        Assert.Null(Validation.NormalizePhone(input));
    }

    [Theory]
    [InlineData("client", true)]
    [InlineData("user_01", true)]
    [InlineData("ab", false)]
    [InlineData("1client", false)]
    [InlineData("client-name", false)]
    [InlineData("verylonglogin123", false)]
    public void IsValidLogin_ChecksLengthAndCharacters(string login, bool expected)
    {
        Assert.Equal(expected, Validation.IsValidLogin(login));
    }

    [Theory]
    [InlineData("12345", false)]
    [InlineData("123456", true)]
    [InlineData("12345678901234", true)]
    [InlineData("123456789012345", false)]
    public void IsValidPassword_ChecksLength(string password, bool expected)
    {
        Assert.Equal(expected, Validation.IsValidPassword(password));
    }

    [Theory]
    [InlineData("Иванов Иван", true)]
    [InlineData("Иванов", false)]
    [InlineData("", false)]
    public void IsValidFio_RequiresAtLeastTwoWords(string fio, bool expected)
    {
        Assert.Equal(expected, Validation.IsValidFio(fio));
    }

    [Theory]
    [InlineData("user@mail.ru", true)]
    [InlineData("", true)]
    [InlineData("not-an-email", false)]
    public void IsValidEmail_ChecksFormat(string email, bool expected)
    {
        Assert.Equal(expected, Validation.IsValidEmail(email));
    }
}
