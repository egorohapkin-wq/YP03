﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {

        public static int UserId { get; set; }
        public static int RoleId { get; set; }
        public static string Login { get; set; }
        public static int ClientId { get; set; }
    }
}
