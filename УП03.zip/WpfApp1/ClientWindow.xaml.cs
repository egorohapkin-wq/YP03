using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Диалог добавления и редактирования клиента
    /// </summary>
    public partial class ClientWindow : Window
    {
        private readonly int? _id;

        public ClientWindow(int? id)
        {
            InitializeComponent();
            _id = id;
            Title = id == null ? "Добавление клиента" : "Редактирование клиента";

            if (id != null) LoadClient();
        }

        private void LoadClient()
        {
            var dt = Database.Query("SELECT * FROM [03Clienti] WHERE ID_Clienti = @id",
                new[] { new SqlParameter("@id", _id.Value) });

            if (dt.Rows.Count == 0) return;
            var r = dt.Rows[0];

            txtFamiliya.Text = r["Familiya"].ToString();
            txtImya.Text = r["Imya"].ToString();
            txtOtchestvo.Text = r["Otchestvo"].ToString();
            txtSeriya.Text = r["seriya_pasporta"].ToString();
            txtNomer.Text = r["nomer_pasporta"].ToString();
            txtKem.Text = r["kem_vidan"].ToString();
            txtTelephone.Text = r["telephone"].ToString();
            txtEmail.Text = r["email"].ToString();
            if (r["data_rojdeniya"] != DBNull.Value)
                dpData.SelectedDate = Convert.ToDateTime(r["data_rojdeniya"]);
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFamiliya.Text) ||
                string.IsNullOrWhiteSpace(txtImya.Text))
            {
                MessageBox.Show("Заполните фамилию и имя.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var p = new List<SqlParameter>
            {
                new SqlParameter("@fam", txtFamiliya.Text.Trim()),
                new SqlParameter("@imya", txtImya.Text.Trim()),
                new SqlParameter("@otch", txtOtchestvo.Text.Trim()),
                new SqlParameter("@data", (object)dpData.SelectedDate ?? DBNull.Value),
                new SqlParameter("@ser", txtSeriya.Text.Trim()),
                new SqlParameter("@nom", txtNomer.Text.Trim()),
                new SqlParameter("@kem", txtKem.Text.Trim()),
                new SqlParameter("@tel", txtTelephone.Text.Trim()),
                new SqlParameter("@mail", txtEmail.Text.Trim())
            };

            try
            {
                if (_id == null)
                {
                    string sql = @"INSERT INTO [03Clienti]
                        (Familiya, Imya, Otchestvo, data_rojdeniya, seriya_pasporta,
                         nomer_pasporta, kem_vidan, telephone, email)
                        VALUES (@fam, @imya, @otch, @data, @ser, @nom, @kem, @tel, @mail)";
                    Database.NonQuery(sql, p.ToArray());
                }
                else
                {
                    p.Add(new SqlParameter("@id", _id.Value));
                    string sql = @"UPDATE [03Clienti] SET
                        Familiya=@fam, Imya=@imya, Otchestvo=@otch, data_rojdeniya=@data,
                        seriya_pasporta=@ser, nomer_pasporta=@nom, kem_vidan=@kem,
                        telephone=@tel, email=@mail
                        WHERE ID_Clienti=@id";
                    Database.NonQuery(sql, p.ToArray());
                }

                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
