using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Диалог добавления и редактирования кредитного продукта
    /// </summary>
    public partial class ProductWindow : Window
    {
        private readonly int? _id;

        public ProductWindow(int? id)
        {
            InitializeComponent();
            _id = id;
            Title = id == null ? "Добавление продукта" : "Редактирование продукта";

            if (id != null) LoadProduct();
        }

        private void LoadProduct()
        {
            var dt = Database.Query("SELECT * FROM [03KRProduct] WHERE ID_Product = @id",
                new[] { new SqlParameter("@id", _id.Value) });

            if (dt.Rows.Count == 0) return;
            var r = dt.Rows[0];

            txtNazvanie.Text = r["nazvanie"].ToString();
            txtVid.Text = r["vid_kredita"].ToString();
            txtStavka.Text = r["proc_stavka"].ToString();
            txtMinSum.Text = r["min_symma"].ToString();
            txtMaxSum.Text = r["max_symma"].ToString();
            txtMinSrok.Text = r["min_srok"].ToString();
            txtMaxSrok.Text = r["max_srok"].ToString();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNazvanie.Text))
            {
                MessageBox.Show("Введите название продукта.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var p = new List<SqlParameter>
            {
                new SqlParameter("@naz", txtNazvanie.Text.Trim()),
                new SqlParameter("@vid", txtVid.Text.Trim()),
                new SqlParameter("@stavka", txtStavka.Text.Trim()),
                new SqlParameter("@mins", txtMinSum.Text.Trim()),
                new SqlParameter("@maxs", txtMaxSum.Text.Trim()),
                new SqlParameter("@minsr", txtMinSrok.Text.Trim()),
                new SqlParameter("@maxsr", txtMaxSrok.Text.Trim())
            };

            try
            {
                if (_id == null)
                {
                    string sql = @"INSERT INTO [03KRProduct]
                        (nazvanie, vid_kredita, proc_stavka, min_symma, max_symma, min_srok, max_srok)
                        VALUES (@naz, @vid, @stavka, @mins, @maxs, @minsr, @maxsr)";
                    Database.NonQuery(sql, p.ToArray());
                }
                else
                {
                    p.Add(new SqlParameter("@id", _id.Value));
                    string sql = @"UPDATE [03KRProduct] SET nazvanie=@naz, vid_kredita=@vid,
                        proc_stavka=@stavka, min_symma=@mins, max_symma=@maxs,
                        min_srok=@minsr, max_srok=@maxsr
                        WHERE ID_Product=@id";
                    Database.NonQuery(sql, p.ToArray());
                }

                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}