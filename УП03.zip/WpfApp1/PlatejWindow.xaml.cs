using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Диалог добавления и редактирования платежа
    /// </summary>
    public partial class PlatejWindow : Window
    {
        private readonly int? _id;

        public PlatejWindow(int? id)
        {
            InitializeComponent();
            _id = id;
            Title = id == null ? "Добавление платежа" : "Редактирование платежа";

            cmbStatus.ItemsSource = new[] { "Оплачен", "Просрочен", "Ожидается" };

            LoadDogovors();

            if (id != null) LoadPlatej();
        }

        private void LoadDogovors()
        {
            var dt = Database.Query(
                @"SELECT d.ID_Dogovor,
                         d.Nomer_dogovora + ' — ' + c.Familiya + ' ' + c.Imya AS Info
                  FROM [03Dogovor] d
                  LEFT JOIN [03Clienti] c ON d.ID_Clienta = c.ID_Clienti
                  ORDER BY d.Nomer_dogovora");
            cmbDogovor.ItemsSource = dt.DefaultView;
        }

        private void LoadPlatej()
        {
            var dt = Database.Query("SELECT * FROM [03Plateji] WHERE ID_Platej = @id",
                new[] { new SqlParameter("@id", _id.Value) });

            if (dt.Rows.Count == 0) return;
            var r = dt.Rows[0];

            if (r["ID_Dogovor"] != DBNull.Value)
                cmbDogovor.SelectedValue = Convert.ToInt32(r["ID_Dogovor"]);

            txtNomer.Text = r["nomer_plateja"].ToString();
            txtSymma.Text = r["symma_oplati"].ToString();
            cmbStatus.Text = r["status"].ToString();

            if (r["data_plateja"] != DBNull.Value)
                dpData.SelectedDate = Convert.ToDateTime(r["data_plateja"]);
            if (r["data_oplati"] != DBNull.Value)
                dpDataOplati.SelectedDate = Convert.ToDateTime(r["data_oplati"]);
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (cmbDogovor.SelectedValue == null)
            {
                MessageBox.Show("Выберите договор.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string status = cmbStatus.Text.Trim();
            if (status == "") status = "Ожидается";

            var p = new List<SqlParameter>
            {
                new SqlParameter("@dogovor", cmbDogovor.SelectedValue),
                new SqlParameter("@nomer", txtNomer.Text.Trim()),
                new SqlParameter("@data", (object)dpData.SelectedDate ?? DBNull.Value),
                new SqlParameter("@symma", txtSymma.Text.Trim()),
                new SqlParameter("@dataopl", (object)dpDataOplati.SelectedDate ?? DBNull.Value),
                new SqlParameter("@status", status)
            };

            try
            {
                if (_id == null)
                {
                    string sql = @"INSERT INTO [03Plateji]
                        (ID_Dogovor, nomer_plateja, data_plateja, symma_oplati, data_oplati, status)
                        VALUES (@dogovor, @nomer, @data, @symma, @dataopl, @status)";
                    Database.NonQuery(sql, p.ToArray());
                }
                else
                {
                    p.Add(new SqlParameter("@id", _id.Value));
                    string sql = @"UPDATE [03Plateji] SET ID_Dogovor=@dogovor, nomer_plateja=@nomer,
                        data_plateja=@data, symma_oplati=@symma, data_oplati=@dataopl, status=@status
                        WHERE ID_Platej=@id";
                    Database.NonQuery(sql, p.ToArray());
                }

                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}