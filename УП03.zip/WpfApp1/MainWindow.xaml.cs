using System;
using System.Data.SqlClient;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string _module = "Клиенты";

        public MainWindow()
        {
            InitializeComponent();

            UserText.Text = "Пользователь: " + App.Login +
                (App.RoleId == 1 ? " (Администратор)" : " (Клиент)");

            ApplyRole();
            LoadData();
        }

        // Доступ: администратор (ID_Role = 1) может всё, остальные - только просмотр
        private void ApplyRole()
        {
            bool isAdmin = App.RoleId == 1;
            btnAdd.IsEnabled = isAdmin;
            btnEdit.IsEnabled = isAdmin;
            btnDelete.IsEnabled = isAdmin;
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void Module_Click(object sender, RoutedEventArgs e)
        {
            var item = sender as MenuItem;
            if (item == null) return;

            _module = item.Tag.ToString();
            txtSearch.Clear();
            LoadData();
        }

        private void Refresh_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void Find_Click(object sender, RoutedEventArgs e)
        {
            LoadData();
        }

        private void Add_Click(object sender, RoutedEventArgs e)
        {
            if (!CanEdit()) return;

            if (OpenDialog(null))
            {
                LoadData();
                StatusText.Text = "Запись добавлена";
            }
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (!CanEdit()) return;

            int id = GetSelectedId();
            if (id == 0) return;

            if (OpenDialog(id))
            {
                LoadData();
                StatusText.Text = "Запись изменена";
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (!CanEdit()) return;

            int id = GetSelectedId();
            if (id == 0) return;

            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
                return;

            try
            {
                string sql = "DELETE FROM " + GetTableName() +
                             " WHERE " + GetKeyColumn() + " = @id";
                Database.NonQuery(sql, new[] { new SqlParameter("@id", id) });
                LoadData();
                StatusText.Text = "Запись удалена";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось удалить запись:\n" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private bool CanEdit()
        {
            if (_module == "Должники" || _module == "Отчёт")
            {
                MessageBox.Show("Для данного раздела редактирование недоступно.",
                    "Информация", MessageBoxButton.OK, MessageBoxImage.Information);
                return false;
            }

            if (App.RoleId != 1)
            {
                MessageBox.Show("Недостаточно прав для изменения данных.",
                    "Доступ запрещён", MessageBoxButton.OK, MessageBoxImage.Warning);
                return false;
            }

            return true;
        }

        private int GetSelectedId()
        {
            var row = MainDataGrid.SelectedItem as DataRowView;
            if (row == null)
            {
                MessageBox.Show("Выберите запись в таблице.", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return 0;
            }

            return Convert.ToInt32(row["ID"]);
        }

        // Открывает окно добавления (id = null) или редактирования (id != null)
        private bool OpenDialog(int? id)
        {
            Window w = null;

            switch (_module)
            {
                case "Клиенты": w = new ClientWindow(id); break;
                case "Кредитные продукты": w = new ProductWindow(id); break;
                case "Пользователи": w = new UserWindow(id); break;
                case "Филиалы": w = new FilialWindow(id); break;
                case "Заявки": w = new ZayavkaWindow(id); break;
                case "Договоры": w = new DogovorWindow(id); break;
                case "Платежи": w = new PlatejWindow(id); break;
                default: return false;
            }

            return w.ShowDialog() == true;
        }

        // Загрузка данных текущего модуля в таблицу
        private void LoadData()
        {
            try
            {
                string sql = GetSelectSql();
                string search = txtSearch.Text.Trim();

                if (search != "" && GetSearchWhere() != "")
                {
                    sql = AddSearchCondition(sql, GetSearchWhere());
                }

                DataTable dt;
                if (search != "")
                {
                    var p = new[] { new SqlParameter("@q", "%" + search + "%") };
                    dt = Database.Query(sql, p);
                }
                else
                {
                    dt = Database.Query(sql);
                }

                BindGrid(dt);
                Title = "ИС МФО - " + _module;
                StatusText.Text = "Записей: " + dt.Rows.Count;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных:\n" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string AddSearchCondition(string sql, string condition)
        {
            // WHERE должен находиться до ORDER BY. Иначе SQL Server выдаёт:
            // «Неправильный синтаксис около ключевого слова WHERE».
            int orderByIndex = sql.IndexOf("ORDER BY", StringComparison.OrdinalIgnoreCase);
            string orderBy = "";

            if (orderByIndex >= 0)
            {
                orderBy = sql.Substring(orderByIndex);
                sql = sql.Substring(0, orderByIndex).TrimEnd();
            }

            if (sql.IndexOf("WHERE", StringComparison.OrdinalIgnoreCase) >= 0)
                sql += " AND (" + condition + ")";
            else
                sql += " WHERE (" + condition + ")";

            return sql + (orderBy == "" ? "" : " " + orderBy);
        }

        private void BindGrid(DataTable dt)
        {
            MainDataGrid.Columns.Clear();

            foreach (DataColumn dataColumn in dt.Columns)
            {
                var name = dataColumn.ColumnName;
                var header = name;
                if (_module == "Заявки" &&
                    (name == "СРОК КРЕДИТА (МЕСЯЦЫ)" || name == "Срок кредита, мес." ||
                     name == "Срок, мес." || name.Equals("srok", StringComparison.OrdinalIgnoreCase)))
                {
                    header = "Срок кредита (мес.)";
                }

                var width = header == "Срок кредита (мес.)"
                    ? new DataGridLength(140)
                    : DataGridLength.Auto;
                MainDataGrid.Columns.Add(new DataGridTextColumn
                {
                    Header = header,
                    Width = width,
                    Binding = new Binding("[" + name + "]")
                });
            }

            MainDataGrid.ItemsSource = dt.DefaultView;
        }

        private string GetSelectSql()
        {
            switch (_module)
            {
                case "Клиенты":
                    return @"SELECT ID_Clienti AS ID,
                                    ISNULL(Familiya, '') AS [Фамилия],
                                    ISNULL(Imya, '') AS [Имя],
                                    ISNULL(Otchestvo, '') AS [Отчество],
                                    data_rojdeniya AS [Дата рождения],
                                    ISNULL(seriya_pasporta, '') AS [Серия паспорта],
                                    ISNULL(nomer_pasporta, '') AS [Номер паспорта],
                                    ISNULL(kem_vidan, '') AS [Кем выдан],
                                    ISNULL(telephone, '') AS [Телефон],
                                    ISNULL(email, '') AS [Email]
                             FROM [03Clienti]
                             ORDER BY ID_Clienti";

                case "Кредитные продукты":
                    return @"SELECT ID_Product AS ID, nazvanie AS [Название], vid_kredita AS [Вид кредита],
                                    proc_stavka AS [Ставка], min_symma AS [Мин. сумма], max_symma AS [Макс. сумма],
                                    min_srok AS [Мин. срок], max_srok AS [Макс. срок]
                             FROM [03KRProduct]";

                case "Пользователи":
                    return @"SELECT p.ID_Polzovatel AS ID, p.Familiya AS [Фамилия], p.Imya AS [Имя],
                                    p.Otchestvo AS [Отчество], p.login AS [Логин],
                                    r.nazvanie AS [Роль], f.nazvanie AS [Филиал]
                             FROM [03Polzovatel] p
                             LEFT JOIN [03Role] r ON p.ID_Role = r.ID_Role
                             LEFT JOIN [03Filial] f ON p.ID_Filial = f.ID_Filial";

                case "Филиалы":
                    return @"SELECT ID_Filial AS ID, nazvanie AS [Название], gorod AS [Город],
                                    adres AS [Адрес], telephon AS [Телефон]
                             FROM [03Filial]";

                case "Заявки":
                    return @"SELECT z.ID_Zayavki AS ID, c.Familiya + ' ' + c.Imya AS [Клиент],
                                    p.nazvanie AS [Продукт], z.symma AS [Сумма],
                                    z.srok AS [СРОК КРЕДИТА (МЕСЯЦЫ)],
                                    z.data AS [Дата], z.status AS [Статус]
                              FROM [03Zayavki] z
                              LEFT JOIN [03Clienti] c ON z.ID_Client = c.ID_Clienti
                              LEFT JOIN [03KRProduct] p ON z.ID_Product = p.ID_Product";

                case "Договоры":
                    return @"SELECT d.ID_Dogovor AS ID, d.Nomer_dogovora AS [Номер],
                                    c.Familiya + ' ' + c.Imya AS [Клиент],
                                    p.nazvanie AS [Продукт], u.Familiya + ' ' + u.Imya AS [Сотрудник],
                                    d.symma AS [Сумма], d.stavka AS [Ставка], d.srok AS [Срок],
                                    d.symma_k_vozvraty AS [К возврату], d.status AS [Статус]
                             FROM [03Dogovor] d
                             LEFT JOIN [03Clienti] c ON d.ID_Clienta = c.ID_Clienti
                             LEFT JOIN [03KRProduct] p ON d.ID_Producta = p.ID_Product
                             LEFT JOIN [03Polzovatel] u ON d.ID_Polzovatelya = u.ID_Polzovatel";

                case "Платежи":
                    return @"SELECT pl.ID_Platej AS ID, pl.nomer_plateja AS [Номер],
                                    d.Nomer_dogovora AS [Договор], pl.data_plateja AS [Дата платежа],
                                    pl.symma_oplati AS [Сумма], pl.data_oplati AS [Дата оплаты],
                                    pl.status AS [Статус]
                             FROM [03Plateji] pl
                             LEFT JOIN [03Dogovor] d ON pl.ID_Dogovor = d.ID_Dogovor";

                case "Должники":
                    return @"SELECT d.ID_Dogovor AS ID, c.Familiya + ' ' + c.Imya AS [Клиент],
                                    c.telephone AS [Телефон], d.Nomer_dogovora AS [Договор],
                                    d.symma_k_vozvraty AS [К возврату], d.status AS [Статус]
                             FROM [03Dogovor] d
                             LEFT JOIN [03Clienti] c ON d.ID_Clienta = c.ID_Clienti
                             WHERE d.status = 'Просрочен'";

                case "Отчёт":
                    return @"SELECT p.nazvanie AS [Продукт], COUNT(d.ID_Dogovor) AS [Кол-во договоров],
                                    SUM(CAST(d.symma AS bigint)) AS [Сумма выдачи],
                                    SUM(CAST(d.symma_k_vozvraty AS bigint)) AS [Сумма к возврату]
                             FROM [03Dogovor] d
                             LEFT JOIN [03KRProduct] p ON d.ID_Producta = p.ID_Product
                             GROUP BY p.nazvanie";

                default:
                    return "SELECT ID_Clienti AS ID, Familiya AS [Фамилия], Imya AS [Имя] FROM [03Clienti]";
            }
        }

        private string GetSearchWhere()
        {
            switch (_module)
            {
                case "Клиенты":
                    return "Familiya LIKE @q OR Imya LIKE @q OR Otchestvo LIKE @q OR nomer_pasporta LIKE @q";
                case "Кредитные продукты":
                    return "nazvanie LIKE @q OR vid_kredita LIKE @q";
                case "Пользователи":
                    return "p.Familiya LIKE @q OR p.Imya LIKE @q OR p.login LIKE @q";
                case "Филиалы":
                    return "nazvanie LIKE @q OR gorod LIKE @q OR adres LIKE @q";
                case "Заявки":
                    return "c.Familiya LIKE @q OR p.nazvanie LIKE @q OR z.status LIKE @q";
                case "Договоры":
                    return "d.Nomer_dogovora LIKE @q OR c.Familiya LIKE @q OR d.status LIKE @q";
                case "Платежи":
                    return "pl.nomer_plateja LIKE @q OR d.Nomer_dogovora LIKE @q OR pl.status LIKE @q";
                case "Должники":
                    return "c.Familiya LIKE @q OR d.Nomer_dogovora LIKE @q";
                default:
                    return "";
            }
        }

        private string GetTableName()
        {
            switch (_module)
            {
                case "Клиенты": return "[03Clienti]";
                case "Кредитные продукты": return "[03KRProduct]";
                case "Пользователи": return "[03Polzovatel]";
                case "Филиалы": return "[03Filial]";
                case "Заявки": return "[03Zayavki]";
                case "Договоры": return "[03Dogovor]";
                case "Платежи": return "[03Plateji]";
                default: return "[03Clienti]";
            }
        }

        private string GetKeyColumn()
        {
            switch (_module)
            {
                case "Клиенты": return "ID_Clienti";
                case "Кредитные продукты": return "ID_Product";
                case "Пользователи": return "ID_Polzovatel";
                case "Филиалы": return "ID_Filial";
                case "Заявки": return "ID_Zayavki";
                case "Договоры": return "ID_Dogovor";
                case "Платежи": return "ID_Platej";
                default: return "ID_Clienti";
            }
        }
    }

}
