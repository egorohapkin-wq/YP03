using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Диалог добавления и редактирования заявки
    /// </summary>
    public partial class ZayavkaWindow : Window
    {
        private readonly int? _id;
        private readonly int? _clientOnly;

        public ZayavkaWindow(int? id)
            : this(id, null)
        {
        }

        public ZayavkaWindow(int? id, int? clientOnly)
        {
            InitializeComponent();
            _id = id;
            _clientOnly = clientOnly;
            Title = id == null ? "Добавление заявки" : "Редактирование заявки";

            cmbStatus.ItemsSource = new[] { "На рассмотрении", "Одобрена", "Отклонена" };

            LoadClients();
            LoadProducts();

            if (_clientOnly.HasValue)
            {
                cmbClient.SelectedValue = _clientOnly.Value;
                cmbClient.IsEnabled = false;
                cmbStatus.SelectedItem = "На рассмотрении";
                cmbStatus.IsEnabled = false;
            }

            if (id != null) LoadZayavka();
        }

        private void LoadClients()
        {
            var dt = Database.Query(
                "SELECT ID_Clienti, Familiya + ' ' + Imya AS FIO FROM [03Clienti] ORDER BY Familiya");
            cmbClient.ItemsSource = dt.DefaultView;
        }

        private void LoadProducts()
        {
            var dt = Database.Query("SELECT ID_Product, nazvanie FROM [03KRProduct] ORDER BY nazvanie");
            cmbProduct.ItemsSource = dt.DefaultView;
        }

        private void LoadZayavka()
        {
            var dt = Database.Query("SELECT * FROM [03Zayavki] WHERE ID_Zayavki = @id",
                new[] { new SqlParameter("@id", _id.Value) });

            if (dt.Rows.Count == 0) return;
            var r = dt.Rows[0];

            if (r["ID_Client"] != DBNull.Value)
                cmbClient.SelectedValue = Convert.ToInt32(r["ID_Client"]);
            if (r["ID_Product"] != DBNull.Value)
                cmbProduct.SelectedValue = Convert.ToInt32(r["ID_Product"]);

            txtSymma.Text = r["symma"].ToString();
            txtSrok.Text = r["srok"].ToString();
            cmbStatus.Text = r["status"].ToString();

            if (r["data"] != DBNull.Value)
                dpData.SelectedDate = Convert.ToDateTime(r["data"]);
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (cmbClient.SelectedValue == null || cmbProduct.SelectedValue == null)
            {
                MessageBox.Show("Выберите клиента и продукт.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string status = _clientOnly.HasValue ? "На рассмотрении" : cmbStatus.Text.Trim();
            if (status == "") status = "На рассмотрении";

            var p = new List<SqlParameter>
            {
                new SqlParameter("@client", cmbClient.SelectedValue),
                new SqlParameter("@product", cmbProduct.SelectedValue),
                new SqlParameter("@symma", txtSymma.Text.Trim()),
                new SqlParameter("@srok", txtSrok.Text.Trim()),
                new SqlParameter("@data", (object)dpData.SelectedDate ?? DBNull.Value),
                new SqlParameter("@status", status)
            };

            try
            {
                if (_id == null)
                {
                    string sql = @"INSERT INTO [03Zayavki] (ID_Client, ID_Product, symma, srok, data, status)
                                   VALUES (@client, @product, @symma, @srok, @data, @status)";
                    Database.NonQuery(sql, p.ToArray());
                }
                else
                {
                    p.Add(new SqlParameter("@id", _id.Value));
                    string sql = @"UPDATE [03Zayavki] SET ID_Client=@client, ID_Product=@product,
                                   symma=@symma, srok=@srok, data=@data, status=@status
                                   WHERE ID_Zayavki=@id";
                    Database.NonQuery(sql, p.ToArray());
                }

                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
