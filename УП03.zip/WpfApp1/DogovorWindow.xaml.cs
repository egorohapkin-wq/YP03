using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    /// <summary>
    /// Диалог добавления и редактирования договора займа
    /// </summary>
    public partial class DogovorWindow : Window
    {
        private readonly int? _id;

        public DogovorWindow(int? id)
        {
            InitializeComponent();
            _id = id;
            Title = id == null ? "Добавление договора" : "Редактирование договора";

            cmbStatus.ItemsSource = new[] { "Активен", "Закрыт", "Просрочен" };

            LoadClients();
            LoadProducts();
            LoadUsers();

            if (id != null) LoadDogovor();
        }

        private void LoadClients()
        {
            var dt = Database.Query(
                "SELECT ID_Clienti, Familiya + ' ' + Imya AS FIO FROM [03Clienti] ORDER BY Familiya");
            cmbClient.ItemsSource = dt.DefaultView;
        }

        private void LoadProducts()
        {
            var dt = Database.Query(
                "SELECT ID_Product, nazvanie, proc_stavka FROM [03KRProduct] ORDER BY nazvanie");
            cmbProduct.ItemsSource = dt.DefaultView;
        }

        private void LoadUsers()
        {
            var dt = Database.Query(
                "SELECT ID_Polzovatel, Familiya + ' ' + Imya AS FIO FROM [03Polzovatel] ORDER BY Familiya");
            cmbUser.ItemsSource = dt.DefaultView;
        }

        private void LoadDogovor()
        {
            var dt = Database.Query("SELECT * FROM [03Dogovor] WHERE ID_Dogovor = @id",
                new[] { new SqlParameter("@id", _id.Value) });

            if (dt.Rows.Count == 0) return;
            var r = dt.Rows[0];

            txtNomer.Text = r["Nomer_dogovora"].ToString();
            if (r["ID_Clienta"] != DBNull.Value)
                cmbClient.SelectedValue = Convert.ToInt32(r["ID_Clienta"]);
            if (r["ID_Producta"] != DBNull.Value)
                cmbProduct.SelectedValue = Convert.ToInt32(r["ID_Producta"]);
            if (r["ID_Polzovatelya"] != DBNull.Value)
                cmbUser.SelectedValue = Convert.ToInt32(r["ID_Polzovatelya"]);

            txtSymma.Text = r["symma"].ToString();
            txtStavka.Text = r["stavka"].ToString();
            txtSrok.Text = r["srok"].ToString();
            txtKVozvrat.Text = r["symma_k_vozvraty"].ToString();
            cmbStatus.Text = r["status"].ToString();
        }

        private void Product_Changed(object sender, SelectionChangedEventArgs e)
        {
            var row = cmbProduct.SelectedItem as DataRowView;
            if (row != null)
                txtStavka.Text = row["proc_stavka"].ToString();
        }

        private void Calc_Click(object sender, RoutedEventArgs e)
        {
            double sum, st, srok;

            string stavka = txtStavka.Text.Replace("%", "").Trim();

            if (!double.TryParse(txtSymma.Text.Trim(), NumberStyles.Any,
                    CultureInfo.InvariantCulture, out sum) ||
                !double.TryParse(stavka, NumberStyles.Any,
                    CultureInfo.InvariantCulture, out st) ||
                !double.TryParse(txtSrok.Text.Trim(), NumberStyles.Any,
                    CultureInfo.InvariantCulture, out srok))
            {
                MessageBox.Show("Проверьте сумму, ставку и срок (только числа).",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            double result = sum * (1 + st / 100.0 * srok / 12.0);
            txtKVozvrat.Text = Math.Round(result, 2).ToString("0.##", CultureInfo.InvariantCulture);
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNomer.Text))
            {
                MessageBox.Show("Введите номер договора.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            string status = cmbStatus.Text.Trim();
            if (status == "") status = "Активен";

            var p = new List<SqlParameter>
            {
                new SqlParameter("@nomer", txtNomer.Text.Trim()),
                new SqlParameter("@client", cmbClient.SelectedValue ?? (object)DBNull.Value),
                new SqlParameter("@user", cmbUser.SelectedValue ?? (object)DBNull.Value),
                new SqlParameter("@product", cmbProduct.SelectedValue ?? (object)DBNull.Value),
                new SqlParameter("@symma", txtSymma.Text.Trim()),
                new SqlParameter("@stavka", txtStavka.Text.Trim()),
                new SqlParameter("@srok", txtSrok.Text.Trim()),
                new SqlParameter("@kvozvrat", txtKVozvrat.Text.Trim()),
                new SqlParameter("@status", status)
            };

            try
            {
                if (_id == null)
                {
                    string sql = @"INSERT INTO [03Dogovor]
                        (Nomer_dogovora, ID_Clienta, ID_Polzovatelya, ID_Producta,
                         symma, stavka, srok, symma_k_vozvraty, status)
                        VALUES (@nomer, @client, @user, @product, @symma, @stavka, @srok, @kvozvrat, @status)";
                    Database.NonQuery(sql, p.ToArray());
                }
                else
                {
                    p.Add(new SqlParameter("@id", _id.Value));
                    string sql = @"UPDATE [03Dogovor] SET Nomer_dogovora=@nomer, ID_Clienta=@client,
                        ID_Polzovatelya=@user, ID_Producta=@product, symma=@symma,
                        stavka=@stavka, srok=@srok, symma_k_vozvraty=@kvozvrat, status=@status
                        WHERE ID_Dogovor=@id";
                    Database.NonQuery(sql, p.ToArray());
                }

                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}