﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    public static class Database
    {
        public static string ConnectionString =
            "data source=stud-mssql.sttec.yar.ru,38325;" +
            "user id=user92_db;" +
            "password=user92;" +
            "trustservercertificate=True;" +
            "MultipleActiveResultSets=True;" +
            "App=EntityFramework";

        public static DataTable Query(string sql, SqlParameter[] p = null)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(sql, conn))
                {
                    if (p != null) cmd.Parameters.AddRange(p);
                    var dt = new DataTable();
                    new SqlDataAdapter(cmd).Fill(dt);
                    return dt;
                }
            }
        }

        public static int NonQuery(string sql, SqlParameter[] p = null)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(sql, conn))
                {
                    if (p != null) cmd.Parameters.AddRange(p);
                    return cmd.ExecuteNonQuery();
                }
            }
        }

        public static object Scalar(string sql, SqlParameter[] p = null)
        {
            using (var conn = new SqlConnection(ConnectionString))
            {
                conn.Open();
                using (var cmd = new SqlCommand(sql, conn))
                {
                    if (p != null) cmd.Parameters.AddRange(p);
                    return cmd.ExecuteScalar();
                }
            }
        }
    }
}
