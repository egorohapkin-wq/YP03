using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtLogin.Text) ||
                string.IsNullOrWhiteSpace(txtPassword.Password))
            {
                MessageBox.Show("Введите логин и пароль!", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                string sql = @"SELECT p.ID_Polzovatel, p.ID_Role, p.login, r.nazvanie AS RoleName
                               FROM [03Polzovatel] p
                               LEFT JOIN [03Role] r ON p.ID_Role = r.ID_Role
                               WHERE p.login = @login AND p.parol = @parol";

                SqlParameter[] p = {
                    new SqlParameter("@login", txtLogin.Text.Trim()),
                    new SqlParameter("@parol", txtPassword.Password)
                };

                var dt = Database.Query(sql, p);

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Неверный логин или пароль!", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                App.UserId = Convert.ToInt32(dt.Rows[0]["ID_Polzovatel"]);
                App.RoleId = Convert.ToInt32(dt.Rows[0]["ID_Role"]);
                App.Login = dt.Rows[0]["login"].ToString();

                Window window;
                if (App.RoleId == 1)
                {
                    window = new MainWindow();
                }
                else
                {
                    App.ClientId = ClientContext.GetOrCreateClient(App.UserId);
                    window = new ClientCabinetWindow();
                }

                window.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка подключения к БД:\n" + ex.Message,
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
