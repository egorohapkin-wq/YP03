using System;
using System.Data.SqlClient;
using System.Windows;

namespace WpfApp1
{
    public partial class ClientCabinetWindow : Window
    {
        public ClientCabinetWindow()
        {
            InitializeComponent();
            LoadCabinet();
        }

        private void LoadCabinet()
        {
            try
            {
                if (App.ClientId <= 0)
                {
                    WelcomeText.Text = "Личный кабинет";
                    ProfileText.Text = "Профиль клиента не найден. Обратитесь к администратору.";
                    StatusText.Text = "Клиент не найден";
                    return;
                }

                var profile = Database.Query(@"SELECT Familiya, Imya, Otchestvo, telephone, email
                    FROM [03Clienti] WHERE ID_Clienti=@id", P("@id", App.ClientId));
                if (profile.Rows.Count > 0)
                {
                    var r = profile.Rows[0];
                    var fio = (r["Familiya"] + " " + r["Imya"] + " " + r["Otchestvo"]).Trim();
                    WelcomeText.Text = "Здравствуйте, " + fio + "!";
                    ProfileText.Text = "Телефон: " + DisplayValue(r["telephone"]) +
                                       "\nEmail: " + DisplayValue(r["email"]);
                }
                else
                {
                    ProfileText.Text = "Профиль клиента не найден. Обратитесь к администратору.";
                    StatusText.Text = "Клиент не найден";
                    return;
                }

                ApplicationsGrid.ItemsSource = Database.Query(@"SELECT z.ID_Zayavki AS ID, p.nazvanie AS [Продукт],
                    z.symma AS [Сумма], z.srok AS [Срок кредита (мес.)], z.data AS [Дата], z.status AS [Статус]
                    FROM [03Zayavki] z LEFT JOIN [03KRProduct] p ON z.ID_Product=p.ID_Product
                    WHERE z.ID_Client=@id ORDER BY z.data DESC", P("@id", App.ClientId)).DefaultView;

                ContractsGrid.ItemsSource = Database.Query(@"SELECT d.Nomer_dogovora AS [Договор], p.nazvanie AS [Продукт],
                    d.symma AS [Сумма], d.symma_k_vozvraty AS [К возврату], d.status AS [Статус],
                    pl.data_plateja AS [Дата платежа], pl.symma_oplati AS [Платёж], pl.status AS [Статус платежа]
                    FROM [03Dogovor] d LEFT JOIN [03KRProduct] p ON d.ID_Producta=p.ID_Product
                    LEFT JOIN [03Plateji] pl ON pl.ID_Dogovor=d.ID_Dogovor
                    WHERE d.ID_Clienta=@id ORDER BY pl.data_plateja DESC", P("@id", App.ClientId)).DefaultView;
                StatusText.Text = "Данные загружены";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки личного кабинета:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Apply_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new ZayavkaWindow(null, App.ClientId);
            if (dialog.ShowDialog() == true) LoadCabinet();
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            new LoginWindow().Show();
            Close();
        }

        private static SqlParameter[] P(string name, object value)
        {
            return new[] { new SqlParameter(name, value ?? DBNull.Value) };
        }

        private static string DisplayValue(object value)
        {
            return value == null || value == DBNull.Value || string.IsNullOrWhiteSpace(value.ToString())
                ? "не указано"
                : value.ToString();
        }
    }

    public static class ClientContext
    {
        public static int GetOrCreateClient(int userId)
        {
            var user = Database.Query("SELECT Familiya, Imya, Otchestvo FROM [03Polzovatel] WHERE ID_Polzovatel=@id",
                new[] { new SqlParameter("@id", userId) });
            if (user.Rows.Count == 0) return 0;
            var u = user.Rows[0];

            // В текущей учебной базе нет отдельного поля связи пользователя
            // с клиентом. Для исходных записей используется одинаковый ID.
            var byId = Database.Scalar(@"SELECT ID_Clienti FROM [03Clienti]
                WHERE ID_Clienti=@id", new[] { new SqlParameter("@id", userId) });
            if (byId != null && byId != DBNull.Value) return Convert.ToInt32(byId);

            var existing = Database.Scalar(@"SELECT TOP 1 ID_Clienti FROM [03Clienti]
                WHERE Familiya=@fam AND Imya=@imya AND ISNULL(Otchestvo, '')=ISNULL(@otch, '')
                ORDER BY ID_Clienti", new[] {
                new SqlParameter("@fam", u["Familiya"]), new SqlParameter("@imya", u["Imya"]),
                new SqlParameter("@otch", u["Otchestvo"] ?? DBNull.Value)
            });
            if (existing != null && existing != DBNull.Value) return Convert.ToInt32(existing);

            var created = Database.Scalar(@"INSERT INTO [03Clienti]
                (Familiya, Imya, Otchestvo) OUTPUT INSERTED.ID_Clienti
                VALUES (@fam, @imya, @otch)", new[] {
                new SqlParameter("@fam", u["Familiya"]), new SqlParameter("@imya", u["Imya"]),
                new SqlParameter("@otch", u["Otchestvo"])
            });

            return created == null || created == DBNull.Value ? 0 : Convert.ToInt32(created);
        }
    }
}
