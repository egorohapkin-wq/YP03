using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace WpfApp1
{
    /// <summary>
    /// Диалог добавления и редактирования пользователя
    /// </summary>
    public partial class UserWindow : Window
    {
        private readonly int? _id;

        public UserWindow(int? id)
        {
            InitializeComponent();
            _id = id;
            Title = id == null ? "Добавление пользователя" : "Редактирование пользователя";

            LoadRoles();
            LoadFilials();

            if (id != null) LoadUser();
        }

        private void LoadRoles()
        {
            var dt = Database.Query("SELECT ID_Role, nazvanie FROM [03Role] ORDER BY nazvanie");
            cmbRole.ItemsSource = dt.DefaultView;
        }

        private void LoadFilials()
        {
            var dt = Database.Query("SELECT ID_Filial, nazvanie FROM [03Filial] ORDER BY nazvanie");
            cmbFilial.ItemsSource = dt.DefaultView;
        }

        private void LoadUser()
        {
            var dt = Database.Query("SELECT * FROM [03Polzovatel] WHERE ID_Polzovatel = @id",
                new[] { new SqlParameter("@id", _id.Value) });

            if (dt.Rows.Count == 0) return;
            var r = dt.Rows[0];

            txtFamiliya.Text = r["Familiya"].ToString();
            txtImya.Text = r["Imya"].ToString();
            txtOtchestvo.Text = r["Otchestvo"].ToString();
            txtLogin.Text = r["login"].ToString();
            txtParol.Text = r["parol"].ToString();

            if (r["ID_Role"] != DBNull.Value)
                cmbRole.SelectedValue = Convert.ToInt32(r["ID_Role"]);
            if (r["ID_Filial"] != DBNull.Value)
                cmbFilial.SelectedValue = Convert.ToInt32(r["ID_Filial"]);
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFamiliya.Text) ||
                string.IsNullOrWhiteSpace(txtLogin.Text) ||
                string.IsNullOrWhiteSpace(txtParol.Text))
            {
                MessageBox.Show("Заполните фамилию, логин и пароль.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var p = new List<SqlParameter>
            {
                new SqlParameter("@fam", txtFamiliya.Text.Trim()),
                new SqlParameter("@imya", txtImya.Text.Trim()),
                new SqlParameter("@otch", txtOtchestvo.Text.Trim()),
                new SqlParameter("@login", txtLogin.Text.Trim()),
                new SqlParameter("@parol", txtParol.Text.Trim()),
                new SqlParameter("@role", cmbRole.SelectedValue ?? (object)DBNull.Value),
                new SqlParameter("@filial", cmbFilial.SelectedValue ?? (object)DBNull.Value)
            };

            try
            {
                if (_id == null)
                {
                    string sql = @"INSERT INTO [03Polzovatel]
                        (Familiya, Imya, Otchestvo, login, parol, ID_Role, ID_Filial)
                        VALUES (@fam, @imya, @otch, @login, @parol, @role, @filial)";
                    Database.NonQuery(sql, p.ToArray());
                }
                else
                {
                    p.Add(new SqlParameter("@id", _id.Value));
                    string sql = @"UPDATE [03Polzovatel] SET Familiya=@fam, Imya=@imya,
                        Otchestvo=@otch, login=@login, parol=@parol,
                        ID_Role=@role, ID_Filial=@filial
                        WHERE ID_Polzovatel=@id";
                    Database.NonQuery(sql, p.ToArray());
                }

                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}