using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows;

namespace WpfApp1
{
    /// <summary>
    /// Диалог добавления и редактирования филиала
    /// </summary>
    public partial class FilialWindow : Window
    {
        private readonly int? _id;

        public FilialWindow(int? id)
        {
            InitializeComponent();
            _id = id;
            Title = id == null ? "Добавление филиала" : "Редактирование филиала";

            if (id != null) LoadFilial();
        }

        private void LoadFilial()
        {
            var dt = Database.Query("SELECT * FROM [03Filial] WHERE ID_Filial = @id",
                new[] { new SqlParameter("@id", _id.Value) });

            if (dt.Rows.Count == 0) return;
            var r = dt.Rows[0];

            txtNazvanie.Text = r["nazvanie"].ToString();
            txtGorod.Text = r["gorod"].ToString();
            txtAdres.Text = r["adres"].ToString();
            txtTelephone.Text = r["telephon"].ToString();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNazvanie.Text))
            {
                MessageBox.Show("Введите название филиала.", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var p = new List<SqlParameter>
            {
                new SqlParameter("@naz", txtNazvanie.Text.Trim()),
                new SqlParameter("@gorod", txtGorod.Text.Trim()),
                new SqlParameter("@adres", txtAdres.Text.Trim()),
                new SqlParameter("@tel", txtTelephone.Text.Trim())
            };

            try
            {
                if (_id == null)
                {
                    Database.NonQuery(
                        "INSERT INTO [03Filial] (nazvanie, gorod, adres, telephon) VALUES (@naz, @gorod, @adres, @tel)",
                        p.ToArray());
                }
                else
                {
                    p.Add(new SqlParameter("@id", _id.Value));
                    Database.NonQuery(
                        "UPDATE [03Filial] SET nazvanie=@naz, gorod=@gorod, adres=@adres, telephon=@tel WHERE ID_Filial=@id",
                        p.ToArray());
                }

                DialogResult = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка сохранения:\n" + ex.Message, "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}